<?php
ini_set( 'error_reporting', E_ERROR );
define( "DIR_ROOT", dirname ( __FILE__ ) );

require_once DIR_ROOT . "/config/mysql.cfg.php";
require_once DIR_ROOT . "/config/global.cfg.php";
require_once DIR_ROOT . "/kernel/classes/mysql.class.php";
$db = new db( $sql['server'], $sql['user'], $sql['password'], $sql['database'] );

header('Content-Type: text/xml');
header('Cache-Control: no-cache');
header('Pragma: no-cache');
echo "<?xml version=\"1.0\" encoding=\"utf-8\" ?>\n";
echo "<rss version=\"2.0\">\n";
echo "	<channel>\n";
echo "		<title>" . $config['title'] . "</title>\n";
echo "		<link>" . $config['url_home'] . "</link>\n";
echo "		<description>Новости world-sms</description>\n";
$result = $db->query( "SELECT * FROM " . $sql['prefix'] . "_news WHERE time <= " . ( time () + ( $config['tz'] * 60 ) ) . "  ORDER BY time DESC LIMIT 0, 10;" );
while ( $row = $db->fetchrow( $result ) ) {
	echo "		<item>\n";
	echo "			<title>" . $row['title'] . "</title>\n";
	echo "			<pubDate>" . htmlspecialchars( date( "D, j M Y H:m:s O", $row['time'] ) ) . "</pubDate>\n";
	echo "			<description>" . htmlspecialchars( $row['template'] ) . "</description>\n";
	echo "		</item>\n";
}
echo "	</channel>\n";
echo "</rss>";
?>