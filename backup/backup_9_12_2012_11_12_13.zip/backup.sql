CREATE TABLE `sms_memail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `taker` varchar(255) NOT NULL,
  `time` int(11) NOT NULL,
  `member` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8

INSERT INTO `sms_memail` VALUES(`1`, `kr0n4ik@mail.ru`, `1354729501`, ``);
INSERT INTO `sms_memail` VALUES(`2`, `info@world-sms.ru`, `1354729681`, ``);
CREATE TABLE `sms_msend_one` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `time` int(8) NOT NULL,
  `emails` text NOT NULL,
  `sender` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `template` text NOT NULL,
  `author` varchar(255) NOT NULL,
  `status` text NOT NULL,
  `distr` varchar(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8

CREATE TABLE `sms_news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `template` text NOT NULL,
  `time` int(8) NOT NULL,
  `author` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8

INSERT INTO `sms_news` VALUES(`5`, `Выплаты по партнерской программе за март`, `Произведены выплаты по партнерской программе за март.`, `1333346640`, `Владимир`);
INSERT INTO `sms_news` VALUES(`6`, `Выплаты по партнерской программе за апрель`, `Произведены выплаты по партнерской программе за апрель.`, `1335859680`, `Владимир`);
INSERT INTO `sms_news` VALUES(`7`, `Выплаты по партнерской программе за май`, `Произведены выплаты по партнерской программе за май.`, `1338538500`, `Владимир`);
INSERT INTO `sms_news` VALUES(`8`, `Выплаты по партнерской программе за июнь`, `Произведены выплаты по партнерской программе за июнь.`, `1341220080`, `Владимир`);
INSERT INTO `sms_news` VALUES(`9`, `Выплаты по партнерской программе за июль`, `Произведены выплаты по партнерской программе за июль.`, `1343803080`, `Владимир`);
INSERT INTO `sms_news` VALUES(`10`, `Выплаты по партнерской программе за август`, `Произведены выплаты по партнерской программе за август.`, `1346649000`, `Владимир`);
INSERT INTO `sms_news` VALUES(`11`, `Выплаты по партнерской программе за сентябрь`, `Произведены выплаты по партнерской программе за сентябрь.`, `1349858580`, `Владимир`);
INSERT INTO `sms_news` VALUES(`12`, `Выплаты по партнерской программе за октябрь`, `Произведены выплаты по партнерской программе за октябрь.`, `1351750620`, `Владимир`);
CREATE TABLE `sms_partners_two` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `partone` int(11) NOT NULL,
  `parttwo` int(11) NOT NULL,
  `prpartone` int(11) NOT NULL,
  `prparttwo` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `ip` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2278 DEFAULT CHARSET=latin1

INSERT INTO `sms_partners_two` VALUES(`2`, `0`, `0`, `0`, `0`, `0`, `0`, `91.203.67.49`);
INSERT INTO `sms_partners_two` VALUES(`3`, `0`, `1`, `0`, `0`, `0`, `0`, `176.96.249.143`);
INSERT INTO `sms_partners_two` VALUES(`4`, `0`, `0`, `0`, `0`, `0`, `0`, `176.96.249.143`);
INSERT INTO `sms_partners_two` VALUES(`5`, `0`, `5`, `0`, `0`, `0`, `0`, `95.83.129.18`);
INSERT INTO `sms_partners_two` VALUES(`6`, `0`, `0`, `0`, `0`, `0`, `0`, `95.83.129.18`);
INSERT INTO `sms_partners_two` VALUES(`7`, `0`, `5`, `0`, `0`, `0`, `0`, `188.134.41.188`);
INSERT INTO `sms_partners_two` VALUES(`8`, `0`, `0`, `0`, `0`, `0`, `0`, `188.134.41.188`);
INSERT INTO `sms_partners_two` VALUES(`9`, `0`, `5`, `0`, `0`, `0`, `0`, `66.249.72.112`);
INSERT INTO `sms_partners_two` VALUES(`10`, `0`, `1`, `0`, `0`, `0`, `0`, `91.203.67.99`);
INSERT INTO `sms_partners_two` VALUES(`11`, `0`, `0`, `0`, `0`, `0`, `0`, `91.203.67.99`);
INSERT INTO `sms_partners_two` VALUES(`12`, `11`, `5`, `0`, `20`, `10`, `0`, `91.223.246.3`);
INSERT INTO `sms_partners_two` VALUES(`13`, `0`, `0`, `0`, `0`, `0`, `0`, `91.223.246.3`);
INSERT INTO `sms_partners_two` VALUES(`14`, `0`, `5`, `0`, `0`, `0`, `0`, `91.223.246.3`);
INSERT INTO `sms_partners_two` VALUES(`15`, `0`, `5`, `0`, `0`, `0`, `0`, `95.83.190.104`);
INSERT INTO `sms_partners_two` VALUES(`16`, `0`, `0`, `0`, `0`, `0`, `0`, `95.83.190.104`);
INSERT INTO `sms_partners_two` VALUES(`17`, `0`, `5`, `0`, `0`, `0`, `0`, `83.149.44.109`);
INSERT INTO `sms_partners_two` VALUES(`18`, `0`, `0`, `0`, `0`, `0`, `0`, `83.149.44.109`);
INSERT INTO `sms_partners_two` VALUES(`19`, `0`, `5`, `0`, `0`, `0`, `0`, `95.83.130.114`);
INSERT INTO `sms_partners_two` VALUES(`20`, `0`, `0`, `0`, `0`, `0`, `0`, `95.83.130.114`);
INSERT INTO `sms_partners_two` VALUES(`21`, `0`, `5`, `0`, `0`, `0`, `0`, `92.243.182.36`);
INSERT INTO `sms_partners_two` VALUES(`22`, `0`, `0`, `0`, `0`, `0`, `0`, `92.243.182.36`);
INSERT INTO `sms_partners_two` VALUES(`23`, `0`, `5`, `0`, `0`, `0`, `0`, `81.253.27.91`);
INSERT INTO `sms_partners_two` VALUES(`24`, `0`, `0`, `0`, `0`, `0`, `0`, `81.253.27.91`);
INSERT INTO `sms_partners_two` VALUES(`25`, `12`, `5`, `0`, `20`, `10`, `0`, `193.19.120.237`);
INSERT INTO `sms_partners_two` VALUES(`26`, `0`, `0`, `0`, `0`, `0`, `0`, `193.19.120.237`);
INSERT INTO `sms_partners_two` VALUES(`27`, `0`, `5`, `0`, `0`, `0`, `0`, `95.83.172.117`);
INSERT INTO `sms_partners_two` VALUES(`28`, `0`, `0`, `0`, `0`, `0`, `0`, `95.83.172.117`);
INSERT INTO `sms_partners_two` VALUES(`29`, `13`, `5`, `0`, `20`, `10`, `0`, `83.149.45.49`);
INSERT INTO `sms_partners_two` VALUES(`30`, `0`, `0`, `0`, `0`, `0`, `0`, `83.149.45.49`);
INSERT INTO `sms_partners_two` VALUES(`31`, `0`, `5`, `0`, `0`, `0`, `0`, `95.78.208.47`);
INSERT INTO `sms_partners_two` VALUES(`32`, `0`, `0`, `0`, `0`, `0`, `0`, `95.78.208.47`);
INSERT INTO `sms_partners_two` VALUES(`33`, `0`, `5`, `0`, `0`, `0`, `0`, `176.212.174.63`);
INSERT INTO `sms_partners_two` VALUES(`34`, `0`, `0`, `0`, `0`, `0`, `0`, `176.212.174.63`);
INSERT INTO `sms_partners_two` VALUES(`35`, `0`, `5`, `0`, `0`, `0`, `0`, `89.106.197.29`);
INSERT INTO `sms_partners_two` VALUES(`36`, `0`, `0`, `0`, `0`, `0`, `0`, `89.106.197.29`);
INSERT INTO `sms_partners_two` VALUES(`37`, `0`, `5`, `0`, `0`, `0`, `0`, `109.61.155.23`);
INSERT INTO `sms_partners_two` VALUES(`38`, `0`, `0`, `0`, `0`, `0`, `0`, `109.61.155.23`);
INSERT INTO `sms_partners_two` VALUES(`39`, `0`, `5`, `0`, `0`, `0`, `0`, `83.149.45.131`);
INSERT INTO `sms_partners_two` VALUES(`40`, `0`, `0`, `0`, `0`, `0`, `0`, `83.149.45.131`);
INSERT INTO `sms_partners_two` VALUES(`41`, `0`, `5`, `0`, `0`, `0`, `0`, `89.106.199.199`);
INSERT INTO `sms_partners_two` VALUES(`42`, `0`, `0`, `0`, `0`, `0`, `0`, `89.106.199.199`);
INSERT INTO `sms_partners_two` VALUES(`43`, `14`, `5`, `0`, `20`, `10`, `0`, `46.229.140.197`);
INSERT INTO `sms_partners_two` VALUES(`44`, `15`, `5`, `0`, `20`, `10`, `0`, `46.229.140.197`);
INSERT INTO `sms_partners_two` VALUES(`45`, `0`, `0`, `0`, `0`, `0`, `0`, `46.229.140.197`);
INSERT INTO `sms_partners_two` VALUES(`46`, `16`, `5`, `0`, `20`, `10`, `0`, `46.229.140.197`);
INSERT INTO `sms_partners_two` VALUES(`47`, `0`, `5`, `0`, `0`, `0`, `0`, `94.28.142.93`);
INSERT INTO `sms_partners_two` VALUES(`48`, `0`, `0`, `0`, `0`, `0`, `0`, `94.28.142.93`);
INSERT INTO `sms_partners_two` VALUES(`50`, `0`, `0`, `0`, `0`, `0`, `0`, `176.96.233.78`);
INSERT INTO `sms_partners_two` VALUES(`51`, `0`, `5`, `0`, `0`, `0`, `0`, `178.125.33.22`);
INSERT INTO `sms_partners_two` VALUES(`52`, `0`, `5`, `0`, `0`, `0`, `0`, `91.203.67.38`);
INSERT INTO `sms_partners_two` VALUES(`53`, `0`, `0`, `0`, `0`, `0`, `0`, `91.203.67.38`);
INSERT INTO `sms_partners_two` VALUES(`54`, `0`, `5`, `0`, `0`, `0`, `0`, `46.229.140.198`);
INSERT INTO `sms_partners_two` VALUES(`55`, `0`, `0`, `0`, `0`, `0`, `0`, `46.229.140.198`);
INSERT INTO `sms_partners_two` VALUES(`56`, `0`, `5`, `0`, `0`, `0`, `0`, `31.44.58.152`);
INSERT INTO `sms_partners_two` VALUES(`57`, `0`, `0`, `0`, `0`, `0`, `0`, `31.44.58.152`);
INSERT INTO `sms_partners_two` VALUES(`58`, `0`, `5`, `0`, `0`, `0`, `0`, `95.106.87.35`);
INSERT INTO `sms_partners_two` VALUES(`59`, `0`, `0`, `0`, `0`, `0`, `0`, `95.106.87.35`);
INSERT INTO `sms_partners_two` VALUES(`60`, `0`, `5`, `0`, `0`, `0`, `0`, `176.212.160.181`);
INSERT INTO `sms_partners_two` VALUES(`61`, `0`, `0`, `0`, `0`, `0`, `0`, `176.212.160.181`);
INSERT INTO `sms_partners_two` VALUES(`62`, `0`, `5`, `0`, `0`, `0`, `0`, `37.110.104.47`);
INSERT INTO `sms_partners_two` VALUES(`63`, `0`, `0`, `0`, `0`, `0`, `0`, `37.110.104.47`);
INSERT INTO `sms_partners_two` VALUES(`64`, `0`, `5`, `0`, `0`, `0`, `0`, `66.249.66.101`);
INSERT INTO `sms_partners_two` VALUES(`65`, `0`, `5`, `0`, `0`, `0`, `0`, `176.96.236.91`);
INSERT INTO `sms_partners_two` VALUES(`66`, `0`, `0`, `0`, `0`, `0`, `0`, `176.96.236.91`);
INSERT INTO `sms_partners_two` VALUES(`67`, `0`, `5`, `0`, `0`, `0`, `0`, `193.34.8.214`);
INSERT INTO `sms_partners_two` VALUES(`68`, `0`, `0`, `0`, `0`, `0`, `0`, `193.34.8.214`);
INSERT INTO `sms_partners_two` VALUES(`69`, `0`, `5`, `0`, `0`, `0`, `0`, `78.31.73.172`);
INSERT INTO `sms_partners_two` VALUES(`70`, `0`, `0`, `0`, `0`, `0`, `0`, `78.31.73.172`);
INSERT INTO `sms_partners_two` VALUES(`71`, `0`, `5`, `0`, `0`, `0`, `0`, `95.106.118.247`);
INSERT INTO `sms_partners_two` VALUES(`72`, `0`, `0`, `0`, `0`, `0`, `0`, `95.106.118.247`);
INSERT INTO `sms_partners_two` VALUES(`73`, `0`, `5`, `0`, `0`, `0`, `0`, `31.44.60.61`);
INSERT INTO `sms_partners_two` VALUES(`74`, `0`, `0`, `0`, `0`, `0`, `0`, `31.44.60.61`);
INSERT INTO `sms_partners_two` VALUES(`75`, `0`, `5`, `0`, `0`, `0`, `0`, `176.241.229.218`);
INSERT INTO `sms_partners_two` VALUES(`76`, `0`, `0`, `0`, `0`, `0`, `0`, `176.241.229.218`);
INSERT INTO `sms_partners_two` VALUES(`77`, `0`, `5`, `0`, `0`, `0`, `0`, `83.149.45.186`);
INSERT INTO `sms_partners_two` VALUES(`78`, `0`, `0`, `0`, `0`, `0`, `0`, `83.149.45.186`);
INSERT INTO `sms_partners_two` VALUES(`79`, `0`, `5`, `0`, `0`, `0`, `0`, `176.241.229.145`);
INSERT INTO `sms_partners_two` VALUES(`80`, `0`, `0`, `0`, `0`, `0`, `0`, `176.241.229.145`);
INSERT INTO `sms_partners_two` VALUES(`81`, `0`, `5`, `0`, `0`, `0`, `0`, `91.203.67.180`);
INSERT INTO `sms_partners_two` VALUES(`82`, `0`, `0`, `0`, `0`, `0`, `0`, `91.203.67.180`);
INSERT INTO `sms_partners_two` VALUES(`83`, `0`, `23`, `0`, `0`, `0`, `0`, `87.240.182.155`);
INSERT INTO `sms_partners_two` VALUES(`84`, `0`, `5`, `0`, `0`, `0`, `0`, `91.203.67.156`);
INSERT INTO `sms_partners_two` VALUES(`85`, `0`, `0`, `0`, `0`, `0`, `0`, `91.203.67.156`);
INSERT INTO `sms_partners_two` VALUES(`86`, `0`, `5`, `0`, `0`, `0`, `0`, `31.44.50.120`);
INSERT INTO `sms_partners_two` VALUES(`87`, `0`, `0`, `0`, `0`, `0`, `0`, `31.44.50.120`);
INSERT INTO `sms_partners_two` VALUES(`88`, `0`, `5`, `0`, `0`, `0`, `0`, `87.240.182.130`);
INSERT INTO `sms_partners_two` VALUES(`89`, `0`, `5`, `0`, `0`, `0`, `0`, `80.72.125.156`);
INSERT INTO `sms_partners_two` VALUES(`90`, `0`, `0`, `0`, `0`, `0`, `0`, `80.72.125.156`);
INSERT INTO `sms_partners_two` VALUES(`91`, `0`, `5`, `0`, `0`, `0`, `0`, `95.106.90.193`);
INSERT INTO `sms_partners_two` VALUES(`92`, `0`, `0`, `0`, `0`, `0`, `0`, `95.106.90.193`);
INSERT INTO `sms_partners_two` VALUES(`93`, `0`, `5`, `0`, `0`, `0`, `0`, `95.106.23.178`);
INSERT INTO `sms_partners_two` VALUES(`94`, `0`, `0`, `0`, `0`, `0`, `0`, `95.106.23.178`);
INSERT INTO `sms_partners_two` VALUES(`95`, `0`, `5`, `0`, `0`, `0`, `0`, `176.96.240.147`);
INSERT INTO `sms_partners_two` VALUES(`96`, `0`, `0`, `0`, `0`, `0`, `0`, `176.96.240.147`);
INSERT INTO `sms_partners_two` VALUES(`97`, `0`, `5`, `0`, `0`, `0`, `0`, `95.83.172.215`);
INSERT INTO `sms_partners_two` VALUES(`98`, `0`, `0`, `0`, `0`, `0`, `0`, `95.83.172.215`);
INSERT INTO `sms_partners_two` VALUES(`99`, `0`, `5`, `0`, `0`, `0`, `0`, `80.72.125.137`);
INSERT INTO `sms_partners_two` VALUES(`100`, `0`, `0`, `0`, `0`, `0`, `0`, `80.72.125.137`);
INSERT INTO `sms_partners_two` VALUES(`101`, `0`, `23`, `0`, `0`, `0`, `0`, `88.87.93.45`);
INSERT INTO `sms_partners_two` VALUES(`102`, `0`, `5`, `0`, `0`, `0`, `0`, `212.74.207.25`);
INSERT INTO `sms_partners_two` VALUES(`103`, `0`, `0`, `0`, `0`, `0`, `0`, `212.74.207.25`);
INSERT INTO `sms_partners_two` VALUES(`104`, `0`, `5`, `0`, `0`, `0`, `0`, `176.96.240.216`);
INSERT INTO `sms_partners_two` VALUES(`105`, `0`, `0`, `0`, `0`, `0`, `0`, `176.96.240.216`);
INSERT INTO `sms_partners_two` VALUES(`106`, `0`, `5`, `0`, `0`, `0`, `0`, `91.203.67.71`);
INSERT INTO `sms_partners_two` VALUES(`107`, `0`, `0`, `0`, `0`, `0`, `0`, `91.203.67.71`);
INSERT INTO `sms_partners_two` VALUES(`108`, `0`, `5`, `0`, `0`, `0`, `0`, `213.87.131.147`);
INSERT INTO `sms_partners_two` VALUES(`109`, `0`, `0`, `0`, `0`, `0`, `0`, `213.87.131.147`);
INSERT INTO `sms_partners_two` VALUES(`110`, `0`, `5`, `0`, `0`, `0`, `0`, `95.83.190.39`);
INSERT INTO `sms_partners_two` VALUES(`111`, `0`, `0`, `0`, `0`, `0`, `0`, `95.83.190.39`);
INSERT INTO `sms_partners_two` VALUES(`112`, `0`, `5`, `0`, `0`, `0`, `0`, `176.212.161.9`);
INSERT INTO `sms_partners_two` VALUES(`113`, `0`, `0`, `0`, `0`, `0`, `0`, `176.212.161.9`);
INSERT INTO `sms_partners_two` VALUES(`114`, `0`, `5`, `0`, `0`, `0`, `0`, `95.26.180.180`);
INSERT INTO `sms_partners_two` VALUES(`115`, `0`, `0`, `0`, `0`, `0`, `0`, `95.26.180.180`);
INSERT INTO `sms_partners_two` VALUES(`116`, `0`, `5`, `0`, `0`, `0`, `0`, `83.149.44.37`);
INSERT INTO `sms_partners_two` VALUES(`117`, `0`, `0`, `0`, `0`, `0`, `0`, `83.149.44.37`);
INSERT INTO `sms_partners_two` VALUES(`118`, `0`, `5`, `0`, `0`, `0`, `0`, `94.75.136.233`);
INSERT INTO `sms_partners_two` VALUES(`119`, `0`, `0`, `0`, `0`, `0`, `0`, `94.75.136.233`);
INSERT INTO `sms_partners_two` VALUES(`120`, `0`, `5`, `0`, `0`, `0`, `0`, `83.149.45.207`);
INSERT INTO `sms_partners_two` VALUES(`121`, `0`, `0`, `0`, `0`, `0`, `0`, `83.149.45.207`);
INSERT INTO `sms_partners_two` VALUES(`122`, `0`, `5`, `0`, `0`, `0`, `0`, `176.212.175.55`);
INSERT INTO `sms_partners_two` VALUES(`123`, `0`, `0`, `0`, `0`, `0`, `0`, `176.212.175.55`);
INSERT INTO `sms_partners_two` VALUES(`124`, `0`, `5`, `0`, `0`, `0`, `0`, `95.83.190.30`);
INSERT INTO `sms_partners_two` VALUES(`125`, `0`, `0`, `0`, `0`, `0`, `0`, `95.83.190.30`);
INSERT INTO `sms_partners_two` VALUES(`126`, `0`, `5`, `0`, `0`, `0`, `0`, `194.85.37.126`);
INSERT INTO `sms_partners_two` VALUES(`127`, `0`, `0`, `0`, `0`, `0`, `0`, `194.85.37.126`);
INSERT INTO `sms_partners_two` VALUES(`128`, `0`, `5`, `0`, `0`, `0`, `0`, `176.96.232.193`);
INSERT INTO `sms_partners_two` VALUES(`129`, `0`, `0`, `0`, `0`, `0`, `0`, `176.96.232.193`);
INSERT INTO `sms_partners_two` VALUES(`130`, `0`, `5`, `0`, `0`, `0`, `0`, `213.87.131.164`);
INSERT INTO `sms_partners_two` VALUES(`131`, `0`, `0`, `0`, `0`, `0`, `0`, `213.87.131.164`);
INSERT INTO `sms_partners_two` VALUES(`132`, `0`, `5`, `0`, `0`, `0`, `0`, `95.106.33.215`);
INSERT INTO `sms_partners_two` VALUES(`133`, `0`, `0`, `0`, `0`, `0`, `0`, `95.106.33.215`);
INSERT INTO `sms_partners_two` VALUES(`134`, `0`, `5`, `0`, `0`, `0`, `0`, `176.96.236.7`);
INSERT INTO `sms_partners_two` VALUES(`135`, `0`, `0`, `0`, `0`, `0`, `0`, `176.96.236.7`);
INSERT INTO `sms_partners_two` VALUES(`136`, `0`, `5`, `0`, `0`, `0`, `0`, `176.96.254.26`);
INSERT INTO `sms_partners_two` VALUES(`137`, `0`, `0`, `0`, `0`, `0`, `0`, `176.96.254.26`);
INSERT INTO `sms_partners_two` VALUES(`138`, `0`, `5`, `0`, `0`, `0`, `0`, `91.203.67.124`);
INSERT INTO `sms_partners_two` VALUES(`139`, `0`, `0`, `0`, `0`, `0`, `0`, `91.203.67.124`);
INSERT INTO `sms_partners_two` VALUES(`140`, `0`, `5`, `0`, `0`, `0`, `0`, `213.108.209.165`);
INSERT INTO `sms_partners_two` VALUES(`141`, `0`, `0`, `0`, `0`, `0`, `0`, `213.108.209.165`);
INSERT INTO `sms_partners_two` VALUES(`142`, `0`, `5`, `0`, `0`, `0`, `0`, `46.159.235.48`);
INSERT INTO `sms_partners_two` VALUES(`143`, `0`, `0`, `0`, `0`, `0`, `0`, `46.159.235.48`);
INSERT INTO `sms_partners_two` VALUES(`144`, `0`, `5`, `0`, `0`, `0`, `0`, `91.203.67.217`);
INSERT INTO `sms_partners_two` VALUES(`145`, `0`, `0`, `0`, `0`, `0`, `0`, `91.203.67.217`);
INSERT INTO `sms_partners_two` VALUES(`146`, `0`, `5`, `0`, `0`, `0`, `0`, `212.26.245.148`);
INSERT INTO `sms_partners_two` VALUES(`147`, `0`, `0`, `0`, `0`, `0`, `0`, `212.26.245.148`);
INSERT INTO `sms_partners_two` VALUES(`148`, `0`, `5`, `0`, `0`, `0`, `0`, `92.39.139.146`);
INSERT INTO `sms_partners_two` VALUES(`149`, `0`, `0`, `0`, `0`, `0`, `0`, `92.39.139.146`);
INSERT INTO `sms_partners_two` VALUES(`150`, `0`, `5`, `0`, `0`, `0`, `0`, `87.241.200.9`);
INSERT INTO `sms_partners_two` VALUES(`151`, `0`, `5`, `0`, `0`, `0`, `0`, `95.106.120.127`);
INSERT INTO `sms_partners_two` VALUES(`152`, `0`, `0`, `0`, `0`, `0`, `0`, `95.106.120.127`);
INSERT INTO `sms_partners_two` VALUES(`153`, `0`, `4`, `0`, `0`, `0`, `0`, `176.96.228.146`);
INSERT INTO `sms_partners_two` VALUES(`154`, `0`, `0`, `0`, `0`, `0`, `0`, `176.96.228.146`);
INSERT INTO `sms_partners_two` VALUES(`155`, `0`, `5`, `0`, `0`, `0`, `0`, `95.106.0.98`);
INSERT INTO `sms_partners_two` VALUES(`156`, `0`, `0`, `0`, `0`, `0`, `0`, `95.106.0.98`);
INSERT INTO `sms_partners_two` VALUES(`157`, `0`, `5`, `0`, `0`, `0`, `0`, `176.104.195.91`);
INSERT INTO `sms_partners_two` VALUES(`158`, `0`, `0`, `0`, `0`, `0`, `0`, `176.104.195.91`);
INSERT INTO `sms_partners_two` VALUES(`159`, `0`, `5`, `0`, `0`, `0`, `0`, `176.212.175.248`);
INSERT INTO `sms_partners_two` VALUES(`160`, `0`, `0`, `0`, `0`, `0`, `0`, `176.212.175.248`);
INSERT INTO `sms_partners_two` VALUES(`161`, `0`, `5`, `0`, `0`, `0`, `0`, `176.212.167.195`);
INSERT INTO `sms_partners_two` VALUES(`162`, `0`, `0`, `0`, `0`, `0`, `0`, `176.212.167.195`);
INSERT INTO `sms_partners_two` VALUES(`163`, `27`, `5`, `0`, `20`, `10`, `0`, `176.212.183.44`);
INSERT INTO `sms_partners_two` VALUES(`164`, `0`, `0`, `0`, `0`, `0`, `0`, `176.212.183.44`);
INSERT INTO `sms_partners_two` VALUES(`165`, `0`, `5`, `0`, `0`, `0`, `0`, `95.106.28.106`);
INSERT INTO `sms_partners_two` VALUES(`166`, `0`, `0`, `0`, `0`, `0`, `0`, `95.106.28.106`);
INSERT INTO `sms_partners_two` VALUES(`167`, `0`, `5`, `0`, `0`, `0`, `0`, `109.69.74.28`);
INSERT INTO `sms_partners_two` VALUES(`168`, `0`, `0`, `0`, `0`, `0`, `0`, `109.69.74.28`);
INSERT INTO `sms_partners_two` VALUES(`169`, `28`, `5`, `0`, `20`, `10`, `0`, `85.249.113.102`);
INSERT INTO `sms_partners_two` VALUES(`170`, `0`, `0`, `0`, `0`, `0`, `0`, `85.249.113.102`);
INSERT INTO `sms_partners_two` VALUES(`171`, `0`, `5`, `0`, `0`, `0`, `0`, `95.106.67.214`);
INSERT INTO `sms_partners_two` VALUES(`172`, `0`, `0`, `0`, `0`, `0`, `0`, `95.106.67.214`);
INSERT INTO `sms_partners_two` VALUES(`173`, `0`, `5`, `0`, `0`, `0`, `0`, `93.92.85.86`);
INSERT INTO `sms_partners_two` VALUES(`174`, `0`, `0`, `0`, `0`, `0`, `0`, `93.92.85.86`);
INSERT INTO `sms_partners_two` VALUES(`175`, `0`, `5`, `0`, `0`, `0`, `0`, `31.44.56.55`);
INSERT INTO `sms_partners_two` VALUES(`176`, `0`, `0`, `0`, `0`, `0`, `0`, `31.44.56.55`);
INSERT INTO `sms_partners_two` VALUES(`177`, `0`, `5`, `0`, `0`, `0`, `0`, `91.203.67.202`);
INSERT INTO `sms_partners_two` VALUES(`178`, `0`, `0`, `0`, `0`, `0`, `0`, `91.203.67.202`);
INSERT INTO `sms_partners_two` VALUES(`179`, `0`, `5`, `0`, `0`, `0`, `0`, `92.240.210.44`);
INSERT INTO `sms_partners_two` VALUES(`180`, `0`, `0`, `0`, `0`, `0`, `0`, `92.240.210.44`);
INSERT INTO `sms_partners_two` VALUES(`181`, `0`, `5`, `0`, `0`, `0`, `0`, `46.229.136.13`);
INSERT INTO `sms_partners_two` VALUES(`182`, `0`, `0`, `0`, `0`, `0`, `0`, `46.229.136.13`);
INSERT INTO `sms_partners_two` VALUES(`183`, `0`, `5`, `0`, `0`, `0`, `0`, `91.203.67.70`);
INSERT INTO `sms_partners_two` VALUES(`184`, `0`, `0`, `0`, `0`, `0`, `0`, `91.203.67.70`);
INSERT INTO `sms_partners_two` VALUES(`185`, `0`, `5`, `0`, `0`, `0`, `0`, `95.83.190.126`);
INSERT INTO `sms_partners_two` VALUES(`186`, `0`, `0`, `0`, `0`, `0`, `0`, `95.83.190.126`);
INSERT INTO `sms_partners_two` VALUES(`187`, `0`, `5`, `0`, `0`, `0`, `0`, `176.212.166.147`);
INSERT INTO `sms_partners_two` VALUES(`188`, `0`, `0`, `0`, `0`, `0`, `0`, `176.212.166.147`);
INSERT INTO `sms_partners_two` VALUES(`189`, `0`, `5`, `0`, `0`, `0`, `0`, `176.104.195.252`);
INSERT INTO `sms_partners_two` VALUES(`190`, `0`, `0`, `0`, `0`, `0`, `0`, `176.104.195.252`);
INSERT INTO `sms_partners_two` VALUES(`191`, `0`, `30`, `0`, `0`, `0`, `0`, `212.87.185.235`);
INSERT INTO `sms_partners_two` VALUES(`192`, `0`, `30`, `0`, `0`, `0`, `0`, `178.94.143.215`);
INSERT INTO `sms_partners_two` VALUES(`193`, `0`, `30`, `0`, `0`, `0`, `0`, `94.248.98.152`);
INSERT INTO `sms_partners_two` VALUES(`194`, `0`, `30`, `0`, `0`, `0`, `0`, `212.113.225.185`);
INSERT INTO `sms_partners_two` VALUES(`195`, `0`, `30`, `0`, `0`, `0`, `0`, `46.250.2.87`);
INSERT INTO `sms_partners_two` VALUES(`196`, `0`, `30`, `0`, `0`, `0`, `0`, `178.122.47.209`);
INSERT INTO `sms_partners_two` VALUES(`197`, `0`, `30`, `0`, `0`, `0`, `0`, `95.79.172.120`);
INSERT INTO `sms_partners_two` VALUES(`198`, `0`, `30`, `0`, `0`, `0`, `0`, `94.43.35.60`);
INSERT INTO `sms_partners_two` VALUES(`199`, `0`, `30`, `0`, `0`, `0`, `0`, `178.122.73.9`);
INSERT INTO `sms_partners_two` VALUES(`200`, `0`, `30`, `0`, `0`, `0`, `0`, `93.84.59.50`);
INSERT INTO `sms_partners_two` VALUES(`201`, `0`, `30`, `0`, `0`, `0`, `0`, `176.28.87.242`);
INSERT INTO `sms_partners_two` VALUES(`202`, `0`, `30`, `0`, `0`, `0`, `0`, `178.35.35.73`);
INSERT INTO `sms_partners_two` VALUES(`203`, `0`, `30`, `0`, `0`, `0`, `0`, `178.89.35.227`);
INSERT INTO `sms_partners_two` VALUES(`204`, `0`, `30`, `0`, `0`, `0`, `0`, `188.134.46.186`);
INSERT INTO `sms_partners_two` VALUES(`205`, `0`, `30`, `0`, `0`, `0`, `0`, `95.135.218.132`);
INSERT INTO `sms_partners_two` VALUES(`206`, `0`, `30`, `0`, `0`, `0`, `0`, `95.169.190.176`);
INSERT INTO `sms_partners_two` VALUES(`207`, `0`, `30`, `0`, `0`, `0`, `0`, `213.231.57.185`);
INSERT INTO `sms_partners_two` VALUES(`208`, `0`, `30`, `0`, `0`, `0`, `0`, `178.76.234.94`);
INSERT INTO `sms_partners_two` VALUES(`209`, `0`, `30`, `0`, `0`, `0`, `0`, `62.80.172.54`);
INSERT INTO `sms_partners_two` VALUES(`210`, `0`, `30`, `0`, `0`, `0`, `0`, `178.176.68.6`);
INSERT INTO `sms_partners_two` VALUES(`211`, `0`, `30`, `0`, `0`, `0`, `0`, `46.98.185.36`);
INSERT INTO `sms_partners_two` VALUES(`212`, `0`, `30`, `0`, `0`, `0`, `0`, `79.100.134.26`);
INSERT INTO `sms_partners_two` VALUES(`213`, `0`, `30`, `0`, `0`, `0`, `0`, `178.177.127.78`);
INSERT INTO `sms_partners_two` VALUES(`214`, `0`, `30`, `0`, `0`, `0`, `0`, `95.24.32.203`);
INSERT INTO `sms_partners_two` VALUES(`215`, `0`, `30`, `0`, `0`, `0`, `0`, `62.205.140.107`);
INSERT INTO `sms_partners_two` VALUES(`216`, `0`, `30`, `0`, `0`, `0`, `0`, `94.248.66.134`);
INSERT INTO `sms_partners_two` VALUES(`217`, `0`, `30`, `0`, `0`, `0`, `0`, `212.2.132.241`);
INSERT INTO `sms_partners_two` VALUES(`218`, `0`, `30`, `0`, `0`, `0`, `0`, `93.180.208.98`);
INSERT INTO `sms_partners_two` VALUES(`219`, `0`, `30`, `0`, `0`, `0`, `0`, `95.59.61.30`);
INSERT INTO `sms_partners_two` VALUES(`220`, `0`, `30`, `0`, `0`, `0`, `0`, `109.127.44.113`);
INSERT INTO `sms_partners_two` VALUES(`221`, `0`, `30`, `0`, `0`, `0`, `0`, `176.8.110.213`);
INSERT INTO `sms_partners_two` VALUES(`222`, `0`, `30`, `0`, `0`, `0`, `0`, `93.85.154.226`);
INSERT INTO `sms_partners_two` VALUES(`223`, `0`, `30`, `0`, `0`, `0`, `0`, `95.135.143.117`);
INSERT INTO `sms_partners_two` VALUES(`224`, `0`, `30`, `0`, `0`, `0`, `0`, `37.55.213.51`);
INSERT INTO `sms_partners_two` VALUES(`225`, `0`, `30`, `0`, `0`, `0`, `0`, `31.131.72.213`);
INSERT INTO `sms_partners_two` VALUES(`226`, `0`, `30`, `0`, `0`, `0`, `0`, `176.36.132.100`);
INSERT INTO `sms_partners_two` VALUES(`227`, `0`, `30`, `0`, `0`, `0`, `0`, `188.17.86.242`);
INSERT INTO `sms_partners_two` VALUES(`228`, `0`, `30`, `0`, `0`, `0`, `0`, `178.125.141.156`);
INSERT INTO `sms_partners_two` VALUES(`229`, `0`, `30`, `0`, `0`, `0`, `0`, `31.135.137.59`);
INSERT INTO `sms_partners_two` VALUES(`230`, `0`, `30`, `0`, `0`, `0`, `0`, `46.191.160.85`);
INSERT INTO `sms_partners_two` VALUES(`231`, `0`, `30`, `0`, `0`, `0`, `0`, `93.127.17.71`);
INSERT INTO `sms_partners_two` VALUES(`232`, `0`, `30`, `0`, `0`, `0`, `0`, `109.67.19.44`);
INSERT INTO `sms_partners_two` VALUES(`233`, `0`, `30`, `0`, `0`, `0`, `0`, `176.50.252.89`);
INSERT INTO `sms_partners_two` VALUES(`234`, `0`, `30`, `0`, `0`, `0`, `0`, `176.96.80.147`);
INSERT INTO `sms_partners_two` VALUES(`235`, `0`, `30`, `0`, `0`, `0`, `0`, `92.242.102.140`);
INSERT INTO `sms_partners_two` VALUES(`236`, `0`, `30`, `0`, `0`, `0`, `0`, `95.79.75.74`);
INSERT INTO `sms_partners_two` VALUES(`237`, `0`, `30`, `0`, `0`, `0`, `0`, `109.86.203.184`);
INSERT INTO `sms_partners_two` VALUES(`238`, `0`, `30`, `0`, `0`, `0`, `0`, `94.242.170.186`);
INSERT INTO `sms_partners_two` VALUES(`239`, `0`, `30`, `0`, `0`, `0`, `0`, `109.162.52.172`);
INSERT INTO `sms_partners_two` VALUES(`240`, `0`, `30`, `0`, `0`, `0`, `0`, `31.180.131.254`);
INSERT INTO `sms_partners_two` VALUES(`241`, `0`, `30`, `0`, `0`, `0`, `0`, `91.201.230.131`);
INSERT INTO `sms_partners_two` VALUES(`242`, `0`, `30`, `0`, `0`, `0`, `0`, `91.231.95.163`);
INSERT INTO `sms_partners_two` VALUES(`243`, `0`, `30`, `0`, `0`, `0`, `0`, `42.117.245.111`);
INSERT INTO `sms_partners_two` VALUES(`244`, `0`, `30`, `0`, `0`, `0`, `0`, `2.61.96.25`);
INSERT INTO `sms_partners_two` VALUES(`245`, `0`, `30`, `0`, `0`, `0`, `0`, `2.92.28.93`);
INSERT INTO `sms_partners_two` VALUES(`246`, `0`, `30`, `0`, `0`, `0`, `0`, `46.0.49.114`);
INSERT INTO `sms_partners_two` VALUES(`247`, `0`, `30`, `0`, `0`, `0`, `0`, `176.195.7.17`);
INSERT INTO `sms_partners_two` VALUES(`248`, `0`, `30`, `0`, `0`, `0`, `0`, `95.37.11.25`);
INSERT INTO `sms_partners_two` VALUES(`249`, `0`, `30`, `0`, `0`, `0`, `0`, `178.184.98.253`);
INSERT INTO `sms_partners_two` VALUES(`250`, `0`, `30`, `0`, `0`, `0`, `0`, `178.123.212.213`);
INSERT INTO `sms_partners_two` VALUES(`251`, `0`, `30`, `0`, `0`, `0`, `0`, `178.122.42.238`);
INSERT INTO `sms_partners_two` VALUES(`252`, `0`, `30`, `0`, `0`, `0`, `0`, `141.138.102.240`);
INSERT INTO `sms_partners_two` VALUES(`253`, `0`, `30`, `0`, `0`, `0`, `0`, `79.172.124.251`);
INSERT INTO `sms_partners_two` VALUES(`254`, `0`, `0`, `0`, `0`, `0`, `0`, `79.172.124.251`);
INSERT INTO `sms_partners_two` VALUES(`255`, `0`, `30`, `0`, `0`, `0`, `0`, `46.42.45.56`);
INSERT INTO `sms_partners_two` VALUES(`256`, `0`, `30`, `0`, `0`, `0`, `0`, `193.111.241.71`);
INSERT INTO `sms_partners_two` VALUES(`257`, `0`, `30`, `0`, `0`, `0`, `0`, `92.127.20.29`);
INSERT INTO `sms_partners_two` VALUES(`258`, `0`, `30`, `0`, `0`, `0`, `0`, `109.227.97.101`);
INSERT INTO `sms_partners_two` VALUES(`259`, `0`, `30`, `0`, `0`, `0`, `0`, `92.113.61.239`);
INSERT INTO `sms_partners_two` VALUES(`260`, `0`, `30`, `0`, `0`, `0`, `0`, `212.2.141.86`);
INSERT INTO `sms_partners_two` VALUES(`261`, `0`, `30`, `0`, `0`, `0`, `0`, `178.120.202.198`);
INSERT INTO `sms_partners_two` VALUES(`262`, `0`, `30`, `0`, `0`, `0`, `0`, `31.13.144.16`);
INSERT INTO `sms_partners_two` VALUES(`263`, `0`, `0`, `0`, `0`, `0`, `0`, `92.100.176.62`);
INSERT INTO `sms_partners_two` VALUES(`264`, `0`, `30`, `0`, `0`, `0`, `0`, `217.15.26.242`);
INSERT INTO `sms_partners_two` VALUES(`265`, `0`, `30`, `0`, `0`, `0`, `0`, `195.189.105.147`);
INSERT INTO `sms_partners_two` VALUES(`266`, `0`, `30`, `0`, `0`, `0`, `0`, `31.128.184.65`);
INSERT INTO `sms_partners_two` VALUES(`267`, `0`, `30`, `0`, `0`, `0`, `0`, `212.80.37.211`);
INSERT INTO `sms_partners_two` VALUES(`268`, `0`, `30`, `0`, `0`, `0`, `0`, `93.100.183.170`);
INSERT INTO `sms_partners_two` VALUES(`269`, `0`, `30`, `0`, `0`, `0`, `0`, `94.248.48.209`);
INSERT INTO `sms_partners_two` VALUES(`270`, `0`, `30`, `0`, `0`, `0`, `0`, `195.58.7.169`);
INSERT INTO `sms_partners_two` VALUES(`271`, `0`, `30`, `0`, `0`, `0`, `0`, `178.150.155.241`);
INSERT INTO `sms_partners_two` VALUES(`272`, `0`, `30`, `0`, `0`, `0`, `0`, `31.9.40.132`);
INSERT INTO `sms_partners_two` VALUES(`273`, `0`, `30`, `0`, `0`, `0`, `0`, `85.238.109.131`);
INSERT INTO `sms_partners_two` VALUES(`274`, `0`, `30`, `0`, `0`, `0`, `0`, `46.174.67.16`);
INSERT INTO `sms_partners_two` VALUES(`275`, `0`, `30`, `0`, `0`, `0`, `0`, `178.204.91.20`);
INSERT INTO `sms_partners_two` VALUES(`276`, `0`, `30`, `0`, `0`, `0`, `0`, `78.137.52.234`);
INSERT INTO `sms_partners_two` VALUES(`277`, `0`, `30`, `0`, `0`, `0`, `0`, `46.247.217.12`);
INSERT INTO `sms_partners_two` VALUES(`278`, `0`, `30`, `0`, `0`, `0`, `0`, `37.212.53.37`);
INSERT INTO `sms_partners_two` VALUES(`279`, `0`, `30`, `0`, `0`, `0`, `0`, `85.173.165.198`);
INSERT INTO `sms_partners_two` VALUES(`280`, `0`, `30`, `0`, `0`, `0`, `0`, `194.126.180.178`);
INSERT INTO `sms_partners_two` VALUES(`281`, `0`, `30`, `0`, `0`, `0`, `0`, `92.112.251.205`);
INSERT INTO `sms_partners_two` VALUES(`282`, `0`, `30`, `0`, `0`, `0`, `0`, `109.232.188.28`);
INSERT INTO `sms_partners_two` VALUES(`283`, `0`, `30`, `0`, `0`, `0`, `0`, `83.139.161.254`);
INSERT INTO `sms_partners_two` VALUES(`284`, `0`, `30`, `0`, `0`, `0`, `0`, `178.150.207.233`);
INSERT INTO `sms_partners_two` VALUES(`285`, `0`, `30`, `0`, `0`, `0`, `0`, `159.224.237.157`);
INSERT INTO `sms_partners_two` VALUES(`286`, `0`, `30`, `0`, `0`, `0`, `0`, `176.52.52.227`);
INSERT INTO `sms_partners_two` VALUES(`287`, `0`, `30`, `0`, `0`, `0`, `0`, `178.178.43.192`);
INSERT INTO `sms_partners_two` VALUES(`288`, `0`, `30`, `0`, `0`, `0`, `0`, `46.120.56.27`);
INSERT INTO `sms_partners_two` VALUES(`289`, `0`, `30`, `0`, `0`, `0`, `0`, `46.201.182.144`);
INSERT INTO `sms_partners_two` VALUES(`290`, `0`, `30`, `0`, `0`, `0`, `0`, `89.28.74.192`);
INSERT INTO `sms_partners_two` VALUES(`291`, `0`, `30`, `0`, `0`, `0`, `0`, `94.179.198.96`);
INSERT INTO `sms_partners_two` VALUES(`292`, `0`, `30`, `0`, `0`, `0`, `0`, `109.126.247.101`);
INSERT INTO `sms_partners_two` VALUES(`293`, `0`, `30`, `0`, `0`, `0`, `0`, `85.26.234.215`);
INSERT INTO `sms_partners_two` VALUES(`294`, `0`, `30`, `0`, `0`, `0`, `0`, `95.132.112.188`);
INSERT INTO `sms_partners_two` VALUES(`295`, `0`, `30`, `0`, `0`, `0`, `0`, `46.175.186.129`);
INSERT INTO `sms_partners_two` VALUES(`296`, `0`, `30`, `0`, `0`, `0`, `0`, `87.117.37.193`);
INSERT INTO `sms_partners_two` VALUES(`297`, `0`, `30`, `0`, `0`, `0`, `0`, `178.75.126.195`);
INSERT INTO `sms_partners_two` VALUES(`298`, `0`, `30`, `0`, `0`, `0`, `0`, `178.90.88.207`);
INSERT INTO `sms_partners_two` VALUES(`299`, `0`, `30`, `0`, `0`, `0`, `0`, `81.17.157.140`);
INSERT INTO `sms_partners_two` VALUES(`300`, `0`, `30`, `0`, `0`, `0`, `0`, `37.110.211.15`);
INSERT INTO `sms_partners_two` VALUES(`301`, `0`, `30`, `0`, `0`, `0`, `0`, `92.113.199.220`);
INSERT INTO `sms_partners_two` VALUES(`302`, `0`, `30`, `0`, `0`, `0`, `0`, `217.118.81.9`);
INSERT INTO `sms_partners_two` VALUES(`303`, `0`, `30`, `0`, `0`, `0`, `0`, `46.247.163.175`);
INSERT INTO `sms_partners_two` VALUES(`304`, `0`, `30`, `0`, `0`, `0`, `0`, `77.120.29.199`);
INSERT INTO `sms_partners_two` VALUES(`305`, `0`, `30`, `0`, `0`, `0`, `0`, `94.179.7.154`);
INSERT INTO `sms_partners_two` VALUES(`306`, `0`, `30`, `0`, `0`, `0`, `0`, `194.8.156.108`);
INSERT INTO `sms_partners_two` VALUES(`307`, `0`, `30`, `0`, `0`, `0`, `0`, `79.165.42.77`);
INSERT INTO `sms_partners_two` VALUES(`308`, `0`, `30`, `0`, `0`, `0`, `0`, `194.44.213.186`);
INSERT INTO `sms_partners_two` VALUES(`309`, `0`, `30`, `0`, `0`, `0`, `0`, `178.70.170.97`);
INSERT INTO `sms_partners_two` VALUES(`310`, `0`, `30`, `0`, `0`, `0`, `0`, `178.122.62.75`);
INSERT INTO `sms_partners_two` VALUES(`311`, `0`, `30`, `0`, `0`, `0`, `0`, `88.206.38.155`);
INSERT INTO `sms_partners_two` VALUES(`312`, `0`, `30`, `0`, `0`, `0`, `0`, `212.2.236.72`);
INSERT INTO `sms_partners_two` VALUES(`313`, `0`, `30`, `0`, `0`, `0`, `0`, `95.58.70.112`);
INSERT INTO `sms_partners_two` VALUES(`314`, `0`, `30`, `0`, `0`, `0`, `0`, `77.122.138.177`);
INSERT INTO `sms_partners_two` VALUES(`315`, `0`, `30`, `0`, `0`, `0`, `0`, `178.122.108.109`);
INSERT INTO `sms_partners_two` VALUES(`316`, `0`, `30`, `0`, `0`, `0`, `0`, `95.58.170.48`);
INSERT INTO `sms_partners_two` VALUES(`317`, `0`, `30`, `0`, `0`, `0`, `0`, `95.25.168.146`);
INSERT INTO `sms_partners_two` VALUES(`318`, `0`, `30`, `0`, `0`, `0`, `0`, `178.127.154.208`);
INSERT INTO `sms_partners_two` VALUES(`319`, `0`, `30`, `0`, `0`, `0`, `0`, `188.231.174.192`);
INSERT INTO `sms_partners_two` VALUES(`320`, `39`, `30`, `0`, `20`, `10`, `0`, `86.106.234.136`);
INSERT INTO `sms_partners_two` VALUES(`321`, `0`, `30`, `0`, `0`, `0`, `0`, `78.153.4.49`);
INSERT INTO `sms_partners_two` VALUES(`322`, `0`, `30`, `0`, `0`, `0`, `0`, `217.118.95.94`);
INSERT INTO `sms_partners_two` VALUES(`323`, `0`, `30`, `0`, `0`, `0`, `0`, `195.66.79.192`);
INSERT INTO `sms_partners_two` VALUES(`324`, `0`, `30`, `0`, `0`, `0`, `0`, `2.133.190.116`);
INSERT INTO `sms_partners_two` VALUES(`325`, `0`, `30`, `0`, `0`, `0`, `0`, `176.107.213.151`);
INSERT INTO `sms_partners_two` VALUES(`326`, `0`, `30`, `0`, `0`, `0`, `0`, `46.241.228.72`);
INSERT INTO `sms_partners_two` VALUES(`327`, `0`, `30`, `0`, `0`, `0`, `0`, `94.179.201.55`);
INSERT INTO `sms_partners_two` VALUES(`328`, `0`, `30`, `0`, `0`, `0`, `0`, `178.214.175.127`);
INSERT INTO `sms_partners_two` VALUES(`329`, `0`, `30`, `0`, `0`, `0`, `0`, `91.218.33.65`);
INSERT INTO `sms_partners_two` VALUES(`330`, `0`, `30`, `0`, `0`, `0`, `0`, `213.87.122.203`);
INSERT INTO `sms_partners_two` VALUES(`331`, `0`, `30`, `0`, `0`, `0`, `0`, `46.118.47.243`);
INSERT INTO `sms_partners_two` VALUES(`332`, `0`, `30`, `0`, `0`, `0`, `0`, `188.233.157.12`);
INSERT INTO `sms_partners_two` VALUES(`333`, `0`, `30`, `0`, `0`, `0`, `0`, `109.174.112.92`);
INSERT INTO `sms_partners_two` VALUES(`334`, `0`, `30`, `0`, `0`, `0`, `0`, `91.216.28.115`);
INSERT INTO `sms_partners_two` VALUES(`335`, `0`, `30`, `0`, `0`, `0`, `0`, `178.98.42.229`);
INSERT INTO `sms_partners_two` VALUES(`336`, `0`, `30`, `0`, `0`, `0`, `0`, `178.90.226.223`);
INSERT INTO `sms_partners_two` VALUES(`337`, `0`, `30`, `0`, `0`, `0`, `0`, `178.121.60.162`);
INSERT INTO `sms_partners_two` VALUES(`338`, `0`, `30`, `0`, `0`, `0`, `0`, `218.234.218.136`);
INSERT INTO `sms_partners_two` VALUES(`339`, `0`, `30`, `0`, `0`, `0`, `0`, `46.174.246.109`);
INSERT INTO `sms_partners_two` VALUES(`340`, `0`, `30`, `0`, `0`, `0`, `0`, `62.122.60.4`);
INSERT INTO `sms_partners_two` VALUES(`341`, `0`, `30`, `0`, `0`, `0`, `0`, `31.163.224.108`);
INSERT INTO `sms_partners_two` VALUES(`342`, `0`, `30`, `0`, `0`, `0`, `0`, `80.93.118.177`);
INSERT INTO `sms_partners_two` VALUES(`343`, `0`, `30`, `0`, `0`, `0`, `0`, `78.137.29.149`);
INSERT INTO `sms_partners_two` VALUES(`344`, `0`, `30`, `0`, `0`, `0`, `0`, `66.249.71.249`);
INSERT INTO `sms_partners_two` VALUES(`345`, `0`, `30`, `0`, `0`, `0`, `0`, `92.112.29.20`);
INSERT INTO `sms_partners_two` VALUES(`346`, `0`, `30`, `0`, `0`, `0`, `0`, `95.134.18.236`);
INSERT INTO `sms_partners_two` VALUES(`347`, `0`, `30`, `0`, `0`, `0`, `0`, `95.57.54.107`);
INSERT INTO `sms_partners_two` VALUES(`348`, `0`, `30`, `0`, `0`, `0`, `0`, `178.122.44.124`);
INSERT INTO `sms_partners_two` VALUES(`349`, `0`, `30`, `0`, `0`, `0`, `0`, `178.209.82.11`);
INSERT INTO `sms_partners_two` VALUES(`350`, `0`, `30`, `0`, `0`, `0`, `0`, `46.201.196.182`);
INSERT INTO `sms_partners_two` VALUES(`351`, `0`, `30`, `0`, `0`, `0`, `0`, `93.124.111.178`);
INSERT INTO `sms_partners_two` VALUES(`352`, `0`, `30`, `0`, `0`, `0`, `0`, `46.187.105.82`);
INSERT INTO `sms_partners_two` VALUES(`353`, `0`, `30`, `0`, `0`, `0`, `0`, `77.109.9.11`);
INSERT INTO `sms_partners_two` VALUES(`354`, `0`, `30`, `0`, `0`, `0`, `0`, `176.212.3.56`);
INSERT INTO `sms_partners_two` VALUES(`355`, `0`, `30`, `0`, `0`, `0`, `0`, `178.177.238.64`);
INSERT INTO `sms_partners_two` VALUES(`356`, `0`, `30`, `0`, `0`, `0`, `0`, `217.114.229.168`);
INSERT INTO `sms_partners_two` VALUES(`357`, `0`, `30`, `0`, `0`, `0`, `0`, `95.135.57.219`);
INSERT INTO `sms_partners_two` VALUES(`358`, `0`, `30`, `0`, `0`, `0`, `0`, `88.191.144.69`);
INSERT INTO `sms_partners_two` VALUES(`359`, `0`, `30`, `0`, `0`, `0`, `0`, `213.109.3.203`);
INSERT INTO `sms_partners_two` VALUES(`360`, `0`, `30`, `0`, `0`, `0`, `0`, `79.165.40.98`);
INSERT INTO `sms_partners_two` VALUES(`361`, `0`, `30`, `0`, `0`, `0`, `0`, `178.127.183.220`);
INSERT INTO `sms_partners_two` VALUES(`362`, `0`, `30`, `0`, `0`, `0`, `0`, `178.171.119.171`);
INSERT INTO `sms_partners_two` VALUES(`363`, `0`, `30`, `0`, `0`, `0`, `0`, `93.85.152.114`);
INSERT INTO `sms_partners_two` VALUES(`364`, `0`, `30`, `0`, `0`, `0`, `0`, `109.104.191.178`);
INSERT INTO `sms_partners_two` VALUES(`365`, `34`, `30`, `0`, `20`, `10`, `0`, `93.79.155.229`);
INSERT INTO `sms_partners_two` VALUES(`366`, `0`, `30`, `0`, `0`, `0`, `0`, `109.86.56.4`);
INSERT INTO `sms_partners_two` VALUES(`367`, `0`, `30`, `0`, `0`, `0`, `0`, `77.45.144.107`);
INSERT INTO `sms_partners_two` VALUES(`368`, `0`, `30`, `0`, `0`, `0`, `0`, `93.186.101.239`);
INSERT INTO `sms_partners_two` VALUES(`369`, `0`, `30`, `0`, `0`, `0`, `0`, `178.219.56.49`);
INSERT INTO `sms_partners_two` VALUES(`370`, `0`, `30`, `0`, `0`, `0`, `0`, `178.121.129.245`);
INSERT INTO `sms_partners_two` VALUES(`371`, `0`, `30`, `0`, `0`, `0`, `0`, `88.84.205.147`);
INSERT INTO `sms_partners_two` VALUES(`372`, `0`, `30`, `0`, `0`, `0`, `0`, `212.113.47.90`);
INSERT INTO `sms_partners_two` VALUES(`373`, `0`, `30`, `0`, `0`, `0`, `0`, `178.150.252.24`);
INSERT INTO `sms_partners_two` VALUES(`374`, `0`, `30`, `0`, `0`, `0`, `0`, `95.133.131.163`);
INSERT INTO `sms_partners_two` VALUES(`375`, `0`, `30`, `0`, `0`, `0`, `0`, `31.129.194.10`);
INSERT INTO `sms_partners_two` VALUES(`376`, `0`, `30`, `0`, `0`, `0`, `0`, `31.202.197.83`);
INSERT INTO `sms_partners_two` VALUES(`377`, `0`, `30`, `0`, `0`, `0`, `0`, `46.172.212.119`);
INSERT INTO `sms_partners_two` VALUES(`378`, `0`, `30`, `0`, `0`, `0`, `0`, `46.158.63.237`);
INSERT INTO `sms_partners_two` VALUES(`379`, `0`, `30`, `0`, `0`, `0`, `0`, `91.221.65.6`);
INSERT INTO `sms_partners_two` VALUES(`380`, `0`, `30`, `0`, `0`, `0`, `0`, `95.135.115.106`);
INSERT INTO `sms_partners_two` VALUES(`381`, `0`, `30`, `0`, `0`, `0`, `0`, `188.237.33.30`);
INSERT INTO `sms_partners_two` VALUES(`382`, `0`, `30`, `0`, `0`, `0`, `0`, `89.185.29.66`);
INSERT INTO `sms_partners_two` VALUES(`383`, `0`, `30`, `0`, `0`, `0`, `0`, `2.60.74.11`);
INSERT INTO `sms_partners_two` VALUES(`384`, `0`, `30`, `0`, `0`, `0`, `0`, `178.125.232.78`);
INSERT INTO `sms_partners_two` VALUES(`385`, `0`, `30`, `0`, `0`, `0`, `0`, `109.197.112.91`);
INSERT INTO `sms_partners_two` VALUES(`386`, `0`, `30`, `0`, `0`, `0`, `0`, `79.142.91.72`);
INSERT INTO `sms_partners_two` VALUES(`387`, `0`, `30`, `0`, `0`, `0`, `0`, `217.175.5.72`);
INSERT INTO `sms_partners_two` VALUES(`388`, `0`, `30`, `0`, `0`, `0`, `0`, `188.122.239.150`);
INSERT INTO `sms_partners_two` VALUES(`389`, `0`, `30`, `0`, `0`, `0`, `0`, `78.57.177.53`);
INSERT INTO `sms_partners_two` VALUES(`390`, `0`, `30`, `0`, `0`, `0`, `0`, `109.200.159.193`);
INSERT INTO `sms_partners_two` VALUES(`391`, `0`, `30`, `0`, `0`, `0`, `0`, `194.177.25.23`);
INSERT INTO `sms_partners_two` VALUES(`392`, `0`, `30`, `0`, `0`, `0`, `0`, `91.225.88.117`);
INSERT INTO `sms_partners_two` VALUES(`393`, `0`, `30`, `0`, `0`, `0`, `0`, `178.64.34.237`);
INSERT INTO `sms_partners_two` VALUES(`394`, `0`, `30`, `0`, `0`, `0`, `0`, `89.189.191.26`);
INSERT INTO `sms_partners_two` VALUES(`395`, `0`, `30`, `0`, `0`, `0`, `0`, `94.248.120.232`);
INSERT INTO `sms_partners_two` VALUES(`396`, `0`, `30`, `0`, `0`, `0`, `0`, `109.225.30.70`);
INSERT INTO `sms_partners_two` VALUES(`397`, `0`, `30`, `0`, `0`, `0`, `0`, `217.118.93.103`);
INSERT INTO `sms_partners_two` VALUES(`398`, `0`, `30`, `0`, `0`, `0`, `0`, `95.188.153.225`);
INSERT INTO `sms_partners_two` VALUES(`399`, `0`, `30`, `0`, `0`, `0`, `0`, `192.162.40.151`);
INSERT INTO `sms_partners_two` VALUES(`400`, `0`, `30`, `0`, `0`, `0`, `0`, `95.54.213.46`);
INSERT INTO `sms_partners_two` VALUES(`401`, `0`, `30`, `0`, `0`, `0`, `0`, `188.32.192.165`);
INSERT INTO `sms_partners_two` VALUES(`402`, `0`, `30`, `0`, `0`, `0`, `0`, `46.241.84.189`);
INSERT INTO `sms_partners_two` VALUES(`403`, `0`, `30`, `0`, `0`, `0`, `0`, `37.17.178.219`);
INSERT INTO `sms_partners_two` VALUES(`404`, `0`, `30`, `0`, `0`, `0`, `0`, `178.126.201.117`);
INSERT INTO `sms_partners_two` VALUES(`405`, `0`, `30`, `0`, `0`, `0`, `0`, `178.121.148.179`);
INSERT INTO `sms_partners_two` VALUES(`406`, `0`, `30`, `0`, `0`, `0`, `0`, `46.55.20.94`);
INSERT INTO `sms_partners_two` VALUES(`407`, `0`, `30`, `0`, `0`, `0`, `0`, `89.149.126.9`);
INSERT INTO `sms_partners_two` VALUES(`408`, `0`, `30`, `0`, `0`, `0`, `0`, `178.252.103.245`);
INSERT INTO `sms_partners_two` VALUES(`409`, `0`, `30`, `0`, `0`, `0`, `0`, `178.78.185.157`);
INSERT INTO `sms_partners_two` VALUES(`410`, `0`, `30`, `0`, `0`, `0`, `0`, `78.140.61.108`);
INSERT INTO `sms_partners_two` VALUES(`411`, `0`, `30`, `0`, `0`, `0`, `0`, `178.121.169.30`);
INSERT INTO `sms_partners_two` VALUES(`412`, `0`, `30`, `0`, `0`, `0`, `0`, `109.184.82.203`);
INSERT INTO `sms_partners_two` VALUES(`413`, `0`, `30`, `0`, `0`, `0`, `0`, `95.57.236.241`);
INSERT INTO `sms_partners_two` VALUES(`414`, `0`, `30`, `0`, `0`, `0`, `0`, `2.132.108.67`);
INSERT INTO `sms_partners_two` VALUES(`415`, `0`, `30`, `0`, `0`, `0`, `0`, `78.106.41.61`);
INSERT INTO `sms_partners_two` VALUES(`416`, `0`, `30`, `0`, `0`, `0`, `0`, `89.163.89.148`);
INSERT INTO `sms_partners_two` VALUES(`417`, `0`, `30`, `0`, `0`, `0`, `0`, `192.162.135.254`);
INSERT INTO `sms_partners_two` VALUES(`418`, `0`, `30`, `0`, `0`, `0`, `0`, `178.123.210.43`);
INSERT INTO `sms_partners_two` VALUES(`419`, `0`, `30`, `0`, `0`, `0`, `0`, `109.104.181.133`);
INSERT INTO `sms_partners_two` VALUES(`420`, `0`, `30`, `0`, `0`, `0`, `0`, `85.26.231.74`);
INSERT INTO `sms_partners_two` VALUES(`421`, `0`, `30`, `0`, `0`, `0`, `0`, `130.0.32.121`);
INSERT INTO `sms_partners_two` VALUES(`422`, `0`, `30`, `0`, `0`, `0`, `0`, `37.212.28.190`);
INSERT INTO `sms_partners_two` VALUES(`423`, `0`, `30`, `0`, `0`, `0`, `0`, `95.139.76.124`);
INSERT INTO `sms_partners_two` VALUES(`424`, `0`, `30`, `0`, `0`, `0`, `0`, `79.132.97.108`);
INSERT INTO `sms_partners_two` VALUES(`425`, `0`, `30`, `0`, `0`, `0`, `0`, `178.91.81.23`);
INSERT INTO `sms_partners_two` VALUES(`426`, `0`, `30`, `0`, `0`, `0`, `0`, `92.46.227.52`);
INSERT INTO `sms_partners_two` VALUES(`427`, `0`, `30`, `0`, `0`, `0`, `0`, `95.134.183.48`);
INSERT INTO `sms_partners_two` VALUES(`428`, `0`, `30`, `0`, `0`, `0`, `0`, `178.122.181.196`);
INSERT INTO `sms_partners_two` VALUES(`429`, `0`, `30`, `0`, `0`, `0`, `0`, `92.113.215.246`);
INSERT INTO `sms_partners_two` VALUES(`430`, `0`, `30`, `0`, `0`, `0`, `0`, `178.74.208.178`);
INSERT INTO `sms_partners_two` VALUES(`431`, `0`, `30`, `0`, `0`, `0`, `0`, `79.140.229.239`);
INSERT INTO `sms_partners_two` VALUES(`432`, `0`, `30`, `0`, `0`, `0`, `0`, `94.241.37.134`);
INSERT INTO `sms_partners_two` VALUES(`433`, `0`, `30`, `0`, `0`, `0`, `0`, `37.19.154.109`);
INSERT INTO `sms_partners_two` VALUES(`434`, `0`, `30`, `0`, `0`, `0`, `0`, `178.137.92.235`);
INSERT INTO `sms_partners_two` VALUES(`435`, `0`, `30`, `0`, `0`, `0`, `0`, `81.163.30.8`);
INSERT INTO `sms_partners_two` VALUES(`436`, `0`, `30`, `0`, `0`, `0`, `0`, `91.207.27.15`);
INSERT INTO `sms_partners_two` VALUES(`437`, `0`, `30`, `0`, `0`, `0`, `0`, `2.60.151.84`);
INSERT INTO `sms_partners_two` VALUES(`438`, `0`, `30`, `0`, `0`, `0`, `0`, `188.226.50.142`);
INSERT INTO `sms_partners_two` VALUES(`439`, `0`, `30`, `0`, `0`, `0`, `0`, `178.123.54.207`);
INSERT INTO `sms_partners_two` VALUES(`440`, `0`, `30`, `0`, `0`, `0`, `0`, `95.190.119.104`);
INSERT INTO `sms_partners_two` VALUES(`441`, `0`, `30`, `0`, `0`, `0`, `0`, `178.94.3.1`);
INSERT INTO `sms_partners_two` VALUES(`442`, `0`, `30`, `0`, `0`, `0`, `0`, `46.73.189.160`);
INSERT INTO `sms_partners_two` VALUES(`443`, `0`, `30`, `0`, `0`, `0`, `0`, `188.187.48.62`);
INSERT INTO `sms_partners_two` VALUES(`444`, `0`, `30`, `0`, `0`, `0`, `0`, `178.123.218.220`);
INSERT INTO `sms_partners_two` VALUES(`445`, `0`, `30`, `0`, `0`, `0`, `0`, `46.187.6.7`);
INSERT INTO `sms_partners_two` VALUES(`446`, `0`, `30`, `0`, `0`, `0`, `0`, `217.118.83.163`);
INSERT INTO `sms_partners_two` VALUES(`447`, `0`, `30`, `0`, `0`, `0`, `0`, `91.209.51.130`);
INSERT INTO `sms_partners_two` VALUES(`448`, `0`, `30`, `0`, `0`, `0`, `0`, `93.170.153.211`);
INSERT INTO `sms_partners_two` VALUES(`449`, `0`, `30`, `0`, `0`, `0`, `0`, `62.84.49.226`);
INSERT INTO `sms_partners_two` VALUES(`450`, `0`, `30`, `0`, `0`, `0`, `0`, `46.201.158.132`);
INSERT INTO `sms_partners_two` VALUES(`451`, `0`, `30`, `0`, `0`, `0`, `0`, `109.68.234.4`);
INSERT INTO `sms_partners_two` VALUES(`452`, `0`, `30`, `0`, `0`, `0`, `0`, `94.51.76.53`);
INSERT INTO `sms_partners_two` VALUES(`453`, `0`, `30`, `0`, `0`, `0`, `0`, `37.212.100.132`);
INSERT INTO `sms_partners_two` VALUES(`454`, `0`, `30`, `0`, `0`, `0`, `0`, `109.165.84.48`);
INSERT INTO `sms_partners_two` VALUES(`455`, `0`, `30`, `0`, `0`, `0`, `0`, `95.153.180.68`);
INSERT INTO `sms_partners_two` VALUES(`456`, `0`, `30`, `0`, `0`, `0`, `0`, `94.244.32.223`);
INSERT INTO `sms_partners_two` VALUES(`457`, `0`, `30`, `0`, `0`, `0`, `0`, `95.37.48.212`);
INSERT INTO `sms_partners_two` VALUES(`458`, `0`, `30`, `0`, `0`, `0`, `0`, `93.85.129.249`);
INSERT INTO `sms_partners_two` VALUES(`459`, `0`, `30`, `0`, `0`, `0`, `0`, `178.95.43.27`);
INSERT INTO `sms_partners_two` VALUES(`460`, `0`, `30`, `0`, `0`, `0`, `0`, `178.20.129.199`);
INSERT INTO `sms_partners_two` VALUES(`461`, `0`, `30`, `0`, `0`, `0`, `0`, `178.134.54.54`);
INSERT INTO `sms_partners_two` VALUES(`462`, `0`, `30`, `0`, `0`, `0`, `0`, `178.90.26.254`);
INSERT INTO `sms_partners_two` VALUES(`463`, `0`, `30`, `0`, `0`, `0`, `0`, `77.38.202.47`);
INSERT INTO `sms_partners_two` VALUES(`464`, `0`, `30`, `0`, `0`, `0`, `0`, `37.55.61.196`);
INSERT INTO `sms_partners_two` VALUES(`465`, `0`, `30`, `0`, `0`, `0`, `0`, `176.8.189.131`);
INSERT INTO `sms_partners_two` VALUES(`466`, `0`, `30`, `0`, `0`, `0`, `0`, `77.122.215.113`);
INSERT INTO `sms_partners_two` VALUES(`467`, `0`, `30`, `0`, `0`, `0`, `0`, `213.87.137.10`);
INSERT INTO `sms_partners_two` VALUES(`468`, `0`, `30`, `0`, `0`, `0`, `0`, `217.79.26.80`);
INSERT INTO `sms_partners_two` VALUES(`469`, `0`, `30`, `0`, `0`, `0`, `0`, `193.34.86.42`);
INSERT INTO `sms_partners_two` VALUES(`470`, `0`, `30`, `0`, `0`, `0`, `0`, `188.230.56.244`);
INSERT INTO `sms_partners_two` VALUES(`471`, `0`, `30`, `0`, `0`, `0`, `0`, `91.200.137.72`);
INSERT INTO `sms_partners_two` VALUES(`472`, `0`, `30`, `0`, `0`, `0`, `0`, `31.23.4.18`);
INSERT INTO `sms_partners_two` VALUES(`473`, `0`, `30`, `0`, `0`, `0`, `0`, `77.122.91.162`);
INSERT INTO `sms_partners_two` VALUES(`474`, `0`, `30`, `0`, `0`, `0`, `0`, `83.149.3.237`);
INSERT INTO `sms_partners_two` VALUES(`475`, `0`, `30`, `0`, `0`, `0`, `0`, `46.70.34.163`);
INSERT INTO `sms_partners_two` VALUES(`476`, `0`, `30`, `0`, `0`, `0`, `0`, `178.91.8.5`);
INSERT INTO `sms_partners_two` VALUES(`477`, `0`, `30`, `0`, `0`, `0`, `0`, `31.42.224.76`);
INSERT INTO `sms_partners_two` VALUES(`478`, `0`, `30`, `0`, `0`, `0`, `0`, `2.132.1.198`);
INSERT INTO `sms_partners_two` VALUES(`479`, `0`, `30`, `0`, `0`, `0`, `0`, `46.70.119.124`);
INSERT INTO `sms_partners_two` VALUES(`480`, `0`, `30`, `0`, `0`, `0`, `0`, `78.106.70.100`);
INSERT INTO `sms_partners_two` VALUES(`481`, `0`, `30`, `0`, `0`, `0`, `0`, `37.212.82.167`);
INSERT INTO `sms_partners_two` VALUES(`482`, `0`, `30`, `0`, `0`, `0`, `0`, `91.144.150.202`);
INSERT INTO `sms_partners_two` VALUES(`483`, `0`, `30`, `0`, `0`, `0`, `0`, `82.145.208.196`);
INSERT INTO `sms_partners_two` VALUES(`484`, `0`, `30`, `0`, `0`, `0`, `0`, `31.162.72.125`);
INSERT INTO `sms_partners_two` VALUES(`485`, `0`, `30`, `0`, `0`, `0`, `0`, `178.137.167.245`);
INSERT INTO `sms_partners_two` VALUES(`486`, `0`, `30`, `0`, `0`, `0`, `0`, `95.106.115.223`);
INSERT INTO `sms_partners_two` VALUES(`487`, `0`, `30`, `0`, `0`, `0`, `0`, `178.93.8.139`);
INSERT INTO `sms_partners_two` VALUES(`488`, `0`, `30`, `0`, `0`, `0`, `0`, `178.212.247.73`);
INSERT INTO `sms_partners_two` VALUES(`489`, `0`, `30`, `0`, `0`, `0`, `0`, `178.120.113.213`);
INSERT INTO `sms_partners_two` VALUES(`490`, `0`, `30`, `0`, `0`, `0`, `0`, `176.52.1.80`);
INSERT INTO `sms_partners_two` VALUES(`491`, `0`, `30`, `0`, `0`, `0`, `0`, `37.45.170.120`);
INSERT INTO `sms_partners_two` VALUES(`492`, `0`, `30`, `0`, `0`, `0`, `0`, `95.158.39.36`);
INSERT INTO `sms_partners_two` VALUES(`493`, `0`, `30`, `0`, `0`, `0`, `0`, `82.145.208.129`);
INSERT INTO `sms_partners_two` VALUES(`494`, `0`, `30`, `0`, `0`, `0`, `0`, `213.87.128.186`);
INSERT INTO `sms_partners_two` VALUES(`495`, `0`, `30`, `0`, `0`, `0`, `0`, `94.43.28.14`);
INSERT INTO `sms_partners_two` VALUES(`496`, `0`, `30`, `0`, `0`, `0`, `0`, `46.33.238.156`);
INSERT INTO `sms_partners_two` VALUES(`497`, `0`, `30`, `0`, `0`, `0`, `0`, `95.43.61.177`);
INSERT INTO `sms_partners_two` VALUES(`498`, `0`, `30`, `0`, `0`, `0`, `0`, `90.130.190.255`);
INSERT INTO `sms_partners_two` VALUES(`499`, `0`, `30`, `0`, `0`, `0`, `0`, `92.43.189.15`);
INSERT INTO `sms_partners_two` VALUES(`500`, `0`, `30`, `0`, `0`, `0`, `0`, `83.149.44.249`);
INSERT INTO `sms_partners_two` VALUES(`501`, `0`, `30`, `0`, `0`, `0`, `0`, `31.180.229.164`);
INSERT INTO `sms_partners_two` VALUES(`502`, `0`, `30`, `0`, `0`, `0`, `0`, `93.171.105.102`);
INSERT INTO `sms_partners_two` VALUES(`503`, `0`, `30`, `0`, `0`, `0`, `0`, `178.187.255.98`);
INSERT INTO `sms_partners_two` VALUES(`504`, `0`, `30`, `0`, `0`, `0`, `0`, `90.150.223.222`);
INSERT INTO `sms_partners_two` VALUES(`505`, `0`, `30`, `0`, `0`, `0`, `0`, `84.109.9.92`);
INSERT INTO `sms_partners_two` VALUES(`506`, `0`, `30`, `0`, `0`, `0`, `0`, `46.147.234.65`);
INSERT INTO `sms_partners_two` VALUES(`507`, `0`, `30`, `0`, `0`, `0`, `0`, `188.233.165.193`);
INSERT INTO `sms_partners_two` VALUES(`508`, `0`, `30`, `0`, `0`, `0`, `0`, `92.47.93.87`);
INSERT INTO `sms_partners_two` VALUES(`509`, `0`, `30`, `0`, `0`, `0`, `0`, `95.111.178.158`);
INSERT INTO `sms_partners_two` VALUES(`510`, `0`, `30`, `0`, `0`, `0`, `0`, `109.201.118.198`);
INSERT INTO `sms_partners_two` VALUES(`511`, `0`, `30`, `0`, `0`, `0`, `0`, `79.133.150.214`);
INSERT INTO `sms_partners_two` VALUES(`512`, `0`, `30`, `0`, `0`, `0`, `0`, `92.46.248.148`);
INSERT INTO `sms_partners_two` VALUES(`513`, `0`, `30`, `0`, `0`, `0`, `0`, `31.41.81.14`);
INSERT INTO `sms_partners_two` VALUES(`514`, `0`, `30`, `0`, `0`, `0`, `0`, `90.191.182.98`);
INSERT INTO `sms_partners_two` VALUES(`515`, `0`, `30`, `0`, `0`, `0`, `0`, `77.122.123.242`);
INSERT INTO `sms_partners_two` VALUES(`516`, `0`, `30`, `0`, `0`, `0`, `0`, `93.155.181.3`);
INSERT INTO `sms_partners_two` VALUES(`517`, `0`, `30`, `0`, `0`, `0`, `0`, `88.200.207.100`);
INSERT INTO `sms_partners_two` VALUES(`518`, `0`, `30`, `0`, `0`, `0`, `0`, `85.26.164.57`);
INSERT INTO `sms_partners_two` VALUES(`519`, `0`, `30`, `0`, `0`, `0`, `0`, `130.255.137.223`);
INSERT INTO `sms_partners_two` VALUES(`520`, `0`, `30`, `0`, `0`, `0`, `0`, `188.235.230.182`);
INSERT INTO `sms_partners_two` VALUES(`521`, `0`, `30`, `0`, `0`, `0`, `0`, `31.192.236.77`);
INSERT INTO `sms_partners_two` VALUES(`522`, `0`, `30`, `0`, `0`, `0`, `0`, `83.149.35.124`);
INSERT INTO `sms_partners_two` VALUES(`523`, `0`, `30`, `0`, `0`, `0`, `0`, `178.121.182.246`);
INSERT INTO `sms_partners_two` VALUES(`524`, `0`, `30`, `0`, `0`, `0`, `0`, `91.229.55.173`);
INSERT INTO `sms_partners_two` VALUES(`525`, `0`, `30`, `0`, `0`, `0`, `0`, `95.220.227.116`);
INSERT INTO `sms_partners_two` VALUES(`526`, `0`, `30`, `0`, `0`, `0`, `0`, `109.172.40.166`);
INSERT INTO `sms_partners_two` VALUES(`527`, `0`, `30`, `0`, `0`, `0`, `0`, `37.110.57.127`);
INSERT INTO `sms_partners_two` VALUES(`528`, `0`, `30`, `0`, `0`, `0`, `0`, `95.54.27.92`);
INSERT INTO `sms_partners_two` VALUES(`529`, `0`, `30`, `0`, `0`, `0`, `0`, `77.123.29.79`);
INSERT INTO `sms_partners_two` VALUES(`530`, `0`, `30`, `0`, `0`, `0`, `0`, `95.72.154.247`);
INSERT INTO `sms_partners_two` VALUES(`531`, `0`, `30`, `0`, `0`, `0`, `0`, `194.44.177.2`);
INSERT INTO `sms_partners_two` VALUES(`532`, `0`, `30`, `0`, `0`, `0`, `0`, `84.54.111.177`);
INSERT INTO `sms_partners_two` VALUES(`533`, `0`, `30`, `0`, `0`, `0`, `0`, `46.39.37.13`);
INSERT INTO `sms_partners_two` VALUES(`534`, `0`, `30`, `0`, `0`, `0`, `0`, `109.167.207.22`);
INSERT INTO `sms_partners_two` VALUES(`535`, `0`, `30`, `0`, `0`, `0`, `0`, `31.28.240.228`);
INSERT INTO `sms_partners_two` VALUES(`536`, `0`, `30`, `0`, `0`, `0`, `0`, `89.179.106.94`);
INSERT INTO `sms_partners_two` VALUES(`537`, `0`, `30`, `0`, `0`, `0`, `0`, `178.122.26.140`);
INSERT INTO `sms_partners_two` VALUES(`538`, `0`, `30`, `0`, `0`, `0`, `0`, `91.200.235.214`);
INSERT INTO `sms_partners_two` VALUES(`539`, `0`, `30`, `0`, `0`, `0`, `0`, `37.52.2.61`);
INSERT INTO `sms_partners_two` VALUES(`540`, `0`, `30`, `0`, `0`, `0`, `0`, `92.112.232.73`);
INSERT INTO `sms_partners_two` VALUES(`541`, `0`, `30`, `0`, `0`, `0`, `0`, `91.76.92.91`);
INSERT INTO `sms_partners_two` VALUES(`542`, `0`, `30`, `0`, `0`, `0`, `0`, `92.47.163.252`);
INSERT INTO `sms_partners_two` VALUES(`543`, `0`, `30`, `0`, `0`, `0`, `0`, `78.138.166.0`);
INSERT INTO `sms_partners_two` VALUES(`544`, `0`, `30`, `0`, `0`, `0`, `0`, `37.213.20.237`);
INSERT INTO `sms_partners_two` VALUES(`545`, `0`, `30`, `0`, `0`, `0`, `0`, `46.98.196.168`);
INSERT INTO `sms_partners_two` VALUES(`546`, `0`, `30`, `0`, `0`, `0`, `0`, `94.137.19.250`);
INSERT INTO `sms_partners_two` VALUES(`547`, `0`, `30`, `0`, `0`, `0`, `0`, `178.120.151.166`);
INSERT INTO `sms_partners_two` VALUES(`548`, `0`, `30`, `0`, `0`, `0`, `0`, `178.123.23.14`);
INSERT INTO `sms_partners_two` VALUES(`549`, `0`, `30`, `0`, `0`, `0`, `0`, `176.214.87.223`);
INSERT INTO `sms_partners_two` VALUES(`550`, `0`, `30`, `0`, `0`, `0`, `0`, `37.55.6.113`);
INSERT INTO `sms_partners_two` VALUES(`551`, `0`, `30`, `0`, `0`, `0`, `0`, `176.222.161.246`);
INSERT INTO `sms_partners_two` VALUES(`552`, `0`, `30`, `0`, `0`, `0`, `0`, `195.16.79.89`);
INSERT INTO `sms_partners_two` VALUES(`553`, `0`, `30`, `0`, `0`, `0`, `0`, `93.73.194.41`);
INSERT INTO `sms_partners_two` VALUES(`554`, `0`, `30`, `0`, `0`, `0`, `0`, `178.213.1.157`);
INSERT INTO `sms_partners_two` VALUES(`555`, `0`, `30`, `0`, `0`, `0`, `0`, `178.151.17.17`);
INSERT INTO `sms_partners_two` VALUES(`556`, `0`, `30`, `0`, `0`, `0`, `0`, `109.201.216.83`);
INSERT INTO `sms_partners_two` VALUES(`557`, `0`, `30`, `0`, `0`, `0`, `0`, `94.241.250.106`);
INSERT INTO `sms_partners_two` VALUES(`558`, `0`, `30`, `0`, `0`, `0`, `0`, `88.206.61.249`);
INSERT INTO `sms_partners_two` VALUES(`559`, `0`, `30`, `0`, `0`, `0`, `0`, `92.100.30.155`);
INSERT INTO `sms_partners_two` VALUES(`560`, `0`, `30`, `0`, `0`, `0`, `0`, `128.73.165.77`);
INSERT INTO `sms_partners_two` VALUES(`561`, `0`, `30`, `0`, `0`, `0`, `0`, `178.127.179.216`);
INSERT INTO `sms_partners_two` VALUES(`562`, `0`, `30`, `0`, `0`, `0`, `0`, `31.23.156.13`);
INSERT INTO `sms_partners_two` VALUES(`563`, `0`, `30`, `0`, `0`, `0`, `0`, `193.104.208.34`);
INSERT INTO `sms_partners_two` VALUES(`564`, `0`, `30`, `0`, `0`, `0`, `0`, `93.180.229.181`);
INSERT INTO `sms_partners_two` VALUES(`565`, `0`, `30`, `0`, `0`, `0`, `0`, `188.17.65.236`);
INSERT INTO `sms_partners_two` VALUES(`566`, `0`, `30`, `0`, `0`, `0`, `0`, `178.155.31.127`);
INSERT INTO `sms_partners_two` VALUES(`567`, `0`, `30`, `0`, `0`, `0`, `0`, `89.178.87.237`);
INSERT INTO `sms_partners_two` VALUES(`568`, `0`, `30`, `0`, `0`, `0`, `0`, `178.126.136.191`);
INSERT INTO `sms_partners_two` VALUES(`569`, `0`, `30`, `0`, `0`, `0`, `0`, `95.135.186.8`);
INSERT INTO `sms_partners_two` VALUES(`570`, `0`, `30`, `0`, `0`, `0`, `0`, `83.218.199.254`);
INSERT INTO `sms_partners_two` VALUES(`571`, `0`, `30`, `0`, `0`, `0`, `0`, `31.23.213.157`);
INSERT INTO `sms_partners_two` VALUES(`572`, `0`, `30`, `0`, `0`, `0`, `0`, `94.179.12.168`);
INSERT INTO `sms_partners_two` VALUES(`573`, `0`, `30`, `0`, `0`, `0`, `0`, `176.8.214.113`);
INSERT INTO `sms_partners_two` VALUES(`574`, `0`, `30`, `0`, `0`, `0`, `0`, `92.112.209.32`);
INSERT INTO `sms_partners_two` VALUES(`575`, `0`, `30`, `0`, `0`, `0`, `0`, `92.112.220.69`);
INSERT INTO `sms_partners_two` VALUES(`576`, `0`, `30`, `0`, `0`, `0`, `0`, `109.207.181.22`);
INSERT INTO `sms_partners_two` VALUES(`577`, `0`, `30`, `0`, `0`, `0`, `0`, `95.137.149.65`);
INSERT INTO `sms_partners_two` VALUES(`578`, `0`, `30`, `0`, `0`, `0`, `0`, `46.147.88.21`);
INSERT INTO `sms_partners_two` VALUES(`579`, `0`, `30`, `0`, `0`, `0`, `0`, `92.36.101.251`);
INSERT INTO `sms_partners_two` VALUES(`580`, `0`, `30`, `0`, `0`, `0`, `0`, `213.87.139.118`);
INSERT INTO `sms_partners_two` VALUES(`581`, `0`, `30`, `0`, `0`, `0`, `0`, `188.134.45.0`);
INSERT INTO `sms_partners_two` VALUES(`582`, `0`, `30`, `0`, `0`, `0`, `0`, `80.240.10.218`);
INSERT INTO `sms_partners_two` VALUES(`583`, `0`, `30`, `0`, `0`, `0`, `0`, `194.44.163.224`);
INSERT INTO `sms_partners_two` VALUES(`584`, `0`, `30`, `0`, `0`, `0`, `0`, `176.67.3.64`);
INSERT INTO `sms_partners_two` VALUES(`585`, `0`, `30`, `0`, `0`, `0`, `0`, `46.211.183.228`);
INSERT INTO `sms_partners_two` VALUES(`586`, `0`, `30`, `0`, `0`, `0`, `0`, `87.110.141.87`);
INSERT INTO `sms_partners_two` VALUES(`587`, `0`, `30`, `0`, `0`, `0`, `0`, `95.58.234.103`);
INSERT INTO `sms_partners_two` VALUES(`588`, `0`, `30`, `0`, `0`, `0`, `0`, `94.241.210.142`);
INSERT INTO `sms_partners_two` VALUES(`589`, `0`, `30`, `0`, `0`, `0`, `0`, `178.35.66.81`);
INSERT INTO `sms_partners_two` VALUES(`590`, `0`, `30`, `0`, `0`, `0`, `0`, `95.56.131.9`);
INSERT INTO `sms_partners_two` VALUES(`591`, `0`, `30`, `0`, `0`, `0`, `0`, `95.134.124.113`);
INSERT INTO `sms_partners_two` VALUES(`592`, `0`, `30`, `0`, `0`, `0`, `0`, `79.126.86.163`);
INSERT INTO `sms_partners_two` VALUES(`593`, `0`, `30`, `0`, `0`, `0`, `0`, `178.123.211.227`);
INSERT INTO `sms_partners_two` VALUES(`594`, `0`, `30`, `0`, `0`, `0`, `0`, `46.203.106.172`);
INSERT INTO `sms_partners_two` VALUES(`595`, `0`, `30`, `0`, `0`, `0`, `0`, `46.185.24.213`);
INSERT INTO `sms_partners_two` VALUES(`596`, `0`, `30`, `0`, `0`, `0`, `0`, `95.134.108.251`);
INSERT INTO `sms_partners_two` VALUES(`597`, `0`, `30`, `0`, `0`, `0`, `0`, `62.209.151.130`);
INSERT INTO `sms_partners_two` VALUES(`598`, `0`, `30`, `0`, `0`, `0`, `0`, `188.112.140.51`);
INSERT INTO `sms_partners_two` VALUES(`599`, `0`, `30`, `0`, `0`, `0`, `0`, `95.134.14.248`);
INSERT INTO `sms_partners_two` VALUES(`600`, `0`, `30`, `0`, `0`, `0`, `0`, `176.109.218.167`);
INSERT INTO `sms_partners_two` VALUES(`601`, `0`, `30`, `0`, `0`, `0`, `0`, `46.158.177.103`);
INSERT INTO `sms_partners_two` VALUES(`602`, `0`, `30`, `0`, `0`, `0`, `0`, `92.112.182.57`);
INSERT INTO `sms_partners_two` VALUES(`603`, `0`, `30`, `0`, `0`, `0`, `0`, `87.245.203.18`);
INSERT INTO `sms_partners_two` VALUES(`604`, `0`, `30`, `0`, `0`, `0`, `0`, `151.0.19.68`);
INSERT INTO `sms_partners_two` VALUES(`605`, `0`, `30`, `0`, `0`, `0`, `0`, `78.137.51.232`);
INSERT INTO `sms_partners_two` VALUES(`606`, `0`, `30`, `0`, `0`, `0`, `0`, `178.206.19.214`);
INSERT INTO `sms_partners_two` VALUES(`607`, `0`, `30`, `0`, `0`, `0`, `0`, `178.65.146.176`);
INSERT INTO `sms_partners_two` VALUES(`608`, `0`, `30`, `0`, `0`, `0`, `0`, `178.212.102.76`);
INSERT INTO `sms_partners_two` VALUES(`609`, `0`, `30`, `0`, `0`, `0`, `0`, `178.151.119.189`);
INSERT INTO `sms_partners_two` VALUES(`610`, `0`, `30`, `0`, `0`, `0`, `0`, `178.165.30.185`);
INSERT INTO `sms_partners_two` VALUES(`611`, `0`, `30`, `0`, `0`, `0`, `0`, `212.22.201.227`);
INSERT INTO `sms_partners_two` VALUES(`612`, `0`, `30`, `0`, `0`, `0`, `0`, `109.185.156.68`);
INSERT INTO `sms_partners_two` VALUES(`613`, `0`, `30`, `0`, `0`, `0`, `0`, `95.32.47.68`);
INSERT INTO `sms_partners_two` VALUES(`614`, `0`, `30`, `0`, `0`, `0`, `0`, `178.45.79.133`);
INSERT INTO `sms_partners_two` VALUES(`615`, `0`, `30`, `0`, `0`, `0`, `0`, `31.181.37.162`);
INSERT INTO `sms_partners_two` VALUES(`616`, `0`, `30`, `0`, `0`, `0`, `0`, `130.180.223.190`);
INSERT INTO `sms_partners_two` VALUES(`617`, `0`, `30`, `0`, `0`, `0`, `0`, `46.138.97.238`);
INSERT INTO `sms_partners_two` VALUES(`618`, `0`, `30`, `0`, `0`, `0`, `0`, `130.234.176.219`);
INSERT INTO `sms_partners_two` VALUES(`619`, `0`, `30`, `0`, `0`, `0`, `0`, `178.125.204.209`);
INSERT INTO `sms_partners_two` VALUES(`620`, `0`, `30`, `0`, `0`, `0`, `0`, `46.233.206.31`);
INSERT INTO `sms_partners_two` VALUES(`621`, `0`, `30`, `0`, `0`, `0`, `0`, `178.126.128.170`);
INSERT INTO `sms_partners_two` VALUES(`622`, `0`, `30`, `0`, `0`, `0`, `0`, `91.217.244.99`);
INSERT INTO `sms_partners_two` VALUES(`623`, `0`, `30`, `0`, `0`, `0`, `0`, `195.211.188.16`);
INSERT INTO `sms_partners_two` VALUES(`624`, `0`, `30`, `0`, `0`, `0`, `0`, `46.187.19.87`);
INSERT INTO `sms_partners_two` VALUES(`625`, `0`, `30`, `0`, `0`, `0`, `0`, `91.225.95.249`);
INSERT INTO `sms_partners_two` VALUES(`626`, `0`, `30`, `0`, `0`, `0`, `0`, `46.70.35.0`);
INSERT INTO `sms_partners_two` VALUES(`627`, `0`, `30`, `0`, `0`, `0`, `0`, `178.125.238.31`);
INSERT INTO `sms_partners_two` VALUES(`628`, `0`, `30`, `0`, `0`, `0`, `0`, `78.25.180.133`);
INSERT INTO `sms_partners_two` VALUES(`629`, `0`, `30`, `0`, `0`, `0`, `0`, `193.105.92.205`);
INSERT INTO `sms_partners_two` VALUES(`630`, `0`, `30`, `0`, `0`, `0`, `0`, `194.186.53.93`);
INSERT INTO `sms_partners_two` VALUES(`631`, `0`, `30`, `0`, `0`, `0`, `0`, `176.212.19.126`);
INSERT INTO `sms_partners_two` VALUES(`632`, `0`, `30`, `0`, `0`, `0`, `0`, `109.60.168.9`);
INSERT INTO `sms_partners_two` VALUES(`633`, `0`, `30`, `0`, `0`, `0`, `0`, `195.114.138.71`);
INSERT INTO `sms_partners_two` VALUES(`634`, `0`, `30`, `0`, `0`, `0`, `0`, `109.229.0.95`);
INSERT INTO `sms_partners_two` VALUES(`635`, `0`, `30`, `0`, `0`, `0`, `0`, `77.232.159.103`);
INSERT INTO `sms_partners_two` VALUES(`636`, `0`, `30`, `0`, `0`, `0`, `0`, `93.79.5.181`);
INSERT INTO `sms_partners_two` VALUES(`637`, `0`, `30`, `0`, `0`, `0`, `0`, `89.149.87.90`);
INSERT INTO `sms_partners_two` VALUES(`638`, `0`, `30`, `0`, `0`, `0`, `0`, `213.206.41.13`);
INSERT INTO `sms_partners_two` VALUES(`639`, `0`, `30`, `0`, `0`, `0`, `0`, `95.42.114.85`);
INSERT INTO `sms_partners_two` VALUES(`640`, `0`, `30`, `0`, `0`, `0`, `0`, `62.182.71.229`);
INSERT INTO `sms_partners_two` VALUES(`641`, `0`, `30`, `0`, `0`, `0`, `0`, `37.52.2.164`);
INSERT INTO `sms_partners_two` VALUES(`642`, `0`, `30`, `0`, `0`, `0`, `0`, `91.237.0.147`);
INSERT INTO `sms_partners_two` VALUES(`643`, `0`, `30`, `0`, `0`, `0`, `0`, `213.145.22.16`);
INSERT INTO `sms_partners_two` VALUES(`644`, `0`, `30`, `0`, `0`, `0`, `0`, `78.26.200.108`);
INSERT INTO `sms_partners_two` VALUES(`645`, `0`, `30`, `0`, `0`, `0`, `0`, `37.45.251.106`);
INSERT INTO `sms_partners_two` VALUES(`646`, `0`, `30`, `0`, `0`, `0`, `0`, `31.162.73.219`);
INSERT INTO `sms_partners_two` VALUES(`647`, `0`, `30`, `0`, `0`, `0`, `0`, `84.15.180.28`);
INSERT INTO `sms_partners_two` VALUES(`648`, `0`, `30`, `0`, `0`, `0`, `0`, `85.159.226.17`);
INSERT INTO `sms_partners_two` VALUES(`649`, `0`, `30`, `0`, `0`, `0`, `0`, `77.120.150.96`);
INSERT INTO `sms_partners_two` VALUES(`650`, `0`, `30`, `0`, `0`, `0`, `0`, `95.153.169.58`);
INSERT INTO `sms_partners_two` VALUES(`651`, `0`, `30`, `0`, `0`, `0`, `0`, `46.182.53.201`);
INSERT INTO `sms_partners_two` VALUES(`652`, `0`, `30`, `0`, `0`, `0`, `0`, `92.242.113.69`);
INSERT INTO `sms_partners_two` VALUES(`653`, `0`, `30`, `0`, `0`, `0`, `0`, `178.94.141.85`);
INSERT INTO `sms_partners_two` VALUES(`654`, `0`, `30`, `0`, `0`, `0`, `0`, `91.214.203.212`);
INSERT INTO `sms_partners_two` VALUES(`655`, `0`, `30`, `0`, `0`, `0`, `0`, `178.120.28.145`);
INSERT INTO `sms_partners_two` VALUES(`656`, `0`, `30`, `0`, `0`, `0`, `0`, `95.182.110.36`);
INSERT INTO `sms_partners_two` VALUES(`657`, `0`, `30`, `0`, `0`, `0`, `0`, `193.200.85.116`);
INSERT INTO `sms_partners_two` VALUES(`658`, `0`, `30`, `0`, `0`, `0`, `0`, `178.95.72.109`);
INSERT INTO `sms_partners_two` VALUES(`659`, `0`, `30`, `0`, `0`, `0`, `0`, `178.68.239.52`);
INSERT INTO `sms_partners_two` VALUES(`660`, `0`, `30`, `0`, `0`, `0`, `0`, `78.139.152.107`);
INSERT INTO `sms_partners_two` VALUES(`661`, `0`, `30`, `0`, `0`, `0`, `0`, `85.172.189.254`);
INSERT INTO `sms_partners_two` VALUES(`662`, `0`, `30`, `0`, `0`, `0`, `0`, `95.133.48.110`);
INSERT INTO `sms_partners_two` VALUES(`663`, `0`, `30`, `0`, `0`, `0`, `0`, `128.70.163.235`);
INSERT INTO `sms_partners_two` VALUES(`664`, `0`, `30`, `0`, `0`, `0`, `0`, `178.204.39.119`);
INSERT INTO `sms_partners_two` VALUES(`665`, `0`, `30`, `0`, `0`, `0`, `0`, `213.87.135.39`);
INSERT INTO `sms_partners_two` VALUES(`666`, `0`, `30`, `0`, `0`, `0`, `0`, `46.72.19.36`);
INSERT INTO `sms_partners_two` VALUES(`667`, `0`, `30`, `0`, `0`, `0`, `0`, `94.153.124.113`);
INSERT INTO `sms_partners_two` VALUES(`668`, `0`, `30`, `0`, `0`, `0`, `0`, `192.166.132.12`);
INSERT INTO `sms_partners_two` VALUES(`669`, `0`, `30`, `0`, `0`, `0`, `0`, `37.44.127.213`);
INSERT INTO `sms_partners_two` VALUES(`670`, `0`, `30`, `0`, `0`, `0`, `0`, `178.165.48.149`);
INSERT INTO `sms_partners_two` VALUES(`671`, `0`, `30`, `0`, `0`, `0`, `0`, `109.207.176.154`);
INSERT INTO `sms_partners_two` VALUES(`672`, `0`, `30`, `0`, `0`, `0`, `0`, `77.244.116.41`);
INSERT INTO `sms_partners_two` VALUES(`673`, `0`, `30`, `0`, `0`, `0`, `0`, `188.230.68.11`);
INSERT INTO `sms_partners_two` VALUES(`674`, `0`, `30`, `0`, `0`, `0`, `0`, `95.106.109.89`);
INSERT INTO `sms_partners_two` VALUES(`675`, `0`, `30`, `0`, `0`, `0`, `0`, `178.122.61.227`);
INSERT INTO `sms_partners_two` VALUES(`676`, `0`, `30`, `0`, `0`, `0`, `0`, `109.229.72.120`);
INSERT INTO `sms_partners_two` VALUES(`677`, `0`, `30`, `0`, `0`, `0`, `0`, `91.231.148.56`);
INSERT INTO `sms_partners_two` VALUES(`678`, `0`, `30`, `0`, `0`, `0`, `0`, `88.135.227.182`);
INSERT INTO `sms_partners_two` VALUES(`679`, `0`, `30`, `0`, `0`, `0`, `0`, `178.45.90.249`);
INSERT INTO `sms_partners_two` VALUES(`680`, `0`, `30`, `0`, `0`, `0`, `0`, `78.85.124.214`);
INSERT INTO `sms_partners_two` VALUES(`681`, `0`, `30`, `0`, `0`, `0`, `0`, `37.45.5.22`);
INSERT INTO `sms_partners_two` VALUES(`682`, `0`, `30`, `0`, `0`, `0`, `0`, `188.124.34.81`);
INSERT INTO `sms_partners_two` VALUES(`683`, `0`, `30`, `0`, `0`, `0`, `0`, `77.34.22.138`);
INSERT INTO `sms_partners_two` VALUES(`684`, `0`, `30`, `0`, `0`, `0`, `0`, `188.235.40.42`);
INSERT INTO `sms_partners_two` VALUES(`685`, `0`, `30`, `0`, `0`, `0`, `0`, `91.217.60.2`);
INSERT INTO `sms_partners_two` VALUES(`686`, `0`, `30`, `0`, `0`, `0`, `0`, `46.146.34.16`);
INSERT INTO `sms_partners_two` VALUES(`687`, `0`, `30`, `0`, `0`, `0`, `0`, `95.133.99.210`);
INSERT INTO `sms_partners_two` VALUES(`688`, `0`, `30`, `0`, `0`, `0`, `0`, `80.84.184.34`);
INSERT INTO `sms_partners_two` VALUES(`689`, `0`, `30`, `0`, `0`, `0`, `0`, `194.28.69.142`);
INSERT INTO `sms_partners_two` VALUES(`690`, `0`, `30`, `0`, `0`, `0`, `0`, `83.142.104.72`);
INSERT INTO `sms_partners_two` VALUES(`691`, `0`, `30`, `0`, `0`, `0`, `0`, `178.123.202.38`);
INSERT INTO `sms_partners_two` VALUES(`692`, `0`, `30`, `0`, `0`, `0`, `0`, `178.216.2.167`);
INSERT INTO `sms_partners_two` VALUES(`693`, `0`, `30`, `0`, `0`, `0`, `0`, `95.42.70.37`);
INSERT INTO `sms_partners_two` VALUES(`694`, `0`, `30`, `0`, `0`, `0`, `0`, `78.24.10.252`);
INSERT INTO `sms_partners_two` VALUES(`695`, `0`, `30`, `0`, `0`, `0`, `0`, `178.187.117.32`);
INSERT INTO `sms_partners_two` VALUES(`696`, `0`, `30`, `0`, `0`, `0`, `0`, `62.192.231.136`);
INSERT INTO `sms_partners_two` VALUES(`697`, `0`, `30`, `0`, `0`, `0`, `0`, `92.112.154.184`);
INSERT INTO `sms_partners_two` VALUES(`698`, `0`, `30`, `0`, `0`, `0`, `0`, `213.111.70.213`);
INSERT INTO `sms_partners_two` VALUES(`699`, `0`, `30`, `0`, `0`, `0`, `0`, `88.135.62.29`);
INSERT INTO `sms_partners_two` VALUES(`700`, `0`, `30`, `0`, `0`, `0`, `0`, `46.175.184.168`);
INSERT INTO `sms_partners_two` VALUES(`701`, `0`, `30`, `0`, `0`, `0`, `0`, `94.241.247.245`);
INSERT INTO `sms_partners_two` VALUES(`702`, `0`, `30`, `0`, `0`, `0`, `0`, `92.112.158.63`);
INSERT INTO `sms_partners_two` VALUES(`703`, `0`, `30`, `0`, `0`, `0`, `0`, `31.24.94.204`);
INSERT INTO `sms_partners_two` VALUES(`704`, `0`, `30`, `0`, `0`, `0`, `0`, `87.252.227.61`);
INSERT INTO `sms_partners_two` VALUES(`705`, `0`, `30`, `0`, `0`, `0`, `0`, `178.151.133.114`);
INSERT INTO `sms_partners_two` VALUES(`706`, `0`, `30`, `0`, `0`, `0`, `0`, `89.254.241.229`);
INSERT INTO `sms_partners_two` VALUES(`707`, `0`, `30`, `0`, `0`, `0`, `0`, `178.159.93.38`);
INSERT INTO `sms_partners_two` VALUES(`708`, `0`, `30`, `0`, `0`, `0`, `0`, `87.228.80.13`);
INSERT INTO `sms_partners_two` VALUES(`709`, `0`, `30`, `0`, `0`, `0`, `0`, `93.85.220.185`);
INSERT INTO `sms_partners_two` VALUES(`710`, `0`, `30`, `0`, `0`, `0`, `0`, `188.134.60.101`);
INSERT INTO `sms_partners_two` VALUES(`711`, `0`, `30`, `0`, `0`, `0`, `0`, `92.101.83.63`);
INSERT INTO `sms_partners_two` VALUES(`712`, `0`, `30`, `0`, `0`, `0`, `0`, `178.187.149.184`);
INSERT INTO `sms_partners_two` VALUES(`713`, `0`, `30`, `0`, `0`, `0`, `0`, `178.127.104.134`);
INSERT INTO `sms_partners_two` VALUES(`714`, `0`, `30`, `0`, `0`, `0`, `0`, `85.26.231.36`);
INSERT INTO `sms_partners_two` VALUES(`715`, `0`, `30`, `0`, `0`, `0`, `0`, `109.161.11.117`);
INSERT INTO `sms_partners_two` VALUES(`716`, `0`, `30`, `0`, `0`, `0`, `0`, `94.179.31.51`);
INSERT INTO `sms_partners_two` VALUES(`717`, `0`, `30`, `0`, `0`, `0`, `0`, `84.54.120.62`);
INSERT INTO `sms_partners_two` VALUES(`718`, `0`, `30`, `0`, `0`, `0`, `0`, `178.66.212.231`);
INSERT INTO `sms_partners_two` VALUES(`719`, `0`, `30`, `0`, `0`, `0`, `0`, `85.26.206.177`);
INSERT INTO `sms_partners_two` VALUES(`720`, `0`, `30`, `0`, `0`, `0`, `0`, `46.53.195.31`);
INSERT INTO `sms_partners_two` VALUES(`721`, `0`, `30`, `0`, `0`, `0`, `0`, `77.232.158.106`);
INSERT INTO `sms_partners_two` VALUES(`722`, `0`, `30`, `0`, `0`, `0`, `0`, `83.149.47.88`);
INSERT INTO `sms_partners_two` VALUES(`723`, `0`, `30`, `0`, `0`, `0`, `0`, `178.45.206.218`);
INSERT INTO `sms_partners_two` VALUES(`724`, `0`, `30`, `0`, `0`, `0`, `0`, `178.121.12.42`);
INSERT INTO `sms_partners_two` VALUES(`725`, `0`, `30`, `0`, `0`, `0`, `0`, `31.134.250.163`);
INSERT INTO `sms_partners_two` VALUES(`726`, `0`, `30`, `0`, `0`, `0`, `0`, `109.174.112.69`);
INSERT INTO `sms_partners_two` VALUES(`727`, `0`, `30`, `0`, `0`, `0`, `0`, `37.52.231.147`);
INSERT INTO `sms_partners_two` VALUES(`728`, `0`, `0`, `0`, `0`, `0`, `0`, `37.52.231.147`);
INSERT INTO `sms_partners_two` VALUES(`729`, `0`, `30`, `0`, `0`, `0`, `0`, `194.28.62.255`);
INSERT INTO `sms_partners_two` VALUES(`730`, `0`, `30`, `0`, `0`, `0`, `0`, `46.71.7.77`);
INSERT INTO `sms_partners_two` VALUES(`731`, `0`, `30`, `0`, `0`, `0`, `0`, `217.118.79.30`);
INSERT INTO `sms_partners_two` VALUES(`732`, `0`, `30`, `0`, `0`, `0`, `0`, `46.203.233.0`);
INSERT INTO `sms_partners_two` VALUES(`733`, `0`, `30`, `0`, `0`, `0`, `0`, `37.26.135.4`);
INSERT INTO `sms_partners_two` VALUES(`734`, `0`, `30`, `0`, `0`, `0`, `0`, `178.90.231.54`);
INSERT INTO `sms_partners_two` VALUES(`735`, `0`, `30`, `0`, `0`, `0`, `0`, `85.26.232.54`);
INSERT INTO `sms_partners_two` VALUES(`736`, `0`, `30`, `0`, `0`, `0`, `0`, `77.125.101.85`);
INSERT INTO `sms_partners_two` VALUES(`737`, `0`, `30`, `0`, `0`, `0`, `0`, `178.64.181.254`);
INSERT INTO `sms_partners_two` VALUES(`738`, `0`, `30`, `0`, `0`, `0`, `0`, `46.147.134.123`);
INSERT INTO `sms_partners_two` VALUES(`739`, `0`, `30`, `0`, `0`, `0`, `0`, `2.60.119.166`);
INSERT INTO `sms_partners_two` VALUES(`740`, `0`, `30`, `0`, `0`, `0`, `0`, `188.237.34.205`);
INSERT INTO `sms_partners_two` VALUES(`741`, `0`, `30`, `0`, `0`, `0`, `0`, `95.66.167.35`);
INSERT INTO `sms_partners_two` VALUES(`742`, `0`, `30`, `0`, `0`, `0`, `0`, `109.162.44.93`);
INSERT INTO `sms_partners_two` VALUES(`743`, `0`, `30`, `0`, `0`, `0`, `0`, `93.79.180.100`);
INSERT INTO `sms_partners_two` VALUES(`744`, `0`, `30`, `0`, `0`, `0`, `0`, `81.88.222.36`);
INSERT INTO `sms_partners_two` VALUES(`745`, `0`, `30`, `0`, `0`, `0`, `0`, `77.232.15.245`);
INSERT INTO `sms_partners_two` VALUES(`746`, `0`, `30`, `0`, `0`, `0`, `0`, `91.189.50.42`);
INSERT INTO `sms_partners_two` VALUES(`747`, `0`, `30`, `0`, `0`, `0`, `0`, `95.133.204.213`);
INSERT INTO `sms_partners_two` VALUES(`748`, `0`, `30`, `0`, `0`, `0`, `0`, `178.129.30.92`);
INSERT INTO `sms_partners_two` VALUES(`749`, `0`, `30`, `0`, `0`, `0`, `0`, `89.22.165.136`);
INSERT INTO `sms_partners_two` VALUES(`750`, `0`, `30`, `0`, `0`, `0`, `0`, `188.16.119.13`);
INSERT INTO `sms_partners_two` VALUES(`751`, `0`, `30`, `0`, `0`, `0`, `0`, `93.79.198.50`);
INSERT INTO `sms_partners_two` VALUES(`752`, `0`, `30`, `0`, `0`, `0`, `0`, `109.124.39.85`);
INSERT INTO `sms_partners_two` VALUES(`753`, `0`, `30`, `0`, `0`, `0`, `0`, `128.73.234.245`);
INSERT INTO `sms_partners_two` VALUES(`754`, `0`, `30`, `0`, `0`, `0`, `0`, `85.26.164.167`);
INSERT INTO `sms_partners_two` VALUES(`755`, `0`, `30`, `0`, `0`, `0`, `0`, `91.219.140.120`);
INSERT INTO `sms_partners_two` VALUES(`756`, `0`, `30`, `0`, `0`, `0`, `0`, `178.187.88.2`);
INSERT INTO `sms_partners_two` VALUES(`757`, `0`, `30`, `0`, `0`, `0`, `0`, `78.139.110.162`);
INSERT INTO `sms_partners_two` VALUES(`758`, `0`, `30`, `0`, `0`, `0`, `0`, `93.120.198.203`);
INSERT INTO `sms_partners_two` VALUES(`759`, `0`, `30`, `0`, `0`, `0`, `0`, `176.53.230.68`);
INSERT INTO `sms_partners_two` VALUES(`760`, `0`, `30`, `0`, `0`, `0`, `0`, `77.240.96.18`);
INSERT INTO `sms_partners_two` VALUES(`761`, `0`, `30`, `0`, `0`, `0`, `0`, `62.221.66.55`);
INSERT INTO `sms_partners_two` VALUES(`762`, `0`, `30`, `0`, `0`, `0`, `0`, `95.57.136.51`);
INSERT INTO `sms_partners_two` VALUES(`763`, `0`, `30`, `0`, `0`, `0`, `0`, `95.132.11.78`);
INSERT INTO `sms_partners_two` VALUES(`764`, `0`, `30`, `0`, `0`, `0`, `0`, `78.25.38.187`);
INSERT INTO `sms_partners_two` VALUES(`765`, `0`, `30`, `0`, `0`, `0`, `0`, `91.225.212.106`);
INSERT INTO `sms_partners_two` VALUES(`766`, `0`, `30`, `0`, `0`, `0`, `0`, `46.118.192.201`);
INSERT INTO `sms_partners_two` VALUES(`767`, `0`, `30`, `0`, `0`, `0`, `0`, `92.243.181.22`);
INSERT INTO `sms_partners_two` VALUES(`768`, `0`, `30`, `0`, `0`, `0`, `0`, `95.32.156.2`);
INSERT INTO `sms_partners_two` VALUES(`769`, `0`, `30`, `0`, `0`, `0`, `0`, `95.52.41.39`);
INSERT INTO `sms_partners_two` VALUES(`770`, `0`, `30`, `0`, `0`, `0`, `0`, `176.195.100.67`);
INSERT INTO `sms_partners_two` VALUES(`771`, `0`, `30`, `0`, `0`, `0`, `0`, `77.127.39.192`);
INSERT INTO `sms_partners_two` VALUES(`772`, `0`, `30`, `0`, `0`, `0`, `0`, `95.105.121.21`);
INSERT INTO `sms_partners_two` VALUES(`773`, `0`, `30`, `0`, `0`, `0`, `0`, `178.94.82.39`);
INSERT INTO `sms_partners_two` VALUES(`774`, `0`, `30`, `0`, `0`, `0`, `0`, `91.124.30.95`);
INSERT INTO `sms_partners_two` VALUES(`775`, `0`, `30`, `0`, `0`, `0`, `0`, `178.154.12.178`);
INSERT INTO `sms_partners_two` VALUES(`776`, `0`, `30`, `0`, `0`, `0`, `0`, `178.93.218.4`);
INSERT INTO `sms_partners_two` VALUES(`777`, `0`, `30`, `0`, `0`, `0`, `0`, `78.132.148.97`);
INSERT INTO `sms_partners_two` VALUES(`778`, `0`, `30`, `0`, `0`, `0`, `0`, `94.251.59.211`);
INSERT INTO `sms_partners_two` VALUES(`779`, `0`, `30`, `0`, `0`, `0`, `0`, `95.105.76.19`);
INSERT INTO `sms_partners_two` VALUES(`780`, `0`, `30`, `0`, `0`, `0`, `0`, `176.8.253.84`);
INSERT INTO `sms_partners_two` VALUES(`781`, `0`, `30`, `0`, `0`, `0`, `0`, `188.190.36.79`);
INSERT INTO `sms_partners_two` VALUES(`782`, `0`, `30`, `0`, `0`, `0`, `0`, `85.115.224.222`);
INSERT INTO `sms_partners_two` VALUES(`783`, `0`, `30`, `0`, `0`, `0`, `0`, `176.110.239.240`);
INSERT INTO `sms_partners_two` VALUES(`784`, `0`, `30`, `0`, `0`, `0`, `0`, `85.238.107.149`);
INSERT INTO `sms_partners_two` VALUES(`785`, `0`, `30`, `0`, `0`, `0`, `0`, `77.123.51.250`);
INSERT INTO `sms_partners_two` VALUES(`786`, `0`, `30`, `0`, `0`, `0`, `0`, `94.241.254.91`);
INSERT INTO `sms_partners_two` VALUES(`787`, `0`, `30`, `0`, `0`, `0`, `0`, `188.190.32.3`);
INSERT INTO `sms_partners_two` VALUES(`788`, `0`, `30`, `0`, `0`, `0`, `0`, `31.31.98.186`);
INSERT INTO `sms_partners_two` VALUES(`789`, `0`, `30`, `0`, `0`, `0`, `0`, `31.162.176.45`);
INSERT INTO `sms_partners_two` VALUES(`790`, `0`, `30`, `0`, `0`, `0`, `0`, `80.234.127.41`);
INSERT INTO `sms_partners_two` VALUES(`791`, `0`, `30`, `0`, `0`, `0`, `0`, `212.1.100.222`);
INSERT INTO `sms_partners_two` VALUES(`792`, `0`, `30`, `0`, `0`, `0`, `0`, `178.129.200.102`);
INSERT INTO `sms_partners_two` VALUES(`793`, `0`, `30`, `0`, `0`, `0`, `0`, `88.200.220.162`);
INSERT INTO `sms_partners_two` VALUES(`794`, `0`, `30`, `0`, `0`, `0`, `0`, `92.47.121.147`);
INSERT INTO `sms_partners_two` VALUES(`795`, `0`, `30`, `0`, `0`, `0`, `0`, `95.65.67.33`);
INSERT INTO `sms_partners_two` VALUES(`796`, `0`, `30`, `0`, `0`, `0`, `0`, `94.179.188.107`);
INSERT INTO `sms_partners_two` VALUES(`797`, `0`, `30`, `0`, `0`, `0`, `0`, `109.87.105.152`);
INSERT INTO `sms_partners_two` VALUES(`798`, `0`, `30`, `0`, `0`, `0`, `0`, `212.220.130.54`);
INSERT INTO `sms_partners_two` VALUES(`799`, `0`, `30`, `0`, `0`, `0`, `0`, `95.58.180.81`);
INSERT INTO `sms_partners_two` VALUES(`800`, `0`, `30`, `0`, `0`, `0`, `0`, `91.196.91.32`);
INSERT INTO `sms_partners_two` VALUES(`801`, `0`, `30`, `0`, `0`, `0`, `0`, `95.134.64.200`);
INSERT INTO `sms_partners_two` VALUES(`802`, `0`, `30`, `0`, `0`, `0`, `0`, `31.8.212.231`);
INSERT INTO `sms_partners_two` VALUES(`803`, `0`, `30`, `0`, `0`, `0`, `0`, `176.32.12.159`);
INSERT INTO `sms_partners_two` VALUES(`804`, `0`, `30`, `0`, `0`, `0`, `0`, `178.45.2.161`);
INSERT INTO `sms_partners_two` VALUES(`805`, `0`, `30`, `0`, `0`, `0`, `0`, `78.111.219.27`);
INSERT INTO `sms_partners_two` VALUES(`806`, `0`, `30`, `0`, `0`, `0`, `0`, `31.162.5.23`);
INSERT INTO `sms_partners_two` VALUES(`807`, `0`, `30`, `0`, `0`, `0`, `0`, `93.116.226.83`);
INSERT INTO `sms_partners_two` VALUES(`808`, `0`, `30`, `0`, `0`, `0`, `0`, `109.248.83.26`);
INSERT INTO `sms_partners_two` VALUES(`809`, `0`, `30`, `0`, `0`, `0`, `0`, `91.234.91.149`);
INSERT INTO `sms_partners_two` VALUES(`810`, `0`, `30`, `0`, `0`, `0`, `0`, `178.95.29.138`);
INSERT INTO `sms_partners_two` VALUES(`811`, `0`, `30`, `0`, `0`, `0`, `0`, `188.255.88.130`);
INSERT INTO `sms_partners_two` VALUES(`812`, `0`, `30`, `0`, `0`, `0`, `0`, `217.150.48.73`);
INSERT INTO `sms_partners_two` VALUES(`813`, `0`, `30`, `0`, `0`, `0`, `0`, `213.87.121.150`);
INSERT INTO `sms_partners_two` VALUES(`814`, `0`, `30`, `0`, `0`, `0`, `0`, `95.170.180.252`);
INSERT INTO `sms_partners_two` VALUES(`815`, `0`, `30`, `0`, `0`, `0`, `0`, `95.167.219.48`);
INSERT INTO `sms_partners_two` VALUES(`816`, `0`, `30`, `0`, `0`, `0`, `0`, `83.149.2.81`);
INSERT INTO `sms_partners_two` VALUES(`817`, `0`, `30`, `0`, `0`, `0`, `0`, `77.120.76.66`);
INSERT INTO `sms_partners_two` VALUES(`818`, `0`, `30`, `0`, `0`, `0`, `0`, `46.147.129.148`);
INSERT INTO `sms_partners_two` VALUES(`819`, `0`, `30`, `0`, `0`, `0`, `0`, `194.24.138.5`);
INSERT INTO `sms_partners_two` VALUES(`820`, `0`, `30`, `0`, `0`, `0`, `0`, `95.132.190.40`);
INSERT INTO `sms_partners_two` VALUES(`821`, `0`, `30`, `0`, `0`, `0`, `0`, `37.55.114.47`);
INSERT INTO `sms_partners_two` VALUES(`822`, `0`, `30`, `0`, `0`, `0`, `0`, `178.165.56.192`);
INSERT INTO `sms_partners_two` VALUES(`823`, `0`, `30`, `0`, `0`, `0`, `0`, `46.251.91.23`);
INSERT INTO `sms_partners_two` VALUES(`824`, `0`, `30`, `0`, `0`, `0`, `0`, `178.126.123.252`);
INSERT INTO `sms_partners_two` VALUES(`825`, `0`, `30`, `0`, `0`, `0`, `0`, `46.130.86.118`);
INSERT INTO `sms_partners_two` VALUES(`826`, `0`, `30`, `0`, `0`, `0`, `0`, `95.132.140.205`);
INSERT INTO `sms_partners_two` VALUES(`827`, `0`, `30`, `0`, `0`, `0`, `0`, `109.238.100.134`);
INSERT INTO `sms_partners_two` VALUES(`828`, `0`, `30`, `0`, `0`, `0`, `0`, `91.215.144.2`);
INSERT INTO `sms_partners_two` VALUES(`829`, `0`, `30`, `0`, `0`, `0`, `0`, `37.54.201.78`);
INSERT INTO `sms_partners_two` VALUES(`830`, `0`, `30`, `0`, `0`, `0`, `0`, `178.127.194.68`);
INSERT INTO `sms_partners_two` VALUES(`831`, `0`, `30`, `0`, `0`, `0`, `0`, `178.93.89.205`);
INSERT INTO `sms_partners_two` VALUES(`832`, `0`, `30`, `0`, `0`, `0`, `0`, `77.123.187.1`);
INSERT INTO `sms_partners_two` VALUES(`833`, `0`, `30`, `0`, `0`, `0`, `0`, `37.229.67.96`);
INSERT INTO `sms_partners_two` VALUES(`834`, `0`, `30`, `0`, `0`, `0`, `0`, `31.43.170.37`);
INSERT INTO `sms_partners_two` VALUES(`835`, `0`, `30`, `0`, `0`, `0`, `0`, `46.173.164.11`);
INSERT INTO `sms_partners_two` VALUES(`836`, `0`, `30`, `0`, `0`, `0`, `0`, `109.227.72.124`);
INSERT INTO `sms_partners_two` VALUES(`837`, `0`, `30`, `0`, `0`, `0`, `0`, `195.58.245.214`);
INSERT INTO `sms_partners_two` VALUES(`838`, `0`, `30`, `0`, `0`, `0`, `0`, `195.230.96.254`);
INSERT INTO `sms_partners_two` VALUES(`839`, `0`, `30`, `0`, `0`, `0`, `0`, `88.80.55.148`);
INSERT INTO `sms_partners_two` VALUES(`840`, `0`, `30`, `0`, `0`, `0`, `0`, `93.126.88.7`);
INSERT INTO `sms_partners_two` VALUES(`841`, `0`, `30`, `0`, `0`, `0`, `0`, `178.210.210.155`);
INSERT INTO `sms_partners_two` VALUES(`842`, `0`, `30`, `0`, `0`, `0`, `0`, `213.174.9.34`);
INSERT INTO `sms_partners_two` VALUES(`843`, `0`, `30`, `0`, `0`, `0`, `0`, `213.138.68.42`);
INSERT INTO `sms_partners_two` VALUES(`844`, `0`, `30`, `0`, `0`, `0`, `0`, `37.113.179.129`);
INSERT INTO `sms_partners_two` VALUES(`845`, `0`, `30`, `0`, `0`, `0`, `0`, `94.243.22.214`);
INSERT INTO `sms_partners_two` VALUES(`846`, `0`, `30`, `0`, `0`, `0`, `0`, `91.220.106.215`);
INSERT INTO `sms_partners_two` VALUES(`847`, `0`, `30`, `0`, `0`, `0`, `0`, `176.8.66.131`);
INSERT INTO `sms_partners_two` VALUES(`848`, `0`, `30`, `0`, `0`, `0`, `0`, `178.217.208.7`);
INSERT INTO `sms_partners_two` VALUES(`849`, `0`, `30`, `0`, `0`, `0`, `0`, `46.71.194.101`);
INSERT INTO `sms_partners_two` VALUES(`850`, `0`, `30`, `0`, `0`, `0`, `0`, `37.55.71.78`);
INSERT INTO `sms_partners_two` VALUES(`851`, `0`, `30`, `0`, `0`, `0`, `0`, `109.108.249.12`);
INSERT INTO `sms_partners_two` VALUES(`852`, `0`, `30`, `0`, `0`, `0`, `0`, `37.229.21.22`);
INSERT INTO `sms_partners_two` VALUES(`853`, `0`, `30`, `0`, `0`, `0`, `0`, `176.102.4.220`);
INSERT INTO `sms_partners_two` VALUES(`854`, `0`, `30`, `0`, `0`, `0`, `0`, `195.189.60.30`);
INSERT INTO `sms_partners_two` VALUES(`855`, `0`, `30`, `0`, `0`, `0`, `0`, `178.93.22.47`);
INSERT INTO `sms_partners_two` VALUES(`856`, `0`, `30`, `0`, `0`, `0`, `0`, `89.28.81.53`);
INSERT INTO `sms_partners_two` VALUES(`857`, `0`, `30`, `0`, `0`, `0`, `0`, `194.44.188.151`);
INSERT INTO `sms_partners_two` VALUES(`858`, `0`, `30`, `0`, `0`, `0`, `0`, `78.61.150.217`);
INSERT INTO `sms_partners_two` VALUES(`859`, `0`, `30`, `0`, `0`, `0`, `0`, `159.224.26.169`);
INSERT INTO `sms_partners_two` VALUES(`860`, `0`, `30`, `0`, `0`, `0`, `0`, `90.150.214.198`);
INSERT INTO `sms_partners_two` VALUES(`861`, `0`, `30`, `0`, `0`, `0`, `0`, `188.17.98.112`);
INSERT INTO `sms_partners_two` VALUES(`862`, `0`, `30`, `0`, `0`, `0`, `0`, `95.86.219.42`);
INSERT INTO `sms_partners_two` VALUES(`863`, `0`, `30`, `0`, `0`, `0`, `0`, `95.158.58.97`);
INSERT INTO `sms_partners_two` VALUES(`864`, `0`, `30`, `0`, `0`, `0`, `0`, `109.187.27.96`);
INSERT INTO `sms_partners_two` VALUES(`865`, `0`, `30`, `0`, `0`, `0`, `0`, `93.84.50.88`);
INSERT INTO `sms_partners_two` VALUES(`866`, `0`, `30`, `0`, `0`, `0`, `0`, `213.87.122.6`);
INSERT INTO `sms_partners_two` VALUES(`867`, `0`, `0`, `0`, `0`, `0`, `0`, `213.87.122.6`);
INSERT INTO `sms_partners_two` VALUES(`868`, `0`, `30`, `0`, `0`, `0`, `0`, `94.248.1.218`);
INSERT INTO `sms_partners_two` VALUES(`869`, `0`, `30`, `0`, `0`, `0`, `0`, `92.252.230.26`);
INSERT INTO `sms_partners_two` VALUES(`870`, `0`, `30`, `0`, `0`, `0`, `0`, `46.164.136.111`);
INSERT INTO `sms_partners_two` VALUES(`871`, `0`, `30`, `0`, `0`, `0`, `0`, `92.112.231.190`);
INSERT INTO `sms_partners_two` VALUES(`872`, `0`, `30`, `0`, `0`, `0`, `0`, `31.162.66.131`);
INSERT INTO `sms_partners_two` VALUES(`873`, `0`, `30`, `0`, `0`, `0`, `0`, `46.98.106.54`);
INSERT INTO `sms_partners_two` VALUES(`874`, `0`, `30`, `0`, `0`, `0`, `0`, `176.101.13.104`);
INSERT INTO `sms_partners_two` VALUES(`875`, `0`, `30`, `0`, `0`, `0`, `0`, `46.55.89.135`);
INSERT INTO `sms_partners_two` VALUES(`876`, `0`, `30`, `0`, `0`, `0`, `0`, `193.110.115.194`);
INSERT INTO `sms_partners_two` VALUES(`877`, `0`, `30`, `0`, `0`, `0`, `0`, `176.215.70.105`);
INSERT INTO `sms_partners_two` VALUES(`878`, `0`, `30`, `0`, `0`, `0`, `0`, `95.57.137.229`);
INSERT INTO `sms_partners_two` VALUES(`879`, `0`, `30`, `0`, `0`, `0`, `0`, `91.124.137.8`);
INSERT INTO `sms_partners_two` VALUES(`880`, `0`, `30`, `0`, `0`, `0`, `0`, `95.104.74.14`);
INSERT INTO `sms_partners_two` VALUES(`881`, `0`, `30`, `0`, `0`, `0`, `0`, `178.137.102.28`);
INSERT INTO `sms_partners_two` VALUES(`882`, `0`, `30`, `0`, `0`, `0`, `0`, `37.52.61.181`);
INSERT INTO `sms_partners_two` VALUES(`883`, `0`, `30`, `0`, `0`, `0`, `0`, `188.116.154.13`);
INSERT INTO `sms_partners_two` VALUES(`884`, `0`, `30`, `0`, `0`, `0`, `0`, `217.20.179.205`);
INSERT INTO `sms_partners_two` VALUES(`885`, `0`, `30`, `0`, `0`, `0`, `0`, `95.53.45.151`);
INSERT INTO `sms_partners_two` VALUES(`886`, `0`, `30`, `0`, `0`, `0`, `0`, `213.87.135.13`);
INSERT INTO `sms_partners_two` VALUES(`887`, `0`, `30`, `0`, `0`, `0`, `0`, `46.216.187.135`);
INSERT INTO `sms_partners_two` VALUES(`888`, `0`, `30`, `0`, `0`, `0`, `0`, `178.177.99.166`);
INSERT INTO `sms_partners_two` VALUES(`889`, `0`, `30`, `0`, `0`, `0`, `0`, `95.137.198.134`);
INSERT INTO `sms_partners_two` VALUES(`890`, `0`, `30`, `0`, `0`, `0`, `0`, `31.162.210.46`);
INSERT INTO `sms_partners_two` VALUES(`891`, `0`, `30`, `0`, `0`, `0`, `0`, `93.85.169.55`);
INSERT INTO `sms_partners_two` VALUES(`892`, `0`, `30`, `0`, `0`, `0`, `0`, `178.150.51.195`);
INSERT INTO `sms_partners_two` VALUES(`893`, `0`, `30`, `0`, `0`, `0`, `0`, `193.25.121.94`);
INSERT INTO `sms_partners_two` VALUES(`894`, `0`, `30`, `0`, `0`, `0`, `0`, `37.229.53.121`);
INSERT INTO `sms_partners_two` VALUES(`895`, `0`, `30`, `0`, `0`, `0`, `0`, `178.125.104.6`);
INSERT INTO `sms_partners_two` VALUES(`896`, `0`, `30`, `0`, `0`, `0`, `0`, `188.134.37.47`);
INSERT INTO `sms_partners_two` VALUES(`897`, `0`, `30`, `0`, `0`, `0`, `0`, `195.206.233.94`);
INSERT INTO `sms_partners_two` VALUES(`898`, `0`, `30`, `0`, `0`, `0`, `0`, `194.44.38.114`);
INSERT INTO `sms_partners_two` VALUES(`899`, `0`, `30`, `0`, `0`, `0`, `0`, `82.52.63.166`);
INSERT INTO `sms_partners_two` VALUES(`900`, `0`, `30`, `0`, `0`, `0`, `0`, `217.66.152.14`);
INSERT INTO `sms_partners_two` VALUES(`901`, `0`, `30`, `0`, `0`, `0`, `0`, `78.36.247.247`);
INSERT INTO `sms_partners_two` VALUES(`902`, `0`, `30`, `0`, `0`, `0`, `0`, `178.89.207.88`);
INSERT INTO `sms_partners_two` VALUES(`903`, `0`, `0`, `0`, `0`, `0`, `0`, `217.66.152.14`);
INSERT INTO `sms_partners_two` VALUES(`904`, `0`, `30`, `0`, `0`, `0`, `0`, `178.93.69.164`);
INSERT INTO `sms_partners_two` VALUES(`905`, `0`, `30`, `0`, `0`, `0`, `0`, `158.181.30.164`);
INSERT INTO `sms_partners_two` VALUES(`906`, `0`, `30`, `0`, `0`, `0`, `0`, `213.111.131.65`);
INSERT INTO `sms_partners_two` VALUES(`907`, `0`, `30`, `0`, `0`, `0`, `0`, `85.95.188.57`);
INSERT INTO `sms_partners_two` VALUES(`908`, `0`, `30`, `0`, `0`, `0`, `0`, `178.123.151.16`);
INSERT INTO `sms_partners_two` VALUES(`909`, `0`, `30`, `0`, `0`, `0`, `0`, `77.122.5.138`);
INSERT INTO `sms_partners_two` VALUES(`910`, `0`, `30`, `0`, `0`, `0`, `0`, `46.211.251.113`);
INSERT INTO `sms_partners_two` VALUES(`911`, `0`, `30`, `0`, `0`, `0`, `0`, `95.67.197.114`);
INSERT INTO `sms_partners_two` VALUES(`912`, `0`, `30`, `0`, `0`, `0`, `0`, `176.100.6.22`);
INSERT INTO `sms_partners_two` VALUES(`913`, `0`, `30`, `0`, `0`, `0`, `0`, `91.201.177.58`);
INSERT INTO `sms_partners_two` VALUES(`914`, `0`, `30`, `0`, `0`, `0`, `0`, `213.87.132.107`);
INSERT INTO `sms_partners_two` VALUES(`915`, `0`, `30`, `0`, `0`, `0`, `0`, `77.232.159.122`);
INSERT INTO `sms_partners_two` VALUES(`916`, `0`, `30`, `0`, `0`, `0`, `0`, `95.133.26.44`);
INSERT INTO `sms_partners_two` VALUES(`917`, `0`, `30`, `0`, `0`, `0`, `0`, `176.8.16.34`);
INSERT INTO `sms_partners_two` VALUES(`918`, `0`, `30`, `0`, `0`, `0`, `0`, `93.79.77.58`);
INSERT INTO `sms_partners_two` VALUES(`919`, `0`, `30`, `0`, `0`, `0`, `0`, `95.134.182.226`);
INSERT INTO `sms_partners_two` VALUES(`920`, `0`, `30`, `0`, `0`, `0`, `0`, `87.239.29.55`);
INSERT INTO `sms_partners_two` VALUES(`921`, `0`, `30`, `0`, `0`, `0`, `0`, `31.131.77.207`);
INSERT INTO `sms_partners_two` VALUES(`922`, `0`, `30`, `0`, `0`, `0`, `0`, `89.178.124.210`);
INSERT INTO `sms_partners_two` VALUES(`923`, `0`, `30`, `0`, `0`, `0`, `0`, `92.114.216.253`);
INSERT INTO `sms_partners_two` VALUES(`924`, `0`, `30`, `0`, `0`, `0`, `0`, `95.53.161.172`);
INSERT INTO `sms_partners_two` VALUES(`925`, `0`, `30`, `0`, `0`, `0`, `0`, `212.92.245.120`);
INSERT INTO `sms_partners_two` VALUES(`926`, `0`, `30`, `0`, `0`, `0`, `0`, `193.34.61.113`);
INSERT INTO `sms_partners_two` VALUES(`927`, `0`, `30`, `0`, `0`, `0`, `0`, `46.44.55.223`);
INSERT INTO `sms_partners_two` VALUES(`928`, `0`, `30`, `0`, `0`, `0`, `0`, `178.127.153.93`);
INSERT INTO `sms_partners_two` VALUES(`929`, `0`, `30`, `0`, `0`, `0`, `0`, `37.229.177.96`);
INSERT INTO `sms_partners_two` VALUES(`930`, `0`, `30`, `0`, `0`, `0`, `0`, `217.27.150.118`);
INSERT INTO `sms_partners_two` VALUES(`931`, `0`, `30`, `0`, `0`, `0`, `0`, `199.19.249.196`);
INSERT INTO `sms_partners_two` VALUES(`932`, `0`, `30`, `0`, `0`, `0`, `0`, `90.151.44.150`);
INSERT INTO `sms_partners_two` VALUES(`933`, `0`, `30`, `0`, `0`, `0`, `0`, `85.192.166.187`);
INSERT INTO `sms_partners_two` VALUES(`934`, `0`, `30`, `0`, `0`, `0`, `0`, `109.61.160.35`);
INSERT INTO `sms_partners_two` VALUES(`935`, `0`, `30`, `0`, `0`, `0`, `0`, `83.222.75.243`);
INSERT INTO `sms_partners_two` VALUES(`936`, `0`, `30`, `0`, `0`, `0`, `0`, `86.111.88.53`);
INSERT INTO `sms_partners_two` VALUES(`937`, `0`, `30`, `0`, `0`, `0`, `0`, `91.132.202.89`);
INSERT INTO `sms_partners_two` VALUES(`938`, `0`, `30`, `0`, `0`, `0`, `0`, `178.122.221.223`);
INSERT INTO `sms_partners_two` VALUES(`939`, `0`, `30`, `0`, `0`, `0`, `0`, `94.231.72.27`);
INSERT INTO `sms_partners_two` VALUES(`940`, `0`, `30`, `0`, `0`, `0`, `0`, `130.0.13.100`);
INSERT INTO `sms_partners_two` VALUES(`941`, `0`, `30`, `0`, `0`, `0`, `0`, `95.81.9.126`);
INSERT INTO `sms_partners_two` VALUES(`942`, `0`, `30`, `0`, `0`, `0`, `0`, `178.121.104.252`);
INSERT INTO `sms_partners_two` VALUES(`943`, `0`, `30`, `0`, `0`, `0`, `0`, `37.52.42.2`);
INSERT INTO `sms_partners_two` VALUES(`944`, `0`, `30`, `0`, `0`, `0`, `0`, `178.95.102.186`);
INSERT INTO `sms_partners_two` VALUES(`945`, `0`, `30`, `0`, `0`, `0`, `0`, `89.23.154.133`);
INSERT INTO `sms_partners_two` VALUES(`946`, `0`, `30`, `0`, `0`, `0`, `0`, `84.54.101.62`);
INSERT INTO `sms_partners_two` VALUES(`947`, `0`, `30`, `0`, `0`, `0`, `0`, `93.125.37.22`);
INSERT INTO `sms_partners_two` VALUES(`948`, `0`, `30`, `0`, `0`, `0`, `0`, `95.79.38.111`);
INSERT INTO `sms_partners_two` VALUES(`949`, `0`, `30`, `0`, `0`, `0`, `0`, `95.169.102.137`);
INSERT INTO `sms_partners_two` VALUES(`950`, `0`, `30`, `0`, `0`, `0`, `0`, `95.54.27.223`);
INSERT INTO `sms_partners_two` VALUES(`951`, `0`, `30`, `0`, `0`, `0`, `0`, `46.167.115.64`);
INSERT INTO `sms_partners_two` VALUES(`952`, `0`, `30`, `0`, `0`, `0`, `0`, `92.127.163.206`);
INSERT INTO `sms_partners_two` VALUES(`953`, `0`, `30`, `0`, `0`, `0`, `0`, `95.153.124.145`);
INSERT INTO `sms_partners_two` VALUES(`954`, `0`, `30`, `0`, `0`, `0`, `0`, `90.151.214.245`);
INSERT INTO `sms_partners_two` VALUES(`955`, `0`, `30`, `0`, `0`, `0`, `0`, `213.111.144.204`);
INSERT INTO `sms_partners_two` VALUES(`956`, `0`, `30`, `0`, `0`, `0`, `0`, `188.35.130.216`);
INSERT INTO `sms_partners_two` VALUES(`957`, `0`, `30`, `0`, `0`, `0`, `0`, `95.52.24.205`);
INSERT INTO `sms_partners_two` VALUES(`958`, `0`, `30`, `0`, `0`, `0`, `0`, `178.121.156.97`);
INSERT INTO `sms_partners_two` VALUES(`959`, `0`, `30`, `0`, `0`, `0`, `0`, `46.247.191.154`);
INSERT INTO `sms_partners_two` VALUES(`960`, `0`, `30`, `0`, `0`, `0`, `0`, `85.26.207.230`);
INSERT INTO `sms_partners_two` VALUES(`961`, `0`, `30`, `0`, `0`, `0`, `0`, `95.69.229.2`);
INSERT INTO `sms_partners_two` VALUES(`962`, `0`, `30`, `0`, `0`, `0`, `0`, `37.45.211.249`);
INSERT INTO `sms_partners_two` VALUES(`963`, `0`, `30`, `0`, `0`, `0`, `0`, `178.94.229.23`);
INSERT INTO `sms_partners_two` VALUES(`964`, `0`, `30`, `0`, `0`, `0`, `0`, `109.171.45.31`);
INSERT INTO `sms_partners_two` VALUES(`965`, `0`, `30`, `0`, `0`, `0`, `0`, `109.195.150.220`);
INSERT INTO `sms_partners_two` VALUES(`966`, `0`, `30`, `0`, `0`, `0`, `0`, `46.159.164.96`);
INSERT INTO `sms_partners_two` VALUES(`967`, `0`, `30`, `0`, `0`, `0`, `0`, `194.44.77.85`);
INSERT INTO `sms_partners_two` VALUES(`968`, `0`, `30`, `0`, `0`, `0`, `0`, `81.162.72.70`);
INSERT INTO `sms_partners_two` VALUES(`969`, `0`, `30`, `0`, `0`, `0`, `0`, `2.93.131.248`);
INSERT INTO `sms_partners_two` VALUES(`970`, `0`, `30`, `0`, `0`, `0`, `0`, `95.111.162.52`);
INSERT INTO `sms_partners_two` VALUES(`971`, `0`, `30`, `0`, `0`, `0`, `0`, `194.1.193.24`);
INSERT INTO `sms_partners_two` VALUES(`972`, `0`, `30`, `0`, `0`, `0`, `0`, `95.104.242.104`);
INSERT INTO `sms_partners_two` VALUES(`973`, `0`, `30`, `0`, `0`, `0`, `0`, `176.116.212.133`);
INSERT INTO `sms_partners_two` VALUES(`974`, `0`, `30`, `0`, `0`, `0`, `0`, `95.135.118.139`);
INSERT INTO `sms_partners_two` VALUES(`975`, `0`, `30`, `0`, `0`, `0`, `0`, `178.126.163.236`);
INSERT INTO `sms_partners_two` VALUES(`976`, `0`, `30`, `0`, `0`, `0`, `0`, `93.85.175.37`);
INSERT INTO `sms_partners_two` VALUES(`977`, `0`, `30`, `0`, `0`, `0`, `0`, `176.107.88.189`);
INSERT INTO `sms_partners_two` VALUES(`978`, `0`, `30`, `0`, `0`, `0`, `0`, `87.252.227.125`);
INSERT INTO `sms_partners_two` VALUES(`979`, `0`, `30`, `0`, `0`, `0`, `0`, `77.120.168.193`);
INSERT INTO `sms_partners_two` VALUES(`980`, `0`, `30`, `0`, `0`, `0`, `0`, `95.153.88.91`);
INSERT INTO `sms_partners_two` VALUES(`981`, `0`, `30`, `0`, `0`, `0`, `0`, `178.95.198.201`);
INSERT INTO `sms_partners_two` VALUES(`982`, `0`, `30`, `0`, `0`, `0`, `0`, `46.20.185.60`);
INSERT INTO `sms_partners_two` VALUES(`983`, `0`, `30`, `0`, `0`, `0`, `0`, `176.214.157.80`);
INSERT INTO `sms_partners_two` VALUES(`984`, `0`, `30`, `0`, `0`, `0`, `0`, `92.112.158.38`);
INSERT INTO `sms_partners_two` VALUES(`985`, `0`, `30`, `0`, `0`, `0`, `0`, `178.137.126.245`);
INSERT INTO `sms_partners_two` VALUES(`986`, `0`, `30`, `0`, `0`, `0`, `0`, `37.99.94.20`);
INSERT INTO `sms_partners_two` VALUES(`987`, `0`, `30`, `0`, `0`, `0`, `0`, `89.146.89.200`);
INSERT INTO `sms_partners_two` VALUES(`988`, `0`, `30`, `0`, `0`, `0`, `0`, `46.211.47.26`);
INSERT INTO `sms_partners_two` VALUES(`989`, `0`, `30`, `0`, `0`, `0`, `0`, `213.80.217.153`);
INSERT INTO `sms_partners_two` VALUES(`990`, `0`, `30`, `0`, `0`, `0`, `0`, `85.254.183.8`);
INSERT INTO `sms_partners_two` VALUES(`991`, `0`, `30`, `0`, `0`, `0`, `0`, `37.113.148.67`);
INSERT INTO `sms_partners_two` VALUES(`992`, `0`, `30`, `0`, `0`, `0`, `0`, `188.232.193.2`);
INSERT INTO `sms_partners_two` VALUES(`993`, `0`, `30`, `0`, `0`, `0`, `0`, `213.87.130.110`);
INSERT INTO `sms_partners_two` VALUES(`994`, `0`, `30`, `0`, `0`, `0`, `0`, `95.79.43.239`);
INSERT INTO `sms_partners_two` VALUES(`995`, `0`, `30`, `0`, `0`, `0`, `0`, `178.172.210.200`);
INSERT INTO `sms_partners_two` VALUES(`996`, `0`, `30`, `0`, `0`, `0`, `0`, `95.56.187.242`);
INSERT INTO `sms_partners_two` VALUES(`997`, `0`, `30`, `0`, `0`, `0`, `0`, `78.106.118.56`);
INSERT INTO `sms_partners_two` VALUES(`998`, `0`, `30`, `0`, `0`, `0`, `0`, `93.84.42.210`);
INSERT INTO `sms_partners_two` VALUES(`999`, `0`, `30`, `0`, `0`, `0`, `0`, `46.211.104.239`);
INSERT INTO `sms_partners_two` VALUES(`1000`, `0`, `30`, `0`, `0`, `0`, `0`, `178.206.212.99`);
INSERT INTO `sms_partners_two` VALUES(`1001`, `0`, `30`, `0`, `0`, `0`, `0`, `109.254.49.19`);
INSERT INTO `sms_partners_two` VALUES(`1002`, `0`, `30`, `0`, `0`, `0`, `0`, `46.63.11.117`);
INSERT INTO `sms_partners_two` VALUES(`1003`, `0`, `30`, `0`, `0`, `0`, `0`, `95.26.175.206`);
INSERT INTO `sms_partners_two` VALUES(`1004`, `0`, `30`, `0`, `0`, `0`, `0`, `87.110.61.72`);
INSERT INTO `sms_partners_two` VALUES(`1005`, `0`, `30`, `0`, `0`, `0`, `0`, `178.125.120.194`);
INSERT INTO `sms_partners_two` VALUES(`1006`, `0`, `30`, `0`, `0`, `0`, `0`, `87.226.222.114`);
INSERT INTO `sms_partners_two` VALUES(`1007`, `0`, `30`, `0`, `0`, `0`, `0`, `92.36.74.72`);
INSERT INTO `sms_partners_two` VALUES(`1008`, `0`, `30`, `0`, `0`, `0`, `0`, `109.187.237.241`);
INSERT INTO `sms_partners_two` VALUES(`1009`, `0`, `30`, `0`, `0`, `0`, `0`, `193.105.7.121`);
INSERT INTO `sms_partners_two` VALUES(`1010`, `0`, `30`, `0`, `0`, `0`, `0`, `95.153.72.30`);
INSERT INTO `sms_partners_two` VALUES(`1011`, `0`, `30`, `0`, `0`, `0`, `0`, `84.252.19.31`);
INSERT INTO `sms_partners_two` VALUES(`1012`, `0`, `30`, `0`, `0`, `0`, `0`, `46.70.254.174`);
INSERT INTO `sms_partners_two` VALUES(`1013`, `0`, `30`, `0`, `0`, `0`, `0`, `188.237.40.90`);
INSERT INTO `sms_partners_two` VALUES(`1014`, `0`, `30`, `0`, `0`, `0`, `0`, `95.132.79.87`);
INSERT INTO `sms_partners_two` VALUES(`1015`, `0`, `30`, `0`, `0`, `0`, `0`, `31.207.145.7`);
INSERT INTO `sms_partners_two` VALUES(`1016`, `0`, `30`, `0`, `0`, `0`, `0`, `176.215.103.200`);
INSERT INTO `sms_partners_two` VALUES(`1017`, `0`, `30`, `0`, `0`, `0`, `0`, `109.122.11.233`);
INSERT INTO `sms_partners_two` VALUES(`1018`, `0`, `30`, `0`, `0`, `0`, `0`, `95.59.228.185`);
INSERT INTO `sms_partners_two` VALUES(`1019`, `0`, `30`, `0`, `0`, `0`, `0`, `194.28.64.150`);
INSERT INTO `sms_partners_two` VALUES(`1020`, `0`, `30`, `0`, `0`, `0`, `0`, `95.53.163.227`);
INSERT INTO `sms_partners_two` VALUES(`1021`, `0`, `30`, `0`, `0`, `0`, `0`, `46.211.123.114`);
INSERT INTO `sms_partners_two` VALUES(`1022`, `0`, `30`, `0`, `0`, `0`, `0`, `46.158.70.214`);
INSERT INTO `sms_partners_two` VALUES(`1023`, `0`, `30`, `0`, `0`, `0`, `0`, `46.118.108.81`);
INSERT INTO `sms_partners_two` VALUES(`1024`, `0`, `30`, `0`, `0`, `0`, `0`, `178.35.197.92`);
INSERT INTO `sms_partners_two` VALUES(`1025`, `0`, `30`, `0`, `0`, `0`, `0`, `109.75.204.10`);
INSERT INTO `sms_partners_two` VALUES(`1026`, `0`, `30`, `0`, `0`, `0`, `0`, `188.17.65.230`);
INSERT INTO `sms_partners_two` VALUES(`1027`, `0`, `30`, `0`, `0`, `0`, `0`, `91.211.128.211`);
INSERT INTO `sms_partners_two` VALUES(`1028`, `0`, `30`, `0`, `0`, `0`, `0`, `94.251.38.237`);
INSERT INTO `sms_partners_two` VALUES(`1029`, `0`, `30`, `0`, `0`, `0`, `0`, `46.70.3.173`);
INSERT INTO `sms_partners_two` VALUES(`1030`, `0`, `30`, `0`, `0`, `0`, `0`, `62.182.206.220`);
INSERT INTO `sms_partners_two` VALUES(`1031`, `0`, `30`, `0`, `0`, `0`, `0`, `95.24.243.143`);
INSERT INTO `sms_partners_two` VALUES(`1032`, `0`, `30`, `0`, `0`, `0`, `0`, `95.111.173.128`);
INSERT INTO `sms_partners_two` VALUES(`1033`, `0`, `30`, `0`, `0`, `0`, `0`, `195.211.86.198`);
INSERT INTO `sms_partners_two` VALUES(`1034`, `0`, `30`, `0`, `0`, `0`, `0`, `109.237.234.150`);
INSERT INTO `sms_partners_two` VALUES(`1035`, `0`, `30`, `0`, `0`, `0`, `0`, `178.165.45.43`);
INSERT INTO `sms_partners_two` VALUES(`1036`, `0`, `30`, `0`, `0`, `0`, `0`, `188.230.116.16`);
INSERT INTO `sms_partners_two` VALUES(`1037`, `0`, `30`, `0`, `0`, `0`, `0`, `46.150.76.178`);
INSERT INTO `sms_partners_two` VALUES(`1038`, `0`, `30`, `0`, `0`, `0`, `0`, `92.100.175.37`);
INSERT INTO `sms_partners_two` VALUES(`1039`, `0`, `0`, `0`, `0`, `0`, `0`, `92.100.175.37`);
INSERT INTO `sms_partners_two` VALUES(`1040`, `0`, `30`, `0`, `0`, `0`, `0`, `109.75.193.159`);
INSERT INTO `sms_partners_two` VALUES(`1041`, `0`, `30`, `0`, `0`, `0`, `0`, `31.128.136.202`);
INSERT INTO `sms_partners_two` VALUES(`1042`, `0`, `30`, `0`, `0`, `0`, `0`, `178.47.90.61`);
INSERT INTO `sms_partners_two` VALUES(`1043`, `0`, `30`, `0`, `0`, `0`, `0`, `95.215.119.2`);
INSERT INTO `sms_partners_two` VALUES(`1044`, `0`, `30`, `0`, `0`, `0`, `0`, `178.177.19.48`);
INSERT INTO `sms_partners_two` VALUES(`1045`, `0`, `30`, `0`, `0`, `0`, `0`, `46.233.212.227`);
INSERT INTO `sms_partners_two` VALUES(`1046`, `0`, `30`, `0`, `0`, `0`, `0`, `188.16.10.160`);
INSERT INTO `sms_partners_two` VALUES(`1047`, `0`, `30`, `0`, `0`, `0`, `0`, `94.19.217.104`);
INSERT INTO `sms_partners_two` VALUES(`1048`, `0`, `30`, `0`, `0`, `0`, `0`, `37.45.150.210`);
INSERT INTO `sms_partners_two` VALUES(`1049`, `0`, `30`, `0`, `0`, `0`, `0`, `46.48.43.146`);
INSERT INTO `sms_partners_two` VALUES(`1050`, `0`, `30`, `0`, `0`, `0`, `0`, `31.163.50.120`);
INSERT INTO `sms_partners_two` VALUES(`1051`, `0`, `30`, `0`, `0`, `0`, `0`, `95.65.89.150`);
INSERT INTO `sms_partners_two` VALUES(`1052`, `0`, `30`, `0`, `0`, `0`, `0`, `78.111.63.92`);
INSERT INTO `sms_partners_two` VALUES(`1053`, `0`, `30`, `0`, `0`, `0`, `0`, `46.12.160.238`);
INSERT INTO `sms_partners_two` VALUES(`1054`, `0`, `30`, `0`, `0`, `0`, `0`, `92.113.242.158`);
INSERT INTO `sms_partners_two` VALUES(`1055`, `0`, `30`, `0`, `0`, `0`, `0`, `2.132.5.92`);
INSERT INTO `sms_partners_two` VALUES(`1056`, `0`, `30`, `0`, `0`, `0`, `0`, `31.135.137.158`);
INSERT INTO `sms_partners_two` VALUES(`1057`, `0`, `30`, `0`, `0`, `0`, `0`, `176.215.72.128`);
INSERT INTO `sms_partners_two` VALUES(`1058`, `0`, `30`, `0`, `0`, `0`, `0`, `87.110.212.212`);
INSERT INTO `sms_partners_two` VALUES(`1059`, `0`, `30`, `0`, `0`, `0`, `0`, `178.89.43.178`);
INSERT INTO `sms_partners_two` VALUES(`1060`, `0`, `30`, `0`, `0`, `0`, `0`, `178.120.207.194`);
INSERT INTO `sms_partners_two` VALUES(`1061`, `0`, `30`, `0`, `0`, `0`, `0`, `92.113.244.99`);
INSERT INTO `sms_partners_two` VALUES(`1062`, `0`, `30`, `0`, `0`, `0`, `0`, `178.121.226.138`);
INSERT INTO `sms_partners_two` VALUES(`1063`, `0`, `30`, `0`, `0`, `0`, `0`, `91.205.65.56`);
INSERT INTO `sms_partners_two` VALUES(`1064`, `0`, `30`, `0`, `0`, `0`, `0`, `95.134.46.172`);
INSERT INTO `sms_partners_two` VALUES(`1065`, `0`, `30`, `0`, `0`, `0`, `0`, `92.112.79.105`);
INSERT INTO `sms_partners_two` VALUES(`1066`, `0`, `30`, `0`, `0`, `0`, `0`, `193.159.85.37`);
INSERT INTO `sms_partners_two` VALUES(`1067`, `0`, `30`, `0`, `0`, `0`, `0`, `188.232.101.35`);
INSERT INTO `sms_partners_two` VALUES(`1068`, `0`, `30`, `0`, `0`, `0`, `0`, `91.201.144.107`);
INSERT INTO `sms_partners_two` VALUES(`1069`, `0`, `30`, `0`, `0`, `0`, `0`, `93.79.236.165`);
INSERT INTO `sms_partners_two` VALUES(`1070`, `0`, `0`, `0`, `0`, `0`, `0`, `93.79.236.165`);
INSERT INTO `sms_partners_two` VALUES(`1071`, `0`, `30`, `0`, `0`, `0`, `0`, `178.123.225.155`);
INSERT INTO `sms_partners_two` VALUES(`1072`, `0`, `30`, `0`, `0`, `0`, `0`, `83.149.34.220`);
INSERT INTO `sms_partners_two` VALUES(`1073`, `0`, `30`, `0`, `0`, `0`, `0`, `188.16.67.187`);
INSERT INTO `sms_partners_two` VALUES(`1074`, `0`, `30`, `0`, `0`, `0`, `0`, `193.151.13.38`);
INSERT INTO `sms_partners_two` VALUES(`1075`, `0`, `30`, `0`, `0`, `0`, `0`, `37.55.219.218`);
INSERT INTO `sms_partners_two` VALUES(`1076`, `0`, `30`, `0`, `0`, `0`, `0`, `95.104.135.71`);
INSERT INTO `sms_partners_two` VALUES(`1077`, `0`, `30`, `0`, `0`, `0`, `0`, `46.201.171.23`);
INSERT INTO `sms_partners_two` VALUES(`1078`, `0`, `30`, `0`, `0`, `0`, `0`, `83.149.3.104`);
INSERT INTO `sms_partners_two` VALUES(`1079`, `0`, `30`, `0`, `0`, `0`, `0`, `95.79.191.181`);
INSERT INTO `sms_partners_two` VALUES(`1080`, `0`, `30`, `0`, `0`, `0`, `0`, `46.70.228.231`);
INSERT INTO `sms_partners_two` VALUES(`1081`, `0`, `30`, `0`, `0`, `0`, `0`, `78.85.241.100`);
INSERT INTO `sms_partners_two` VALUES(`1082`, `0`, `30`, `0`, `0`, `0`, `0`, `178.78.134.96`);
INSERT INTO `sms_partners_two` VALUES(`1083`, `0`, `30`, `0`, `0`, `0`, `0`, `109.165.3.70`);
INSERT INTO `sms_partners_two` VALUES(`1084`, `0`, `30`, `0`, `0`, `0`, `0`, `213.87.129.129`);
INSERT INTO `sms_partners_two` VALUES(`1085`, `0`, `30`, `0`, `0`, `0`, `0`, `77.121.180.33`);
INSERT INTO `sms_partners_two` VALUES(`1086`, `0`, `30`, `0`, `0`, `0`, `0`, `95.153.177.152`);
INSERT INTO `sms_partners_two` VALUES(`1087`, `0`, `30`, `0`, `0`, `0`, `0`, `2.95.244.71`);
INSERT INTO `sms_partners_two` VALUES(`1088`, `0`, `30`, `0`, `0`, `0`, `0`, `178.92.70.98`);
INSERT INTO `sms_partners_two` VALUES(`1089`, `0`, `30`, `0`, `0`, `0`, `0`, `178.125.212.197`);
INSERT INTO `sms_partners_two` VALUES(`1090`, `0`, `30`, `0`, `0`, `0`, `0`, `176.215.181.2`);
INSERT INTO `sms_partners_two` VALUES(`1091`, `0`, `30`, `0`, `0`, `0`, `0`, `79.181.18.4`);
INSERT INTO `sms_partners_two` VALUES(`1092`, `0`, `30`, `0`, `0`, `0`, `0`, `95.135.140.210`);
INSERT INTO `sms_partners_two` VALUES(`1093`, `0`, `30`, `0`, `0`, `0`, `0`, `178.65.1.16`);
INSERT INTO `sms_partners_two` VALUES(`1094`, `0`, `30`, `0`, `0`, `0`, `0`, `94.41.27.250`);
INSERT INTO `sms_partners_two` VALUES(`1095`, `0`, `30`, `0`, `0`, `0`, `0`, `213.230.93.184`);
INSERT INTO `sms_partners_two` VALUES(`1096`, `0`, `30`, `0`, `0`, `0`, `0`, `81.1.130.228`);
INSERT INTO `sms_partners_two` VALUES(`1097`, `0`, `30`, `0`, `0`, `0`, `0`, `95.83.180.198`);
INSERT INTO `sms_partners_two` VALUES(`1098`, `0`, `30`, `0`, `0`, `0`, `0`, `193.106.40.69`);
INSERT INTO `sms_partners_two` VALUES(`1099`, `0`, `30`, `0`, `0`, `0`, `0`, `178.123.2.219`);
INSERT INTO `sms_partners_two` VALUES(`1100`, `0`, `30`, `0`, `0`, `0`, `0`, `62.73.102.123`);
INSERT INTO `sms_partners_two` VALUES(`1101`, `0`, `30`, `0`, `0`, `0`, `0`, `109.87.85.224`);
INSERT INTO `sms_partners_two` VALUES(`1102`, `0`, `30`, `0`, `0`, `0`, `0`, `193.32.21.126`);
INSERT INTO `sms_partners_two` VALUES(`1103`, `0`, `30`, `0`, `0`, `0`, `0`, `5.1.17.142`);
INSERT INTO `sms_partners_two` VALUES(`1104`, `0`, `30`, `0`, `0`, `0`, `0`, `95.42.47.224`);
INSERT INTO `sms_partners_two` VALUES(`1105`, `0`, `30`, `0`, `0`, `0`, `0`, `91.197.171.47`);
INSERT INTO `sms_partners_two` VALUES(`1106`, `0`, `30`, `0`, `0`, `0`, `0`, `213.109.2.36`);
INSERT INTO `sms_partners_two` VALUES(`1107`, `0`, `30`, `0`, `0`, `0`, `0`, `212.87.185.37`);
INSERT INTO `sms_partners_two` VALUES(`1108`, `0`, `30`, `0`, `0`, `0`, `0`, `46.191.171.121`);
INSERT INTO `sms_partners_two` VALUES(`1109`, `0`, `30`, `0`, `0`, `0`, `0`, `78.139.103.162`);
INSERT INTO `sms_partners_two` VALUES(`1110`, `0`, `0`, `0`, `0`, `0`, `0`, `78.139.103.162`);
INSERT INTO `sms_partners_two` VALUES(`1111`, `0`, `30`, `0`, `0`, `0`, `0`, `94.179.177.119`);
INSERT INTO `sms_partners_two` VALUES(`1112`, `0`, `30`, `0`, `0`, `0`, `0`, `37.110.126.52`);
INSERT INTO `sms_partners_two` VALUES(`1113`, `0`, `30`, `0`, `0`, `0`, `0`, `46.160.111.193`);
INSERT INTO `sms_partners_two` VALUES(`1114`, `0`, `30`, `0`, `0`, `0`, `0`, `195.189.16.125`);
INSERT INTO `sms_partners_two` VALUES(`1115`, `0`, `30`, `0`, `0`, `0`, `0`, `178.127.45.76`);
INSERT INTO `sms_partners_two` VALUES(`1116`, `0`, `30`, `0`, `0`, `0`, `0`, `178.127.34.57`);
INSERT INTO `sms_partners_two` VALUES(`1117`, `0`, `30`, `0`, `0`, `0`, `0`, `46.70.56.60`);
INSERT INTO `sms_partners_two` VALUES(`1118`, `0`, `30`, `0`, `0`, `0`, `0`, `178.206.169.163`);
INSERT INTO `sms_partners_two` VALUES(`1119`, `0`, `30`, `0`, `0`, `0`, `0`, `92.46.168.189`);
INSERT INTO `sms_partners_two` VALUES(`1120`, `0`, `30`, `0`, `0`, `0`, `0`, `31.40.211.173`);
INSERT INTO `sms_partners_two` VALUES(`1121`, `0`, `30`, `0`, `0`, `0`, `0`, `91.214.34.48`);
INSERT INTO `sms_partners_two` VALUES(`1122`, `0`, `30`, `0`, `0`, `0`, `0`, `93.127.40.241`);
INSERT INTO `sms_partners_two` VALUES(`1123`, `0`, `30`, `0`, `0`, `0`, `0`, `176.96.251.89`);
INSERT INTO `sms_partners_two` VALUES(`1124`, `0`, `30`, `0`, `0`, `0`, `0`, `128.70.125.27`);
INSERT INTO `sms_partners_two` VALUES(`1125`, `0`, `30`, `0`, `0`, `0`, `0`, `83.237.35.84`);
INSERT INTO `sms_partners_two` VALUES(`1126`, `0`, `30`, `0`, `0`, `0`, `0`, `92.113.154.41`);
INSERT INTO `sms_partners_two` VALUES(`1127`, `0`, `30`, `0`, `0`, `0`, `0`, `46.119.212.210`);
INSERT INTO `sms_partners_two` VALUES(`1128`, `0`, `30`, `0`, `0`, `0`, `0`, `37.55.4.189`);
INSERT INTO `sms_partners_two` VALUES(`1129`, `0`, `30`, `0`, `0`, `0`, `0`, `78.85.71.202`);
INSERT INTO `sms_partners_two` VALUES(`1130`, `0`, `30`, `0`, `0`, `0`, `0`, `146.247.32.128`);
INSERT INTO `sms_partners_two` VALUES(`1131`, `0`, `30`, `0`, `0`, `0`, `0`, `188.17.86.169`);
INSERT INTO `sms_partners_two` VALUES(`1132`, `0`, `30`, `0`, `0`, `0`, `0`, `109.94.17.140`);
INSERT INTO `sms_partners_two` VALUES(`1133`, `0`, `30`, `0`, `0`, `0`, `0`, `91.226.167.92`);
INSERT INTO `sms_partners_two` VALUES(`1134`, `0`, `30`, `0`, `0`, `0`, `0`, `88.135.239.21`);
INSERT INTO `sms_partners_two` VALUES(`1135`, `0`, `30`, `0`, `0`, `0`, `0`, `80.234.127.249`);
INSERT INTO `sms_partners_two` VALUES(`1136`, `0`, `30`, `0`, `0`, `0`, `0`, `178.125.141.219`);
INSERT INTO `sms_partners_two` VALUES(`1137`, `0`, `30`, `0`, `0`, `0`, `0`, `2.94.228.170`);
INSERT INTO `sms_partners_two` VALUES(`1138`, `32`, `30`, `0`, `20`, `10`, `0`, `176.36.148.253`);
INSERT INTO `sms_partners_two` VALUES(`1139`, `0`, `0`, `0`, `0`, `0`, `0`, `176.36.148.253`);
INSERT INTO `sms_partners_two` VALUES(`1140`, `0`, `30`, `0`, `0`, `0`, `0`, `178.123.81.135`);
INSERT INTO `sms_partners_two` VALUES(`1141`, `0`, `30`, `0`, `0`, `0`, `0`, `188.134.34.43`);
INSERT INTO `sms_partners_two` VALUES(`1142`, `0`, `30`, `0`, `0`, `0`, `0`, `213.87.139.84`);
INSERT INTO `sms_partners_two` VALUES(`1143`, `0`, `30`, `0`, `0`, `0`, `0`, `109.201.235.148`);
INSERT INTO `sms_partners_two` VALUES(`1144`, `0`, `30`, `0`, `0`, `0`, `0`, `85.26.241.86`);
INSERT INTO `sms_partners_two` VALUES(`1145`, `0`, `30`, `0`, `0`, `0`, `0`, `46.247.205.40`);
INSERT INTO `sms_partners_two` VALUES(`1146`, `0`, `30`, `0`, `0`, `0`, `0`, `37.19.178.91`);
INSERT INTO `sms_partners_two` VALUES(`1147`, `0`, `30`, `0`, `0`, `0`, `0`, `178.125.62.185`);
INSERT INTO `sms_partners_two` VALUES(`1148`, `0`, `30`, `0`, `0`, `0`, `0`, `80.242.97.250`);
INSERT INTO `sms_partners_two` VALUES(`1149`, `0`, `32`, `0`, `0`, `0`, `0`, `178.186.160.185`);
INSERT INTO `sms_partners_two` VALUES(`1150`, `0`, `32`, `0`, `0`, `0`, `0`, `79.140.244.137`);
INSERT INTO `sms_partners_two` VALUES(`1151`, `0`, `32`, `0`, `0`, `0`, `0`, `212.25.57.234`);
INSERT INTO `sms_partners_two` VALUES(`1152`, `0`, `30`, `0`, `0`, `0`, `0`, `86.57.244.149`);
INSERT INTO `sms_partners_two` VALUES(`1153`, `0`, `30`, `0`, `0`, `0`, `0`, `84.112.101.243`);
INSERT INTO `sms_partners_two` VALUES(`1154`, `0`, `30`, `0`, `0`, `0`, `0`, `31.131.215.141`);
INSERT INTO `sms_partners_two` VALUES(`1155`, `0`, `30`, `0`, `0`, `0`, `0`, `178.123.94.114`);
INSERT INTO `sms_partners_two` VALUES(`1156`, `0`, `32`, `0`, `0`, `0`, `0`, `178.94.222.17`);
INSERT INTO `sms_partners_two` VALUES(`1157`, `0`, `32`, `0`, `0`, `0`, `0`, `94.242.169.164`);
INSERT INTO `sms_partners_two` VALUES(`1158`, `0`, `30`, `0`, `0`, `0`, `0`, `178.123.8.126`);
INSERT INTO `sms_partners_two` VALUES(`1159`, `0`, `30`, `0`, `0`, `0`, `0`, `91.201.177.82`);
INSERT INTO `sms_partners_two` VALUES(`1160`, `0`, `32`, `0`, `0`, `0`, `0`, `46.226.163.11`);
INSERT INTO `sms_partners_two` VALUES(`1161`, `0`, `30`, `0`, `0`, `0`, `0`, `95.136.32.135`);
INSERT INTO `sms_partners_two` VALUES(`1162`, `0`, `32`, `0`, `0`, `0`, `0`, `151.0.19.68`);
INSERT INTO `sms_partners_two` VALUES(`1163`, `0`, `30`, `0`, `0`, `0`, `0`, `109.185.237.87`);
INSERT INTO `sms_partners_two` VALUES(`1164`, `0`, `30`, `0`, `0`, `0`, `0`, `85.26.233.7`);
INSERT INTO `sms_partners_two` VALUES(`1165`, `0`, `30`, `0`, `0`, `0`, `0`, `109.75.207.31`);
INSERT INTO `sms_partners_two` VALUES(`1166`, `0`, `30`, `0`, `0`, `0`, `0`, `76.171.119.116`);
INSERT INTO `sms_partners_two` VALUES(`1167`, `0`, `30`, `0`, `0`, `0`, `0`, `95.189.50.154`);
INSERT INTO `sms_partners_two` VALUES(`1168`, `0`, `30`, `0`, `0`, `0`, `0`, `178.123.205.3`);
INSERT INTO `sms_partners_two` VALUES(`1169`, `0`, `32`, `0`, `0`, `0`, `0`, `178.151.59.213`);
INSERT INTO `sms_partners_two` VALUES(`1170`, `0`, `32`, `0`, `0`, `0`, `0`, `178.122.51.74`);
INSERT INTO `sms_partners_two` VALUES(`1171`, `0`, `30`, `0`, `0`, `0`, `0`, `93.120.240.110`);
INSERT INTO `sms_partners_two` VALUES(`1172`, `0`, `30`, `0`, `0`, `0`, `0`, `109.252.103.58`);
INSERT INTO `sms_partners_two` VALUES(`1173`, `0`, `32`, `0`, `0`, `0`, `0`, `92.126.40.184`);
INSERT INTO `sms_partners_two` VALUES(`1174`, `0`, `30`, `0`, `0`, `0`, `0`, `46.109.83.54`);
INSERT INTO `sms_partners_two` VALUES(`1175`, `0`, `30`, `0`, `0`, `0`, `0`, `46.98.13.60`);
INSERT INTO `sms_partners_two` VALUES(`1176`, `0`, `30`, `0`, `0`, `0`, `0`, `178.93.161.7`);
INSERT INTO `sms_partners_two` VALUES(`1177`, `0`, `30`, `0`, `0`, `0`, `0`, `93.186.209.163`);
INSERT INTO `sms_partners_two` VALUES(`1178`, `0`, `30`, `0`, `0`, `0`, `0`, `95.133.48.170`);
INSERT INTO `sms_partners_two` VALUES(`1179`, `0`, `30`, `0`, `0`, `0`, `0`, `85.175.171.100`);
INSERT INTO `sms_partners_two` VALUES(`1180`, `0`, `30`, `0`, `0`, `0`, `0`, `78.25.169.34`);
INSERT INTO `sms_partners_two` VALUES(`1181`, `0`, `30`, `0`, `0`, `0`, `0`, `178.120.105.194`);
INSERT INTO `sms_partners_two` VALUES(`1182`, `33`, `30`, `0`, `20`, `10`, `0`, `178.94.33.134`);
INSERT INTO `sms_partners_two` VALUES(`1183`, `0`, `30`, `0`, `0`, `0`, `0`, `178.94.33.134`);
INSERT INTO `sms_partners_two` VALUES(`1184`, `0`, `0`, `0`, `0`, `0`, `0`, `178.94.33.134`);
INSERT INTO `sms_partners_two` VALUES(`1185`, `0`, `32`, `0`, `0`, `0`, `0`, `195.182.194.212`);
INSERT INTO `sms_partners_two` VALUES(`1186`, `0`, `32`, `0`, `0`, `0`, `0`, `109.227.96.147`);
INSERT INTO `sms_partners_two` VALUES(`1187`, `0`, `30`, `0`, `0`, `0`, `0`, `109.200.227.64`);
INSERT INTO `sms_partners_two` VALUES(`1188`, `0`, `32`, `0`, `0`, `0`, `0`, `178.129.230.178`);
INSERT INTO `sms_partners_two` VALUES(`1189`, `0`, `30`, `0`, `0`, `0`, `0`, `188.32.122.197`);
INSERT INTO `sms_partners_two` VALUES(`1190`, `0`, `32`, `0`, `0`, `0`, `0`, `195.16.79.18`);
INSERT INTO `sms_partners_two` VALUES(`1191`, `0`, `30`, `0`, `0`, `0`, `0`, `94.242.186.141`);
INSERT INTO `sms_partners_two` VALUES(`1192`, `0`, `30`, `0`, `0`, `0`, `0`, `95.132.119.248`);
INSERT INTO `sms_partners_two` VALUES(`1193`, `0`, `30`, `0`, `0`, `0`, `0`, `178.165.120.190`);
INSERT INTO `sms_partners_two` VALUES(`1194`, `0`, `30`, `0`, `0`, `0`, `0`, `109.237.225.225`);
INSERT INTO `sms_partners_two` VALUES(`1195`, `0`, `32`, `0`, `0`, `0`, `0`, `176.36.148.253`);
INSERT INTO `sms_partners_two` VALUES(`1196`, `0`, `30`, `0`, `0`, `0`, `0`, `46.53.195.55`);
INSERT INTO `sms_partners_two` VALUES(`1197`, `0`, `0`, `0`, `0`, `0`, `0`, `93.79.155.229`);
INSERT INTO `sms_partners_two` VALUES(`1198`, `0`, `30`, `0`, `0`, `0`, `0`, `212.22.197.131`);
INSERT INTO `sms_partners_two` VALUES(`1199`, `0`, `30`, `0`, `0`, `0`, `0`, `83.149.48.48`);
INSERT INTO `sms_partners_two` VALUES(`1200`, `0`, `30`, `0`, `0`, `0`, `0`, `212.2.232.29`);
INSERT INTO `sms_partners_two` VALUES(`1201`, `0`, `30`, `0`, `0`, `0`, `0`, `95.135.71.191`);
INSERT INTO `sms_partners_two` VALUES(`1202`, `0`, `30`, `0`, `0`, `0`, `0`, `178.123.145.62`);
INSERT INTO `sms_partners_two` VALUES(`1203`, `0`, `30`, `0`, `0`, `0`, `0`, `94.231.160.239`);
INSERT INTO `sms_partners_two` VALUES(`1204`, `0`, `30`, `0`, `0`, `0`, `0`, `193.160.225.55`);
INSERT INTO `sms_partners_two` VALUES(`1205`, `0`, `32`, `0`, `0`, `0`, `0`, `37.110.108.157`);
INSERT INTO `sms_partners_two` VALUES(`1206`, `0`, `30`, `0`, `0`, `0`, `0`, `46.33.52.101`);
INSERT INTO `sms_partners_two` VALUES(`1207`, `0`, `30`, `0`, `0`, `0`, `0`, `213.138.68.62`);
INSERT INTO `sms_partners_two` VALUES(`1208`, `0`, `30`, `0`, `0`, `0`, `0`, `95.135.177.75`);
INSERT INTO `sms_partners_two` VALUES(`1209`, `0`, `30`, `0`, `0`, `0`, `0`, `91.185.0.235`);
INSERT INTO `sms_partners_two` VALUES(`1210`, `0`, `30`, `0`, `0`, `0`, `0`, `46.39.35.188`);
INSERT INTO `sms_partners_two` VALUES(`1211`, `0`, `30`, `0`, `0`, `0`, `0`, `77.121.169.169`);
INSERT INTO `sms_partners_two` VALUES(`1212`, `0`, `30`, `0`, `0`, `0`, `0`, `93.175.200.227`);
INSERT INTO `sms_partners_two` VALUES(`1213`, `0`, `30`, `0`, `0`, `0`, `0`, `212.55.66.176`);
INSERT INTO `sms_partners_two` VALUES(`1214`, `0`, `30`, `0`, `0`, `0`, `0`, `46.229.140.97`);
INSERT INTO `sms_partners_two` VALUES(`1215`, `0`, `30`, `0`, `0`, `0`, `0`, `2.60.122.78`);
INSERT INTO `sms_partners_two` VALUES(`1216`, `0`, `30`, `0`, `0`, `0`, `0`, `188.130.221.137`);
INSERT INTO `sms_partners_two` VALUES(`1217`, `0`, `30`, `0`, `0`, `0`, `0`, `46.0.131.202`);
INSERT INTO `sms_partners_two` VALUES(`1218`, `0`, `30`, `0`, `0`, `0`, `0`, `95.135.48.234`);
INSERT INTO `sms_partners_two` VALUES(`1219`, `0`, `30`, `0`, `0`, `0`, `0`, `83.149.37.210`);
INSERT INTO `sms_partners_two` VALUES(`1220`, `0`, `30`, `0`, `0`, `0`, `0`, `178.120.46.52`);
INSERT INTO `sms_partners_two` VALUES(`1221`, `0`, `30`, `0`, `0`, `0`, `0`, `95.59.246.19`);
INSERT INTO `sms_partners_two` VALUES(`1222`, `0`, `30`, `0`, `0`, `0`, `0`, `195.114.250.254`);
INSERT INTO `sms_partners_two` VALUES(`1223`, `0`, `30`, `0`, `0`, `0`, `0`, `192.162.234.43`);
INSERT INTO `sms_partners_two` VALUES(`1224`, `0`, `30`, `0`, `0`, `0`, `0`, `92.101.71.214`);
INSERT INTO `sms_partners_two` VALUES(`1225`, `0`, `30`, `0`, `0`, `0`, `0`, `212.90.170.234`);
INSERT INTO `sms_partners_two` VALUES(`1226`, `0`, `0`, `0`, `0`, `0`, `0`, `91.122.94.172`);
INSERT INTO `sms_partners_two` VALUES(`1227`, `0`, `30`, `0`, `0`, `0`, `0`, `178.124.245.51`);
INSERT INTO `sms_partners_two` VALUES(`1228`, `0`, `32`, `0`, `0`, `0`, `0`, `91.90.34.1`);
INSERT INTO `sms_partners_two` VALUES(`1229`, `0`, `30`, `0`, `0`, `0`, `0`, `31.128.147.202`);
INSERT INTO `sms_partners_two` VALUES(`1230`, `0`, `30`, `0`, `0`, `0`, `0`, `46.174.246.196`);
INSERT INTO `sms_partners_two` VALUES(`1231`, `0`, `30`, `0`, `0`, `0`, `0`, `62.122.71.250`);
INSERT INTO `sms_partners_two` VALUES(`1232`, `0`, `30`, `0`, `0`, `0`, `0`, `77.40.82.23`);
INSERT INTO `sms_partners_two` VALUES(`1233`, `0`, `30`, `0`, `0`, `0`, `0`, `85.196.211.153`);
INSERT INTO `sms_partners_two` VALUES(`1234`, `0`, `30`, `0`, `0`, `0`, `0`, `95.69.220.93`);
INSERT INTO `sms_partners_two` VALUES(`1235`, `0`, `30`, `0`, `0`, `0`, `0`, `109.174.114.31`);
INSERT INTO `sms_partners_two` VALUES(`1236`, `0`, `30`, `0`, `0`, `0`, `0`, `46.119.174.12`);
INSERT INTO `sms_partners_two` VALUES(`1237`, `0`, `30`, `0`, `0`, `0`, `0`, `79.139.248.204`);
INSERT INTO `sms_partners_two` VALUES(`1238`, `0`, `30`, `0`, `0`, `0`, `0`, `188.230.45.21`);
INSERT INTO `sms_partners_two` VALUES(`1239`, `0`, `30`, `0`, `0`, `0`, `0`, `178.120.78.33`);
INSERT INTO `sms_partners_two` VALUES(`1240`, `0`, `30`, `0`, `0`, `0`, `0`, `93.181.196.98`);
INSERT INTO `sms_partners_two` VALUES(`1241`, `0`, `30`, `0`, `0`, `0`, `0`, `95.57.12.101`);
INSERT INTO `sms_partners_two` VALUES(`1242`, `0`, `30`, `0`, `0`, `0`, `0`, `109.162.101.131`);
INSERT INTO `sms_partners_two` VALUES(`1243`, `0`, `30`, `0`, `0`, `0`, `0`, `92.112.85.195`);
INSERT INTO `sms_partners_two` VALUES(`1244`, `0`, `30`, `0`, `0`, `0`, `0`, `178.66.10.105`);
INSERT INTO `sms_partners_two` VALUES(`1245`, `0`, `30`, `0`, `0`, `0`, `0`, `109.185.70.226`);
INSERT INTO `sms_partners_two` VALUES(`1246`, `0`, `30`, `0`, `0`, `0`, `0`, `194.44.21.44`);
INSERT INTO `sms_partners_two` VALUES(`1247`, `0`, `30`, `0`, `0`, `0`, `0`, `176.195.185.117`);
INSERT INTO `sms_partners_two` VALUES(`1248`, `0`, `32`, `0`, `0`, `0`, `0`, `178.122.36.175`);
INSERT INTO `sms_partners_two` VALUES(`1249`, `0`, `30`, `0`, `0`, `0`, `0`, `128.72.100.185`);
INSERT INTO `sms_partners_two` VALUES(`1250`, `0`, `30`, `0`, `0`, `0`, `0`, `178.127.168.217`);
INSERT INTO `sms_partners_two` VALUES(`1251`, `0`, `30`, `0`, `0`, `0`, `0`, `80.242.101.139`);
INSERT INTO `sms_partners_two` VALUES(`1252`, `0`, `30`, `0`, `0`, `0`, `0`, `46.118.91.206`);
INSERT INTO `sms_partners_two` VALUES(`1253`, `0`, `30`, `0`, `0`, `0`, `0`, `81.23.167.51`);
INSERT INTO `sms_partners_two` VALUES(`1254`, `0`, `30`, `0`, `0`, `0`, `0`, `188.32.175.164`);
INSERT INTO `sms_partners_two` VALUES(`1255`, `0`, `30`, `0`, `0`, `0`, `0`, `95.57.34.98`);
INSERT INTO `sms_partners_two` VALUES(`1256`, `0`, `30`, `0`, `0`, `0`, `0`, `178.122.254.100`);
INSERT INTO `sms_partners_two` VALUES(`1257`, `0`, `30`, `0`, `0`, `0`, `0`, `94.248.17.212`);
INSERT INTO `sms_partners_two` VALUES(`1258`, `0`, `30`, `0`, `0`, `0`, `0`, `93.183.198.226`);
INSERT INTO `sms_partners_two` VALUES(`1259`, `0`, `30`, `0`, `0`, `0`, `0`, `89.22.160.63`);
INSERT INTO `sms_partners_two` VALUES(`1260`, `0`, `30`, `0`, `0`, `0`, `0`, `37.55.133.79`);
INSERT INTO `sms_partners_two` VALUES(`1261`, `0`, `30`, `0`, `0`, `0`, `0`, `94.242.138.235`);
INSERT INTO `sms_partners_two` VALUES(`1262`, `0`, `30`, `0`, `0`, `0`, `0`, `92.112.99.137`);
INSERT INTO `sms_partners_two` VALUES(`1263`, `0`, `30`, `0`, `0`, `0`, `0`, `95.58.9.194`);
INSERT INTO `sms_partners_two` VALUES(`1264`, `0`, `30`, `0`, `0`, `0`, `0`, `178.121.221.81`);
INSERT INTO `sms_partners_two` VALUES(`1265`, `0`, `30`, `0`, `0`, `0`, `0`, `213.179.251.54`);
INSERT INTO `sms_partners_two` VALUES(`1266`, `0`, `30`, `0`, `0`, `0`, `0`, `93.79.77.219`);
INSERT INTO `sms_partners_two` VALUES(`1267`, `0`, `30`, `0`, `0`, `0`, `0`, `46.149.81.102`);
INSERT INTO `sms_partners_two` VALUES(`1268`, `0`, `30`, `0`, `0`, `0`, `0`, `82.162.180.7`);
INSERT INTO `sms_partners_two` VALUES(`1269`, `0`, `32`, `0`, `0`, `0`, `0`, `188.32.161.47`);
INSERT INTO `sms_partners_two` VALUES(`1270`, `0`, `30`, `0`, `0`, `0`, `0`, `94.251.85.102`);
INSERT INTO `sms_partners_two` VALUES(`1271`, `0`, `30`, `0`, `0`, `0`, `0`, `95.153.77.15`);
INSERT INTO `sms_partners_two` VALUES(`1272`, `0`, `30`, `0`, `0`, `0`, `0`, `178.208.248.24`);
INSERT INTO `sms_partners_two` VALUES(`1273`, `0`, `32`, `0`, `0`, `0`, `0`, `78.139.112.98`);
INSERT INTO `sms_partners_two` VALUES(`1274`, `0`, `32`, `0`, `0`, `0`, `0`, `188.65.69.252`);
INSERT INTO `sms_partners_two` VALUES(`1275`, `0`, `30`, `0`, `0`, `0`, `0`, `176.8.148.142`);
INSERT INTO `sms_partners_two` VALUES(`1276`, `0`, `32`, `0`, `0`, `0`, `0`, `193.33.233.254`);
INSERT INTO `sms_partners_two` VALUES(`1277`, `0`, `30`, `0`, `0`, `0`, `0`, `78.106.187.254`);
INSERT INTO `sms_partners_two` VALUES(`1278`, `0`, `30`, `0`, `0`, `0`, `0`, `95.59.185.85`);
INSERT INTO `sms_partners_two` VALUES(`1279`, `0`, `32`, `0`, `0`, `0`, `0`, `212.22.204.133`);
INSERT INTO `sms_partners_two` VALUES(`1280`, `0`, `32`, `0`, `0`, `0`, `0`, `93.185.214.111`);
INSERT INTO `sms_partners_two` VALUES(`1281`, `0`, `30`, `0`, `0`, `0`, `0`, `91.124.1.90`);
INSERT INTO `sms_partners_two` VALUES(`1282`, `0`, `30`, `0`, `0`, `0`, `0`, `2.93.205.114`);
INSERT INTO `sms_partners_two` VALUES(`1283`, `0`, `30`, `0`, `0`, `0`, `0`, `87.117.185.176`);
INSERT INTO `sms_partners_two` VALUES(`1284`, `0`, `30`, `0`, `0`, `0`, `0`, `95.79.199.225`);
INSERT INTO `sms_partners_two` VALUES(`1285`, `0`, `30`, `0`, `0`, `0`, `0`, `178.187.88.114`);
INSERT INTO `sms_partners_two` VALUES(`1286`, `0`, `30`, `0`, `0`, `0`, `0`, `178.209.89.42`);
INSERT INTO `sms_partners_two` VALUES(`1287`, `0`, `30`, `0`, `0`, `0`, `0`, `109.254.46.208`);
INSERT INTO `sms_partners_two` VALUES(`1288`, `0`, `32`, `0`, `0`, `0`, `0`, `95.32.11.23`);
INSERT INTO `sms_partners_two` VALUES(`1289`, `0`, `30`, `0`, `0`, `0`, `0`, `46.71.69.244`);
INSERT INTO `sms_partners_two` VALUES(`1290`, `0`, `30`, `0`, `0`, `0`, `0`, `93.77.69.180`);
INSERT INTO `sms_partners_two` VALUES(`1291`, `0`, `30`, `0`, `0`, `0`, `0`, `194.177.25.17`);
INSERT INTO `sms_partners_two` VALUES(`1292`, `0`, `30`, `0`, `0`, `0`, `0`, `92.112.161.29`);
INSERT INTO `sms_partners_two` VALUES(`1293`, `0`, `30`, `0`, `0`, `0`, `0`, `109.201.93.68`);
INSERT INTO `sms_partners_two` VALUES(`1294`, `0`, `30`, `0`, `0`, `0`, `0`, `193.106.150.187`);
INSERT INTO `sms_partners_two` VALUES(`1295`, `0`, `30`, `0`, `0`, `0`, `0`, `178.121.129.54`);
INSERT INTO `sms_partners_two` VALUES(`1296`, `0`, `30`, `0`, `0`, `0`, `0`, `78.36.157.14`);
INSERT INTO `sms_partners_two` VALUES(`1297`, `0`, `30`, `0`, `0`, `0`, `0`, `95.191.25.23`);
INSERT INTO `sms_partners_two` VALUES(`1298`, `0`, `30`, `0`, `0`, `0`, `0`, `95.58.17.12`);
INSERT INTO `sms_partners_two` VALUES(`1299`, `0`, `30`, `0`, `0`, `0`, `0`, `195.245.97.1`);
INSERT INTO `sms_partners_two` VALUES(`1300`, `0`, `30`, `0`, `0`, `0`, `0`, `92.115.98.200`);
INSERT INTO `sms_partners_two` VALUES(`1301`, `0`, `30`, `0`, `0`, `0`, `0`, `94.179.124.3`);
INSERT INTO `sms_partners_two` VALUES(`1302`, `0`, `30`, `0`, `0`, `0`, `0`, `95.53.39.132`);
INSERT INTO `sms_partners_two` VALUES(`1303`, `0`, `30`, `0`, `0`, `0`, `0`, `93.74.101.40`);
INSERT INTO `sms_partners_two` VALUES(`1304`, `0`, `30`, `0`, `0`, `0`, `0`, `31.133.250.219`);
INSERT INTO `sms_partners_two` VALUES(`1305`, `0`, `30`, `0`, `0`, `0`, `0`, `188.114.26.149`);
INSERT INTO `sms_partners_two` VALUES(`1306`, `0`, `30`, `0`, `0`, `0`, `0`, `178.126.137.77`);
INSERT INTO `sms_partners_two` VALUES(`1307`, `0`, `30`, `0`, `0`, `0`, `0`, `94.179.237.148`);
INSERT INTO `sms_partners_two` VALUES(`1308`, `0`, `32`, `0`, `0`, `0`, `0`, `37.45.237.202`);
INSERT INTO `sms_partners_two` VALUES(`1309`, `0`, `30`, `0`, `0`, `0`, `0`, `176.212.9.44`);
INSERT INTO `sms_partners_two` VALUES(`1310`, `0`, `30`, `0`, `0`, `0`, `0`, `95.58.88.77`);
INSERT INTO `sms_partners_two` VALUES(`1311`, `0`, `30`, `0`, `0`, `0`, `0`, `92.113.118.209`);
INSERT INTO `sms_partners_two` VALUES(`1312`, `0`, `30`, `0`, `0`, `0`, `0`, `92.46.193.183`);
INSERT INTO `sms_partners_two` VALUES(`1313`, `0`, `30`, `0`, `0`, `0`, `0`, `178.123.30.245`);
INSERT INTO `sms_partners_two` VALUES(`1314`, `0`, `30`, `0`, `0`, `0`, `0`, `94.178.49.86`);
INSERT INTO `sms_partners_two` VALUES(`1315`, `0`, `30`, `0`, `0`, `0`, `0`, `176.14.243.192`);
INSERT INTO `sms_partners_two` VALUES(`1316`, `0`, `30`, `0`, `0`, `0`, `0`, `46.165.8.28`);
INSERT INTO `sms_partners_two` VALUES(`1317`, `0`, `32`, `0`, `0`, `0`, `0`, `178.213.1.157`);
INSERT INTO `sms_partners_two` VALUES(`1318`, `0`, `30`, `0`, `0`, `0`, `0`, `109.254.23.64`);
INSERT INTO `sms_partners_two` VALUES(`1319`, `0`, `30`, `0`, `0`, `0`, `0`, `37.113.84.71`);
INSERT INTO `sms_partners_two` VALUES(`1320`, `0`, `30`, `0`, `0`, `0`, `0`, `94.76.121.123`);
INSERT INTO `sms_partners_two` VALUES(`1321`, `0`, `30`, `0`, `0`, `0`, `0`, `95.111.225.155`);
INSERT INTO `sms_partners_two` VALUES(`1322`, `0`, `30`, `0`, `0`, `0`, `0`, `46.165.10.169`);
INSERT INTO `sms_partners_two` VALUES(`1323`, `0`, `30`, `0`, `0`, `0`, `0`, `178.92.241.179`);
INSERT INTO `sms_partners_two` VALUES(`1324`, `0`, `30`, `0`, `0`, `0`, `0`, `109.127.39.203`);
INSERT INTO `sms_partners_two` VALUES(`1325`, `0`, `30`, `0`, `0`, `0`, `0`, `46.211.120.141`);
INSERT INTO `sms_partners_two` VALUES(`1326`, `0`, `30`, `0`, `0`, `0`, `0`, `213.137.232.166`);
INSERT INTO `sms_partners_two` VALUES(`1327`, `0`, `30`, `0`, `0`, `0`, `0`, `91.232.202.55`);
INSERT INTO `sms_partners_two` VALUES(`1328`, `0`, `30`, `0`, `0`, `0`, `0`, `195.18.12.0`);
INSERT INTO `sms_partners_two` VALUES(`1329`, `0`, `30`, `0`, `0`, `0`, `0`, `89.151.173.177`);
INSERT INTO `sms_partners_two` VALUES(`1330`, `0`, `30`, `0`, `0`, `0`, `0`, `188.18.238.111`);
INSERT INTO `sms_partners_two` VALUES(`1331`, `0`, `30`, `0`, `0`, `0`, `0`, `88.222.177.248`);
INSERT INTO `sms_partners_two` VALUES(`1332`, `0`, `30`, `0`, `0`, `0`, `0`, `178.78.36.239`);
INSERT INTO `sms_partners_two` VALUES(`1333`, `0`, `30`, `0`, `0`, `0`, `0`, `188.32.70.39`);
INSERT INTO `sms_partners_two` VALUES(`1334`, `0`, `30`, `0`, `0`, `0`, `0`, `176.8.158.94`);
INSERT INTO `sms_partners_two` VALUES(`1335`, `0`, `30`, `0`, `0`, `0`, `0`, `109.191.107.160`);
INSERT INTO `sms_partners_two` VALUES(`1336`, `0`, `30`, `0`, `0`, `0`, `0`, `95.153.178.128`);
INSERT INTO `sms_partners_two` VALUES(`1337`, `0`, `30`, `0`, `0`, `0`, `0`, `37.212.27.116`);
INSERT INTO `sms_partners_two` VALUES(`1338`, `0`, `30`, `0`, `0`, `0`, `0`, `46.30.167.79`);
INSERT INTO `sms_partners_two` VALUES(`1339`, `0`, `30`, `0`, `0`, `0`, `0`, `78.36.184.36`);
INSERT INTO `sms_partners_two` VALUES(`1340`, `0`, `30`, `0`, `0`, `0`, `0`, `95.134.77.193`);
INSERT INTO `sms_partners_two` VALUES(`1341`, `0`, `30`, `0`, `0`, `0`, `0`, `31.135.137.91`);
INSERT INTO `sms_partners_two` VALUES(`1342`, `0`, `30`, `0`, `0`, `0`, `0`, `91.221.219.45`);
INSERT INTO `sms_partners_two` VALUES(`1343`, `0`, `30`, `0`, `0`, `0`, `0`, `178.67.212.244`);
INSERT INTO `sms_partners_two` VALUES(`1344`, `0`, `30`, `0`, `0`, `0`, `0`, `37.214.116.44`);
INSERT INTO `sms_partners_two` VALUES(`1345`, `0`, `30`, `0`, `0`, `0`, `0`, `193.151.105.108`);
INSERT INTO `sms_partners_two` VALUES(`1346`, `0`, `30`, `0`, `0`, `0`, `0`, `178.74.210.254`);
INSERT INTO `sms_partners_two` VALUES(`1347`, `0`, `30`, `0`, `0`, `0`, `0`, `91.76.103.227`);
INSERT INTO `sms_partners_two` VALUES(`1348`, `0`, `30`, `0`, `0`, `0`, `0`, `176.8.165.220`);
INSERT INTO `sms_partners_two` VALUES(`1349`, `0`, `30`, `0`, `0`, `0`, `0`, `78.36.5.225`);
INSERT INTO `sms_partners_two` VALUES(`1350`, `0`, `30`, `0`, `0`, `0`, `0`, `31.180.201.128`);
INSERT INTO `sms_partners_two` VALUES(`1351`, `0`, `30`, `0`, `0`, `0`, `0`, `94.153.70.17`);
INSERT INTO `sms_partners_two` VALUES(`1352`, `0`, `30`, `0`, `0`, `0`, `0`, `91.124.224.185`);
INSERT INTO `sms_partners_two` VALUES(`1353`, `0`, `30`, `0`, `0`, `0`, `0`, `92.100.182.79`);
INSERT INTO `sms_partners_two` VALUES(`1354`, `0`, `30`, `0`, `0`, `0`, `0`, `91.222.168.140`);
INSERT INTO `sms_partners_two` VALUES(`1355`, `0`, `30`, `0`, `0`, `0`, `0`, `81.163.30.66`);
INSERT INTO `sms_partners_two` VALUES(`1356`, `0`, `30`, `0`, `0`, `0`, `0`, `79.126.80.5`);
INSERT INTO `sms_partners_two` VALUES(`1357`, `0`, `30`, `0`, `0`, `0`, `0`, `37.112.113.21`);
INSERT INTO `sms_partners_two` VALUES(`1358`, `0`, `30`, `0`, `0`, `0`, `0`, `89.249.83.36`);
INSERT INTO `sms_partners_two` VALUES(`1359`, `0`, `30`, `0`, `0`, `0`, `0`, `31.192.236.55`);
INSERT INTO `sms_partners_two` VALUES(`1360`, `0`, `30`, `0`, `0`, `0`, `0`, `178.90.248.201`);
INSERT INTO `sms_partners_two` VALUES(`1361`, `0`, `30`, `0`, `0`, `0`, `0`, `178.216.186.16`);
INSERT INTO `sms_partners_two` VALUES(`1362`, `0`, `30`, `0`, `0`, `0`, `0`, `109.195.174.69`);
INSERT INTO `sms_partners_two` VALUES(`1363`, `0`, `30`, `0`, `0`, `0`, `0`, `176.8.249.247`);
INSERT INTO `sms_partners_two` VALUES(`1364`, `0`, `30`, `0`, `0`, `0`, `0`, `109.226.103.63`);
INSERT INTO `sms_partners_two` VALUES(`1365`, `0`, `30`, `0`, `0`, `0`, `0`, `178.95.189.171`);
INSERT INTO `sms_partners_two` VALUES(`1366`, `0`, `30`, `0`, `0`, `0`, `0`, `37.221.201.218`);
INSERT INTO `sms_partners_two` VALUES(`1367`, `0`, `30`, `0`, `0`, `0`, `0`, `213.230.95.28`);
INSERT INTO `sms_partners_two` VALUES(`1368`, `0`, `30`, `0`, `0`, `0`, `0`, `80.237.121.8`);
INSERT INTO `sms_partners_two` VALUES(`1369`, `0`, `30`, `0`, `0`, `0`, `0`, `80.245.83.36`);
INSERT INTO `sms_partners_two` VALUES(`1370`, `0`, `30`, `0`, `0`, `0`, `0`, `178.187.203.166`);
INSERT INTO `sms_partners_two` VALUES(`1371`, `0`, `30`, `0`, `0`, `0`, `0`, `83.149.38.210`);
INSERT INTO `sms_partners_two` VALUES(`1372`, `0`, `30`, `0`, `0`, `0`, `0`, `95.111.143.203`);
INSERT INTO `sms_partners_two` VALUES(`1373`, `0`, `30`, `0`, `0`, `0`, `0`, `178.92.161.147`);
INSERT INTO `sms_partners_two` VALUES(`1374`, `0`, `30`, `0`, `0`, `0`, `0`, `178.137.70.2`);
INSERT INTO `sms_partners_two` VALUES(`1375`, `0`, `30`, `0`, `0`, `0`, `0`, `92.112.136.88`);
INSERT INTO `sms_partners_two` VALUES(`1376`, `0`, `30`, `0`, `0`, `0`, `0`, `37.229.65.124`);
INSERT INTO `sms_partners_two` VALUES(`1377`, `0`, `30`, `0`, `0`, `0`, `0`, `31.3.28.161`);
INSERT INTO `sms_partners_two` VALUES(`1378`, `0`, `30`, `0`, `0`, `0`, `0`, `213.87.138.29`);
INSERT INTO `sms_partners_two` VALUES(`1379`, `0`, `30`, `0`, `0`, `0`, `0`, `95.133.54.34`);
INSERT INTO `sms_partners_two` VALUES(`1380`, `0`, `30`, `0`, `0`, `0`, `0`, `93.77.26.74`);
INSERT INTO `sms_partners_two` VALUES(`1381`, `0`, `30`, `0`, `0`, `0`, `0`, `85.26.235.216`);
INSERT INTO `sms_partners_two` VALUES(`1382`, `0`, `30`, `0`, `0`, `0`, `0`, `109.200.232.104`);
INSERT INTO `sms_partners_two` VALUES(`1383`, `0`, `30`, `0`, `0`, `0`, `0`, `46.162.210.229`);
INSERT INTO `sms_partners_two` VALUES(`1384`, `0`, `30`, `0`, `0`, `0`, `0`, `91.200.200.12`);
INSERT INTO `sms_partners_two` VALUES(`1385`, `0`, `30`, `0`, `0`, `0`, `0`, `77.121.112.49`);
INSERT INTO `sms_partners_two` VALUES(`1386`, `0`, `30`, `0`, `0`, `0`, `0`, `178.126.6.103`);
INSERT INTO `sms_partners_two` VALUES(`1387`, `0`, `30`, `0`, `0`, `0`, `0`, `31.43.140.75`);
INSERT INTO `sms_partners_two` VALUES(`1388`, `0`, `30`, `0`, `0`, `0`, `0`, `109.115.17.69`);
INSERT INTO `sms_partners_two` VALUES(`1389`, `0`, `30`, `0`, `0`, `0`, `0`, `87.239.27.90`);
INSERT INTO `sms_partners_two` VALUES(`1390`, `0`, `30`, `0`, `0`, `0`, `0`, `128.73.92.42`);
INSERT INTO `sms_partners_two` VALUES(`1391`, `0`, `30`, `0`, `0`, `0`, `0`, `94.156.19.196`);
INSERT INTO `sms_partners_two` VALUES(`1392`, `0`, `30`, `0`, `0`, `0`, `0`, `95.43.118.7`);
INSERT INTO `sms_partners_two` VALUES(`1393`, `0`, `30`, `0`, `0`, `0`, `0`, `95.134.121.195`);
INSERT INTO `sms_partners_two` VALUES(`1394`, `0`, `30`, `0`, `0`, `0`, `0`, `178.150.173.25`);
INSERT INTO `sms_partners_two` VALUES(`1395`, `0`, `30`, `0`, `0`, `0`, `0`, `178.91.113.45`);
INSERT INTO `sms_partners_two` VALUES(`1396`, `0`, `0`, `0`, `0`, `0`, `0`, `178.91.113.45`);
INSERT INTO `sms_partners_two` VALUES(`1397`, `0`, `30`, `0`, `0`, `0`, `0`, `178.125.207.102`);
INSERT INTO `sms_partners_two` VALUES(`1398`, `0`, `30`, `0`, `0`, `0`, `0`, `141.136.84.47`);
INSERT INTO `sms_partners_two` VALUES(`1399`, `0`, `30`, `0`, `0`, `0`, `0`, `93.85.182.10`);
INSERT INTO `sms_partners_two` VALUES(`1400`, `0`, `30`, `0`, `0`, `0`, `0`, `93.84.14.16`);
INSERT INTO `sms_partners_two` VALUES(`1401`, `0`, `30`, `0`, `0`, `0`, `0`, `109.201.111.177`);
INSERT INTO `sms_partners_two` VALUES(`1402`, `0`, `30`, `0`, `0`, `0`, `0`, `178.94.44.97`);
INSERT INTO `sms_partners_two` VALUES(`1403`, `0`, `30`, `0`, `0`, `0`, `0`, `37.55.71.42`);
INSERT INTO `sms_partners_two` VALUES(`1404`, `0`, `30`, `0`, `0`, `0`, `0`, `91.213.248.29`);
INSERT INTO `sms_partners_two` VALUES(`1405`, `0`, `30`, `0`, `0`, `0`, `0`, `93.72.146.153`);
INSERT INTO `sms_partners_two` VALUES(`1406`, `0`, `30`, `0`, `0`, `0`, `0`, `178.219.56.142`);
INSERT INTO `sms_partners_two` VALUES(`1407`, `0`, `30`, `0`, `0`, `0`, `0`, `92.112.123.132`);
INSERT INTO `sms_partners_two` VALUES(`1408`, `0`, `30`, `0`, `0`, `0`, `0`, `95.132.38.188`);
INSERT INTO `sms_partners_two` VALUES(`1409`, `0`, `30`, `0`, `0`, `0`, `0`, `91.215.123.102`);
INSERT INTO `sms_partners_two` VALUES(`1410`, `0`, `30`, `0`, `0`, `0`, `0`, `178.123.205.102`);
INSERT INTO `sms_partners_two` VALUES(`1411`, `0`, `30`, `0`, `0`, `0`, `0`, `78.29.110.65`);
INSERT INTO `sms_partners_two` VALUES(`1412`, `0`, `30`, `0`, `0`, `0`, `0`, `80.80.123.188`);
INSERT INTO `sms_partners_two` VALUES(`1413`, `0`, `30`, `0`, `0`, `0`, `0`, `78.137.51.201`);
INSERT INTO `sms_partners_two` VALUES(`1414`, `0`, `30`, `0`, `0`, `0`, `0`, `46.118.111.107`);
INSERT INTO `sms_partners_two` VALUES(`1415`, `0`, `30`, `0`, `0`, `0`, `0`, `93.79.38.135`);
INSERT INTO `sms_partners_two` VALUES(`1416`, `0`, `30`, `0`, `0`, `0`, `0`, `217.66.156.105`);
INSERT INTO `sms_partners_two` VALUES(`1417`, `0`, `30`, `0`, `0`, `0`, `0`, `178.122.246.229`);
INSERT INTO `sms_partners_two` VALUES(`1418`, `0`, `30`, `0`, `0`, `0`, `0`, `31.41.14.161`);
INSERT INTO `sms_partners_two` VALUES(`1419`, `0`, `30`, `0`, `0`, `0`, `0`, `213.141.138.140`);
INSERT INTO `sms_partners_two` VALUES(`1420`, `0`, `30`, `0`, `0`, `0`, `0`, `178.125.133.149`);
INSERT INTO `sms_partners_two` VALUES(`1421`, `0`, `30`, `0`, `0`, `0`, `0`, `176.8.157.109`);
INSERT INTO `sms_partners_two` VALUES(`1422`, `0`, `30`, `0`, `0`, `0`, `0`, `188.187.34.196`);
INSERT INTO `sms_partners_two` VALUES(`1423`, `0`, `30`, `0`, `0`, `0`, `0`, `178.127.95.96`);
INSERT INTO `sms_partners_two` VALUES(`1424`, `0`, `30`, `0`, `0`, `0`, `0`, `91.124.223.135`);
INSERT INTO `sms_partners_two` VALUES(`1425`, `0`, `30`, `0`, `0`, `0`, `0`, `77.232.139.148`);
INSERT INTO `sms_partners_two` VALUES(`1426`, `0`, `30`, `0`, `0`, `0`, `0`, `178.172.183.223`);
INSERT INTO `sms_partners_two` VALUES(`1427`, `0`, `30`, `0`, `0`, `0`, `0`, `31.181.166.254`);
INSERT INTO `sms_partners_two` VALUES(`1428`, `0`, `30`, `0`, `0`, `0`, `0`, `85.26.164.88`);
INSERT INTO `sms_partners_two` VALUES(`1429`, `0`, `30`, `0`, `0`, `0`, `0`, `62.209.151.60`);
INSERT INTO `sms_partners_two` VALUES(`1430`, `0`, `30`, `0`, `0`, `0`, `0`, `178.137.91.56`);
INSERT INTO `sms_partners_two` VALUES(`1431`, `0`, `30`, `0`, `0`, `0`, `0`, `178.125.145.184`);
INSERT INTO `sms_partners_two` VALUES(`1432`, `0`, `30`, `0`, `0`, `0`, `0`, `178.137.98.68`);
INSERT INTO `sms_partners_two` VALUES(`1433`, `0`, `30`, `0`, `0`, `0`, `0`, `193.105.92.204`);
INSERT INTO `sms_partners_two` VALUES(`1434`, `0`, `30`, `0`, `0`, `0`, `0`, `178.137.9.215`);
INSERT INTO `sms_partners_two` VALUES(`1435`, `0`, `30`, `0`, `0`, `0`, `0`, `178.125.69.70`);
INSERT INTO `sms_partners_two` VALUES(`1436`, `0`, `30`, `0`, `0`, `0`, `0`, `92.113.73.31`);
INSERT INTO `sms_partners_two` VALUES(`1437`, `0`, `30`, `0`, `0`, `0`, `0`, `109.86.163.153`);
INSERT INTO `sms_partners_two` VALUES(`1438`, `0`, `30`, `0`, `0`, `0`, `0`, `83.149.2.39`);
INSERT INTO `sms_partners_two` VALUES(`1439`, `0`, `30`, `0`, `0`, `0`, `0`, `212.66.32.242`);
INSERT INTO `sms_partners_two` VALUES(`1440`, `0`, `30`, `0`, `0`, `0`, `0`, `37.229.64.161`);
INSERT INTO `sms_partners_two` VALUES(`1441`, `0`, `30`, `0`, `0`, `0`, `0`, `195.140.230.253`);
INSERT INTO `sms_partners_two` VALUES(`1442`, `0`, `30`, `0`, `0`, `0`, `0`, `178.120.32.249`);
INSERT INTO `sms_partners_two` VALUES(`1443`, `0`, `30`, `0`, `0`, `0`, `0`, `95.132.68.89`);
INSERT INTO `sms_partners_two` VALUES(`1444`, `0`, `30`, `0`, `0`, `0`, `0`, `95.190.87.71`);
INSERT INTO `sms_partners_two` VALUES(`1445`, `0`, `30`, `0`, `0`, `0`, `0`, `92.242.113.74`);
INSERT INTO `sms_partners_two` VALUES(`1446`, `0`, `30`, `0`, `0`, `0`, `0`, `81.25.254.127`);
INSERT INTO `sms_partners_two` VALUES(`1447`, `0`, `30`, `0`, `0`, `0`, `0`, `31.40.204.36`);
INSERT INTO `sms_partners_two` VALUES(`1448`, `0`, `30`, `0`, `0`, `0`, `0`, `213.154.208.83`);
INSERT INTO `sms_partners_two` VALUES(`1449`, `0`, `30`, `0`, `0`, `0`, `0`, `95.158.230.89`);
INSERT INTO `sms_partners_two` VALUES(`1450`, `0`, `30`, `0`, `0`, `0`, `0`, `95.25.109.70`);
INSERT INTO `sms_partners_two` VALUES(`1451`, `0`, `30`, `0`, `0`, `0`, `0`, `188.230.30.126`);
INSERT INTO `sms_partners_two` VALUES(`1452`, `0`, `30`, `0`, `0`, `0`, `0`, `77.121.243.60`);
INSERT INTO `sms_partners_two` VALUES(`1453`, `0`, `30`, `0`, `0`, `0`, `0`, `94.248.37.34`);
INSERT INTO `sms_partners_two` VALUES(`1454`, `0`, `30`, `0`, `0`, `0`, `0`, `46.72.225.19`);
INSERT INTO `sms_partners_two` VALUES(`1455`, `0`, `30`, `0`, `0`, `0`, `0`, `77.34.19.194`);
INSERT INTO `sms_partners_two` VALUES(`1456`, `0`, `30`, `0`, `0`, `0`, `0`, `188.253.128.177`);
INSERT INTO `sms_partners_two` VALUES(`1457`, `0`, `30`, `0`, `0`, `0`, `0`, `93.84.21.223`);
INSERT INTO `sms_partners_two` VALUES(`1458`, `0`, `30`, `0`, `0`, `0`, `0`, `37.55.59.231`);
INSERT INTO `sms_partners_two` VALUES(`1459`, `0`, `30`, `0`, `0`, `0`, `0`, `176.50.240.53`);
INSERT INTO `sms_partners_two` VALUES(`1460`, `0`, `30`, `0`, `0`, `0`, `0`, `37.214.115.56`);
INSERT INTO `sms_partners_two` VALUES(`1461`, `0`, `30`, `0`, `0`, `0`, `0`, `46.53.166.169`);
INSERT INTO `sms_partners_two` VALUES(`1462`, `0`, `30`, `0`, `0`, `0`, `0`, `80.90.168.22`);
INSERT INTO `sms_partners_two` VALUES(`1463`, `0`, `30`, `0`, `0`, `0`, `0`, `37.229.29.109`);
INSERT INTO `sms_partners_two` VALUES(`1464`, `0`, `30`, `0`, `0`, `0`, `0`, `178.214.182.110`);
INSERT INTO `sms_partners_two` VALUES(`1465`, `0`, `30`, `0`, `0`, `0`, `0`, `46.203.124.49`);
INSERT INTO `sms_partners_two` VALUES(`1466`, `0`, `30`, `0`, `0`, `0`, `0`, `109.127.170.90`);
INSERT INTO `sms_partners_two` VALUES(`1467`, `0`, `30`, `0`, `0`, `0`, `0`, `93.79.158.248`);
INSERT INTO `sms_partners_two` VALUES(`1468`, `35`, `30`, `0`, `20`, `10`, `0`, `213.87.132.38`);
INSERT INTO `sms_partners_two` VALUES(`1469`, `0`, `0`, `0`, `0`, `0`, `0`, `213.87.132.38`);
INSERT INTO `sms_partners_two` VALUES(`1470`, `0`, `30`, `0`, `0`, `0`, `0`, `178.95.189.168`);
INSERT INTO `sms_partners_two` VALUES(`1471`, `0`, `30`, `0`, `0`, `0`, `0`, `92.113.43.94`);
INSERT INTO `sms_partners_two` VALUES(`1472`, `0`, `30`, `0`, `0`, `0`, `0`, `95.135.204.164`);
INSERT INTO `sms_partners_two` VALUES(`1473`, `0`, `30`, `0`, `0`, `0`, `0`, `46.138.141.95`);
INSERT INTO `sms_partners_two` VALUES(`1474`, `0`, `30`, `0`, `0`, `0`, `0`, `95.29.235.224`);
INSERT INTO `sms_partners_two` VALUES(`1475`, `0`, `30`, `0`, `0`, `0`, `0`, `109.126.44.15`);
INSERT INTO `sms_partners_two` VALUES(`1476`, `0`, `30`, `0`, `0`, `0`, `0`, `85.26.231.1`);
INSERT INTO `sms_partners_two` VALUES(`1477`, `0`, `30`, `0`, `0`, `0`, `0`, `37.229.79.150`);
INSERT INTO `sms_partners_two` VALUES(`1478`, `0`, `30`, `0`, `0`, `0`, `0`, `70.29.248.238`);
INSERT INTO `sms_partners_two` VALUES(`1479`, `0`, `30`, `0`, `0`, `0`, `0`, `109.68.236.14`);
INSERT INTO `sms_partners_two` VALUES(`1480`, `0`, `30`, `0`, `0`, `0`, `0`, `93.175.209.21`);
INSERT INTO `sms_partners_two` VALUES(`1481`, `0`, `30`, `0`, `0`, `0`, `0`, `37.52.5.2`);
INSERT INTO `sms_partners_two` VALUES(`1482`, `0`, `30`, `0`, `0`, `0`, `0`, `95.58.77.42`);
INSERT INTO `sms_partners_two` VALUES(`1483`, `0`, `30`, `0`, `0`, `0`, `0`, `217.118.79.20`);
INSERT INTO `sms_partners_two` VALUES(`1484`, `0`, `30`, `0`, `0`, `0`, `0`, `213.87.240.103`);
INSERT INTO `sms_partners_two` VALUES(`1485`, `0`, `30`, `0`, `0`, `0`, `0`, `89.28.41.215`);
INSERT INTO `sms_partners_two` VALUES(`1486`, `0`, `30`, `0`, `0`, `0`, `0`, `85.15.100.100`);
INSERT INTO `sms_partners_two` VALUES(`1487`, `0`, `30`, `0`, `0`, `0`, `0`, `95.57.77.19`);
INSERT INTO `sms_partners_two` VALUES(`1488`, `0`, `30`, `0`, `0`, `0`, `0`, `89.146.75.126`);
INSERT INTO `sms_partners_two` VALUES(`1489`, `0`, `30`, `0`, `0`, `0`, `0`, `213.87.137.45`);
INSERT INTO `sms_partners_two` VALUES(`1490`, `0`, `30`, `0`, `0`, `0`, `0`, `95.58.139.80`);
INSERT INTO `sms_partners_two` VALUES(`1491`, `0`, `30`, `0`, `0`, `0`, `0`, `95.133.15.226`);
INSERT INTO `sms_partners_two` VALUES(`1492`, `0`, `30`, `0`, `0`, `0`, `0`, `178.94.250.127`);
INSERT INTO `sms_partners_two` VALUES(`1493`, `36`, `30`, `0`, `20`, `10`, `0`, `178.125.152.3`);
INSERT INTO `sms_partners_two` VALUES(`1494`, `0`, `0`, `0`, `0`, `0`, `0`, `178.125.152.3`);
INSERT INTO `sms_partners_two` VALUES(`1495`, `0`, `30`, `0`, `0`, `0`, `0`, `213.87.121.154`);
INSERT INTO `sms_partners_two` VALUES(`1496`, `0`, `30`, `0`, `0`, `0`, `0`, `37.112.216.225`);
INSERT INTO `sms_partners_two` VALUES(`1497`, `0`, `30`, `0`, `0`, `0`, `0`, `178.90.67.8`);
INSERT INTO `sms_partners_two` VALUES(`1498`, `0`, `30`, `0`, `0`, `0`, `0`, `178.66.199.149`);
INSERT INTO `sms_partners_two` VALUES(`1499`, `0`, `30`, `0`, `0`, `0`, `0`, `31.163.116.168`);
INSERT INTO `sms_partners_two` VALUES(`1500`, `0`, `30`, `0`, `0`, `0`, `0`, `92.126.23.32`);
INSERT INTO `sms_partners_two` VALUES(`1501`, `0`, `30`, `0`, `0`, `0`, `0`, `159.224.214.217`);
INSERT INTO `sms_partners_two` VALUES(`1502`, `0`, `30`, `0`, `0`, `0`, `0`, `95.57.2.117`);
INSERT INTO `sms_partners_two` VALUES(`1503`, `0`, `30`, `0`, `0`, `0`, `0`, `2.60.178.16`);
INSERT INTO `sms_partners_two` VALUES(`1504`, `0`, `30`, `0`, `0`, `0`, `0`, `79.165.88.162`);
INSERT INTO `sms_partners_two` VALUES(`1505`, `0`, `30`, `0`, `0`, `0`, `0`, `188.255.112.196`);
INSERT INTO `sms_partners_two` VALUES(`1506`, `0`, `30`, `0`, `0`, `0`, `0`, `176.8.229.241`);
INSERT INTO `sms_partners_two` VALUES(`1507`, `0`, `30`, `0`, `0`, `0`, `0`, `188.18.173.164`);
INSERT INTO `sms_partners_two` VALUES(`1508`, `0`, `30`, `0`, `0`, `0`, `0`, `46.211.122.66`);
INSERT INTO `sms_partners_two` VALUES(`1509`, `0`, `30`, `0`, `0`, `0`, `0`, `194.44.201.254`);
INSERT INTO `sms_partners_two` VALUES(`1510`, `0`, `30`, `0`, `0`, `0`, `0`, `88.206.39.225`);
INSERT INTO `sms_partners_two` VALUES(`1511`, `0`, `30`, `0`, `0`, `0`, `0`, `95.70.89.97`);
INSERT INTO `sms_partners_two` VALUES(`1512`, `0`, `30`, `0`, `0`, `0`, `0`, `79.165.88.204`);
INSERT INTO `sms_partners_two` VALUES(`1513`, `0`, `30`, `0`, `0`, `0`, `0`, `77.87.86.138`);
INSERT INTO `sms_partners_two` VALUES(`1514`, `0`, `30`, `0`, `0`, `0`, `0`, `88.206.15.142`);
INSERT INTO `sms_partners_two` VALUES(`1515`, `0`, `30`, `0`, `0`, `0`, `0`, `95.24.106.77`);
INSERT INTO `sms_partners_two` VALUES(`1516`, `0`, `30`, `0`, `0`, `0`, `0`, `77.34.236.142`);
INSERT INTO `sms_partners_two` VALUES(`1517`, `0`, `30`, `0`, `0`, `0`, `0`, `91.212.80.170`);
INSERT INTO `sms_partners_two` VALUES(`1518`, `0`, `30`, `0`, `0`, `0`, `0`, `89.254.231.42`);
INSERT INTO `sms_partners_two` VALUES(`1519`, `0`, `30`, `0`, `0`, `0`, `0`, `31.28.225.74`);
INSERT INTO `sms_partners_two` VALUES(`1520`, `0`, `30`, `0`, `0`, `0`, `0`, `178.95.54.27`);
INSERT INTO `sms_partners_two` VALUES(`1521`, `0`, `30`, `0`, `0`, `0`, `0`, `46.42.36.136`);
INSERT INTO `sms_partners_two` VALUES(`1522`, `0`, `30`, `0`, `0`, `0`, `0`, `46.71.186.103`);
INSERT INTO `sms_partners_two` VALUES(`1523`, `0`, `30`, `0`, `0`, `0`, `0`, `89.254.242.90`);
INSERT INTO `sms_partners_two` VALUES(`1524`, `0`, `30`, `0`, `0`, `0`, `0`, `95.70.84.78`);
INSERT INTO `sms_partners_two` VALUES(`1525`, `0`, `30`, `0`, `0`, `0`, `0`, `217.173.27.182`);
INSERT INTO `sms_partners_two` VALUES(`1526`, `0`, `30`, `0`, `0`, `0`, `0`, `88.135.241.249`);
INSERT INTO `sms_partners_two` VALUES(`1527`, `0`, `30`, `0`, `0`, `0`, `0`, `77.50.43.221`);
INSERT INTO `sms_partners_two` VALUES(`1528`, `0`, `30`, `0`, `0`, `0`, `0`, `94.181.100.191`);
INSERT INTO `sms_partners_two` VALUES(`1529`, `0`, `30`, `0`, `0`, `0`, `0`, `89.179.106.174`);
INSERT INTO `sms_partners_two` VALUES(`1530`, `0`, `30`, `0`, `0`, `0`, `0`, `37.52.239.73`);
INSERT INTO `sms_partners_two` VALUES(`1531`, `0`, `30`, `0`, `0`, `0`, `0`, `178.124.205.210`);
INSERT INTO `sms_partners_two` VALUES(`1532`, `0`, `30`, `0`, `0`, `0`, `0`, `78.138.156.69`);
INSERT INTO `sms_partners_two` VALUES(`1533`, `0`, `0`, `0`, `0`, `0`, `0`, `78.138.156.69`);
INSERT INTO `sms_partners_two` VALUES(`1534`, `0`, `30`, `0`, `0`, `0`, `0`, `83.149.45.69`);
INSERT INTO `sms_partners_two` VALUES(`1535`, `0`, `30`, `0`, `0`, `0`, `0`, `178.121.218.20`);
INSERT INTO `sms_partners_two` VALUES(`1536`, `0`, `30`, `0`, `0`, `0`, `0`, `188.186.33.201`);
INSERT INTO `sms_partners_two` VALUES(`1537`, `0`, `30`, `0`, `0`, `0`, `0`, `109.169.141.172`);
INSERT INTO `sms_partners_two` VALUES(`1538`, `0`, `30`, `0`, `0`, `0`, `0`, `94.241.208.145`);
INSERT INTO `sms_partners_two` VALUES(`1539`, `0`, `30`, `0`, `0`, `0`, `0`, `94.41.214.237`);
INSERT INTO `sms_partners_two` VALUES(`1540`, `0`, `30`, `0`, `0`, `0`, `0`, `188.187.144.12`);
INSERT INTO `sms_partners_two` VALUES(`1541`, `0`, `30`, `0`, `0`, `0`, `0`, `37.46.128.165`);
INSERT INTO `sms_partners_two` VALUES(`1542`, `0`, `30`, `0`, `0`, `0`, `0`, `188.237.213.162`);
INSERT INTO `sms_partners_two` VALUES(`1543`, `0`, `30`, `0`, `0`, `0`, `0`, `93.178.251.96`);
INSERT INTO `sms_partners_two` VALUES(`1544`, `0`, `30`, `0`, `0`, `0`, `0`, `109.104.191.115`);
INSERT INTO `sms_partners_two` VALUES(`1545`, `0`, `30`, `0`, `0`, `0`, `0`, `85.26.231.43`);
INSERT INTO `sms_partners_two` VALUES(`1546`, `0`, `30`, `0`, `0`, `0`, `0`, `91.124.22.241`);
INSERT INTO `sms_partners_two` VALUES(`1547`, `0`, `30`, `0`, `0`, `0`, `0`, `2.95.165.198`);
INSERT INTO `sms_partners_two` VALUES(`1548`, `0`, `30`, `0`, `0`, `0`, `0`, `83.171.165.49`);
INSERT INTO `sms_partners_two` VALUES(`1549`, `0`, `30`, `0`, `0`, `0`, `0`, `109.162.32.87`);
INSERT INTO `sms_partners_two` VALUES(`1550`, `0`, `30`, `0`, `0`, `0`, `0`, `178.206.7.78`);
INSERT INTO `sms_partners_two` VALUES(`1551`, `0`, `30`, `0`, `0`, `0`, `0`, `176.52.37.181`);
INSERT INTO `sms_partners_two` VALUES(`1552`, `0`, `30`, `0`, `0`, `0`, `0`, `2.94.209.19`);
INSERT INTO `sms_partners_two` VALUES(`1553`, `0`, `30`, `0`, `0`, `0`, `0`, `80.83.237.86`);
INSERT INTO `sms_partners_two` VALUES(`1554`, `0`, `30`, `0`, `0`, `0`, `0`, `95.73.205.234`);
INSERT INTO `sms_partners_two` VALUES(`1555`, `0`, `30`, `0`, `0`, `0`, `0`, `91.195.157.242`);
INSERT INTO `sms_partners_two` VALUES(`1556`, `0`, `30`, `0`, `0`, `0`, `0`, `2.132.10.219`);
INSERT INTO `sms_partners_two` VALUES(`1557`, `0`, `30`, `0`, `0`, `0`, `0`, `94.153.12.109`);
INSERT INTO `sms_partners_two` VALUES(`1558`, `0`, `30`, `0`, `0`, `0`, `0`, `178.91.104.186`);
INSERT INTO `sms_partners_two` VALUES(`1559`, `0`, `30`, `0`, `0`, `0`, `0`, `109.87.235.123`);
INSERT INTO `sms_partners_two` VALUES(`1560`, `0`, `30`, `0`, `0`, `0`, `0`, `31.181.3.224`);
INSERT INTO `sms_partners_two` VALUES(`1561`, `0`, `30`, `0`, `0`, `0`, `0`, `109.80.99.137`);
INSERT INTO `sms_partners_two` VALUES(`1562`, `0`, `30`, `0`, `0`, `0`, `0`, `77.235.121.225`);
INSERT INTO `sms_partners_two` VALUES(`1563`, `0`, `30`, `0`, `0`, `0`, `0`, `93.116.142.116`);
INSERT INTO `sms_partners_two` VALUES(`1564`, `0`, `30`, `0`, `0`, `0`, `0`, `83.149.34.162`);
INSERT INTO `sms_partners_two` VALUES(`1565`, `0`, `30`, `0`, `0`, `0`, `0`, `93.127.72.204`);
INSERT INTO `sms_partners_two` VALUES(`1566`, `0`, `30`, `0`, `0`, `0`, `0`, `178.95.82.55`);
INSERT INTO `sms_partners_two` VALUES(`1567`, `0`, `30`, `0`, `0`, `0`, `0`, `193.111.241.58`);
INSERT INTO `sms_partners_two` VALUES(`1568`, `0`, `30`, `0`, `0`, `0`, `0`, `92.113.27.173`);
INSERT INTO `sms_partners_two` VALUES(`1569`, `0`, `30`, `0`, `0`, `0`, `0`, `77.52.51.227`);
INSERT INTO `sms_partners_two` VALUES(`1570`, `0`, `30`, `0`, `0`, `0`, `0`, `37.55.239.97`);
INSERT INTO `sms_partners_two` VALUES(`1571`, `0`, `30`, `0`, `0`, `0`, `0`, `95.132.192.161`);
INSERT INTO `sms_partners_two` VALUES(`1572`, `0`, `30`, `0`, `0`, `0`, `0`, `46.147.147.13`);
INSERT INTO `sms_partners_two` VALUES(`1573`, `0`, `30`, `0`, `0`, `0`, `0`, `92.55.40.242`);
INSERT INTO `sms_partners_two` VALUES(`1574`, `0`, `30`, `0`, `0`, `0`, `0`, `82.209.251.45`);
INSERT INTO `sms_partners_two` VALUES(`1575`, `0`, `30`, `0`, `0`, `0`, `0`, `91.211.16.42`);
INSERT INTO `sms_partners_two` VALUES(`1576`, `0`, `30`, `0`, `0`, `0`, `0`, `109.226.90.175`);
INSERT INTO `sms_partners_two` VALUES(`1577`, `0`, `30`, `0`, `0`, `0`, `0`, `193.107.64.128`);
INSERT INTO `sms_partners_two` VALUES(`1578`, `0`, `30`, `0`, `0`, `0`, `0`, `193.41.239.67`);
INSERT INTO `sms_partners_two` VALUES(`1579`, `0`, `30`, `0`, `0`, `0`, `0`, `80.14.61.60`);
INSERT INTO `sms_partners_two` VALUES(`1580`, `0`, `30`, `0`, `0`, `0`, `0`, `91.211.177.104`);
INSERT INTO `sms_partners_two` VALUES(`1581`, `0`, `30`, `0`, `0`, `0`, `0`, `193.239.24.136`);
INSERT INTO `sms_partners_two` VALUES(`1582`, `0`, `30`, `0`, `0`, `0`, `0`, `213.142.49.210`);
INSERT INTO `sms_partners_two` VALUES(`1583`, `0`, `30`, `0`, `0`, `0`, `0`, `178.94.7.195`);
INSERT INTO `sms_partners_two` VALUES(`1584`, `0`, `30`, `0`, `0`, `0`, `0`, `195.39.210.221`);
INSERT INTO `sms_partners_two` VALUES(`1585`, `0`, `30`, `0`, `0`, `0`, `0`, `83.149.34.184`);
INSERT INTO `sms_partners_two` VALUES(`1586`, `0`, `30`, `0`, `0`, `0`, `0`, `95.78.206.165`);
INSERT INTO `sms_partners_two` VALUES(`1587`, `0`, `30`, `0`, `0`, `0`, `0`, `31.162.142.100`);
INSERT INTO `sms_partners_two` VALUES(`1588`, `0`, `30`, `0`, `0`, `0`, `0`, `88.155.199.167`);
INSERT INTO `sms_partners_two` VALUES(`1589`, `0`, `30`, `0`, `0`, `0`, `0`, `46.158.152.64`);
INSERT INTO `sms_partners_two` VALUES(`1590`, `0`, `30`, `0`, `0`, `0`, `0`, `109.73.195.231`);
INSERT INTO `sms_partners_two` VALUES(`1591`, `0`, `30`, `0`, `0`, `0`, `0`, `93.125.83.46`);
INSERT INTO `sms_partners_two` VALUES(`1592`, `0`, `30`, `0`, `0`, `0`, `0`, `78.25.83.12`);
INSERT INTO `sms_partners_two` VALUES(`1593`, `0`, `30`, `0`, `0`, `0`, `0`, `178.93.61.170`);
INSERT INTO `sms_partners_two` VALUES(`1594`, `0`, `5`, `0`, `0`, `0`, `0`, `91.203.67.111`);
INSERT INTO `sms_partners_two` VALUES(`1595`, `0`, `0`, `0`, `0`, `0`, `0`, `91.203.67.111`);
INSERT INTO `sms_partners_two` VALUES(`1596`, `0`, `30`, `0`, `0`, `0`, `0`, `62.221.81.22`);
INSERT INTO `sms_partners_two` VALUES(`1597`, `0`, `30`, `0`, `0`, `0`, `0`, `46.119.237.87`);
INSERT INTO `sms_partners_two` VALUES(`1598`, `0`, `30`, `0`, `0`, `0`, `0`, `217.118.93.94`);
INSERT INTO `sms_partners_two` VALUES(`1599`, `0`, `30`, `0`, `0`, `0`, `0`, `91.216.22.13`);
INSERT INTO `sms_partners_two` VALUES(`1600`, `0`, `30`, `0`, `0`, `0`, `0`, `91.124.95.1`);
INSERT INTO `sms_partners_two` VALUES(`1601`, `0`, `30`, `0`, `0`, `0`, `0`, `194.44.158.84`);
INSERT INTO `sms_partners_two` VALUES(`1602`, `0`, `30`, `0`, `0`, `0`, `0`, `94.179.124.140`);
INSERT INTO `sms_partners_two` VALUES(`1603`, `0`, `30`, `0`, `0`, `0`, `0`, `128.73.250.21`);
INSERT INTO `sms_partners_two` VALUES(`1604`, `0`, `30`, `0`, `0`, `0`, `0`, `37.55.229.222`);
INSERT INTO `sms_partners_two` VALUES(`1605`, `0`, `30`, `0`, `0`, `0`, `0`, `178.127.175.113`);
INSERT INTO `sms_partners_two` VALUES(`1606`, `0`, `30`, `0`, `0`, `0`, `0`, `95.83.30.248`);
INSERT INTO `sms_partners_two` VALUES(`1607`, `0`, `30`, `0`, `0`, `0`, `0`, `178.65.154.62`);
INSERT INTO `sms_partners_two` VALUES(`1608`, `0`, `30`, `0`, `0`, `0`, `0`, `109.248.81.60`);
INSERT INTO `sms_partners_two` VALUES(`1609`, `0`, `30`, `0`, `0`, `0`, `0`, `46.119.4.104`);
INSERT INTO `sms_partners_two` VALUES(`1610`, `0`, `30`, `0`, `0`, `0`, `0`, `94.51.116.75`);
INSERT INTO `sms_partners_two` VALUES(`1611`, `0`, `30`, `0`, `0`, `0`, `0`, `5.8.208.219`);
INSERT INTO `sms_partners_two` VALUES(`1612`, `0`, `30`, `0`, `0`, `0`, `0`, `194.44.156.226`);
INSERT INTO `sms_partners_two` VALUES(`1613`, `0`, `30`, `0`, `0`, `0`, `0`, `178.187.110.119`);
INSERT INTO `sms_partners_two` VALUES(`1614`, `0`, `30`, `0`, `0`, `0`, `0`, `31.131.76.241`);
INSERT INTO `sms_partners_two` VALUES(`1615`, `0`, `30`, `0`, `0`, `0`, `0`, `92.49.203.121`);
INSERT INTO `sms_partners_two` VALUES(`1616`, `0`, `30`, `0`, `0`, `0`, `0`, `92.113.38.96`);
INSERT INTO `sms_partners_two` VALUES(`1617`, `0`, `30`, `0`, `0`, `0`, `0`, `176.109.28.197`);
INSERT INTO `sms_partners_two` VALUES(`1618`, `0`, `30`, `0`, `0`, `0`, `0`, `95.111.159.157`);
INSERT INTO `sms_partners_two` VALUES(`1619`, `0`, `30`, `0`, `0`, `0`, `0`, `217.118.79.21`);
INSERT INTO `sms_partners_two` VALUES(`1620`, `0`, `30`, `0`, `0`, `0`, `0`, `89.28.59.62`);
INSERT INTO `sms_partners_two` VALUES(`1621`, `0`, `30`, `0`, `0`, `0`, `0`, `109.161.81.122`);
INSERT INTO `sms_partners_two` VALUES(`1622`, `0`, `30`, `0`, `0`, `0`, `0`, `85.70.50.161`);
INSERT INTO `sms_partners_two` VALUES(`1623`, `0`, `30`, `0`, `0`, `0`, `0`, `193.106.201.200`);
INSERT INTO `sms_partners_two` VALUES(`1624`, `0`, `30`, `0`, `0`, `0`, `0`, `178.122.10.251`);
INSERT INTO `sms_partners_two` VALUES(`1625`, `0`, `30`, `0`, `0`, `0`, `0`, `85.159.226.23`);
INSERT INTO `sms_partners_two` VALUES(`1626`, `0`, `30`, `0`, `0`, `0`, `0`, `88.196.50.71`);
INSERT INTO `sms_partners_two` VALUES(`1627`, `0`, `30`, `0`, `0`, `0`, `0`, `46.50.188.217`);
INSERT INTO `sms_partners_two` VALUES(`1628`, `0`, `30`, `0`, `0`, `0`, `0`, `178.46.114.183`);
INSERT INTO `sms_partners_two` VALUES(`1629`, `0`, `30`, `0`, `0`, `0`, `0`, `217.117.64.232`);
INSERT INTO `sms_partners_two` VALUES(`1630`, `0`, `30`, `0`, `0`, `0`, `0`, `109.87.125.25`);
INSERT INTO `sms_partners_two` VALUES(`1631`, `0`, `30`, `0`, `0`, `0`, `0`, `31.23.225.5`);
INSERT INTO `sms_partners_two` VALUES(`1632`, `0`, `30`, `0`, `0`, `0`, `0`, `95.132.59.25`);
INSERT INTO `sms_partners_two` VALUES(`1633`, `0`, `30`, `0`, `0`, `0`, `0`, `188.231.248.94`);
INSERT INTO `sms_partners_two` VALUES(`1634`, `0`, `30`, `0`, `0`, `0`, `0`, `95.135.68.230`);
INSERT INTO `sms_partners_two` VALUES(`1635`, `0`, `30`, `0`, `0`, `0`, `0`, `37.55.9.30`);
INSERT INTO `sms_partners_two` VALUES(`1636`, `0`, `30`, `0`, `0`, `0`, `0`, `178.121.246.253`);
INSERT INTO `sms_partners_two` VALUES(`1637`, `0`, `30`, `0`, `0`, `0`, `0`, `213.21.55.34`);
INSERT INTO `sms_partners_two` VALUES(`1638`, `0`, `30`, `0`, `0`, `0`, `0`, `92.47.37.46`);
INSERT INTO `sms_partners_two` VALUES(`1639`, `0`, `30`, `0`, `0`, `0`, `0`, `86.57.245.207`);
INSERT INTO `sms_partners_two` VALUES(`1640`, `0`, `30`, `0`, `0`, `0`, `0`, `92.242.127.82`);
INSERT INTO `sms_partners_two` VALUES(`1641`, `0`, `30`, `0`, `0`, `0`, `0`, `141.101.18.143`);
INSERT INTO `sms_partners_two` VALUES(`1642`, `0`, `30`, `0`, `0`, `0`, `0`, `178.125.32.105`);
INSERT INTO `sms_partners_two` VALUES(`1643`, `38`, `30`, `0`, `20`, `10`, `0`, `84.15.188.131`);
INSERT INTO `sms_partners_two` VALUES(`1644`, `0`, `30`, `0`, `0`, `0`, `0`, `193.104.213.101`);
INSERT INTO `sms_partners_two` VALUES(`1645`, `0`, `30`, `0`, `0`, `0`, `0`, `95.53.161.117`);
INSERT INTO `sms_partners_two` VALUES(`1646`, `0`, `30`, `0`, `0`, `0`, `0`, `91.207.210.78`);
INSERT INTO `sms_partners_two` VALUES(`1647`, `0`, `30`, `0`, `0`, `0`, `0`, `93.180.234.187`);
INSERT INTO `sms_partners_two` VALUES(`1648`, `0`, `30`, `0`, `0`, `0`, `0`, `158.181.31.109`);
INSERT INTO `sms_partners_two` VALUES(`1649`, `0`, `30`, `0`, `0`, `0`, `0`, `93.78.123.123`);
INSERT INTO `sms_partners_two` VALUES(`1650`, `0`, `30`, `0`, `0`, `0`, `0`, `195.80.231.94`);
INSERT INTO `sms_partners_two` VALUES(`1651`, `0`, `30`, `0`, `0`, `0`, `0`, `217.21.43.222`);
INSERT INTO `sms_partners_two` VALUES(`1652`, `0`, `30`, `0`, `0`, `0`, `0`, `188.187.149.227`);
INSERT INTO `sms_partners_two` VALUES(`1653`, `0`, `30`, `0`, `0`, `0`, `0`, `46.118.199.184`);
INSERT INTO `sms_partners_two` VALUES(`1654`, `0`, `30`, `0`, `0`, `0`, `0`, `176.110.226.59`);
INSERT INTO `sms_partners_two` VALUES(`1655`, `0`, `30`, `0`, `0`, `0`, `0`, `2.94.91.19`);
INSERT INTO `sms_partners_two` VALUES(`1656`, `0`, `30`, `0`, `0`, `0`, `0`, `193.201.199.237`);
INSERT INTO `sms_partners_two` VALUES(`1657`, `0`, `30`, `0`, `0`, `0`, `0`, `193.109.128.82`);
INSERT INTO `sms_partners_two` VALUES(`1658`, `0`, `30`, `0`, `0`, `0`, `0`, `91.230.25.112`);
INSERT INTO `sms_partners_two` VALUES(`1659`, `0`, `30`, `0`, `0`, `0`, `0`, `46.71.4.41`);
INSERT INTO `sms_partners_two` VALUES(`1660`, `0`, `0`, `0`, `0`, `0`, `0`, `91.230.25.112`);
INSERT INTO `sms_partners_two` VALUES(`1661`, `0`, `30`, `0`, `0`, `0`, `0`, `46.98.15.40`);
INSERT INTO `sms_partners_two` VALUES(`1662`, `0`, `30`, `0`, `0`, `0`, `0`, `178.65.145.189`);
INSERT INTO `sms_partners_two` VALUES(`1663`, `0`, `30`, `0`, `0`, `0`, `0`, `92.252.227.2`);
INSERT INTO `sms_partners_two` VALUES(`1664`, `0`, `30`, `0`, `0`, `0`, `0`, `91.197.184.18`);
INSERT INTO `sms_partners_two` VALUES(`1665`, `0`, `30`, `0`, `0`, `0`, `0`, `212.36.243.2`);
INSERT INTO `sms_partners_two` VALUES(`1666`, `0`, `30`, `0`, `0`, `0`, `0`, `188.124.126.224`);
INSERT INTO `sms_partners_two` VALUES(`1667`, `0`, `30`, `0`, `0`, `0`, `0`, `178.90.46.214`);
INSERT INTO `sms_partners_two` VALUES(`1668`, `0`, `30`, `0`, `0`, `0`, `0`, `91.200.138.18`);
INSERT INTO `sms_partners_two` VALUES(`1669`, `0`, `30`, `0`, `0`, `0`, `0`, `212.79.122.241`);
INSERT INTO `sms_partners_two` VALUES(`1670`, `0`, `30`, `0`, `0`, `0`, `0`, `46.44.61.48`);
INSERT INTO `sms_partners_two` VALUES(`1671`, `0`, `30`, `0`, `0`, `0`, `0`, `91.124.106.239`);
INSERT INTO `sms_partners_two` VALUES(`1672`, `0`, `30`, `0`, `0`, `0`, `0`, `109.61.168.11`);
INSERT INTO `sms_partners_two` VALUES(`1673`, `0`, `30`, `0`, `0`, `0`, `0`, `93.175.215.10`);
INSERT INTO `sms_partners_two` VALUES(`1674`, `0`, `30`, `0`, `0`, `0`, `0`, `178.127.193.114`);
INSERT INTO `sms_partners_two` VALUES(`1675`, `0`, `30`, `0`, `0`, `0`, `0`, `195.66.79.211`);
INSERT INTO `sms_partners_two` VALUES(`1676`, `0`, `30`, `0`, `0`, `0`, `0`, `178.172.183.10`);
INSERT INTO `sms_partners_two` VALUES(`1677`, `0`, `30`, `0`, `0`, `0`, `0`, `94.143.192.19`);
INSERT INTO `sms_partners_two` VALUES(`1678`, `0`, `30`, `0`, `0`, `0`, `0`, `178.93.69.117`);
INSERT INTO `sms_partners_two` VALUES(`1679`, `0`, `30`, `0`, `0`, `0`, `0`, `93.175.207.246`);
INSERT INTO `sms_partners_two` VALUES(`1680`, `0`, `30`, `0`, `0`, `0`, `0`, `37.55.188.83`);
INSERT INTO `sms_partners_two` VALUES(`1681`, `0`, `30`, `0`, `0`, `0`, `0`, `178.92.93.209`);
INSERT INTO `sms_partners_two` VALUES(`1682`, `0`, `30`, `0`, `0`, `0`, `0`, `94.179.7.44`);
INSERT INTO `sms_partners_two` VALUES(`1683`, `0`, `30`, `0`, `0`, `0`, `0`, `178.150.102.81`);
INSERT INTO `sms_partners_two` VALUES(`1684`, `0`, `30`, `0`, `0`, `0`, `0`, `188.92.194.171`);
INSERT INTO `sms_partners_two` VALUES(`1685`, `0`, `30`, `0`, `0`, `0`, `0`, `31.43.144.218`);
INSERT INTO `sms_partners_two` VALUES(`1686`, `0`, `30`, `0`, `0`, `0`, `0`, `46.50.207.57`);
INSERT INTO `sms_partners_two` VALUES(`1687`, `0`, `30`, `0`, `0`, `0`, `0`, `95.134.107.202`);
INSERT INTO `sms_partners_two` VALUES(`1688`, `0`, `30`, `0`, `0`, `0`, `0`, `94.198.0.15`);
INSERT INTO `sms_partners_two` VALUES(`1689`, `0`, `30`, `0`, `0`, `0`, `0`, `95.133.77.117`);
INSERT INTO `sms_partners_two` VALUES(`1690`, `0`, `30`, `0`, `0`, `0`, `0`, `178.47.166.52`);
INSERT INTO `sms_partners_two` VALUES(`1691`, `0`, `30`, `0`, `0`, `0`, `0`, `92.49.195.207`);
INSERT INTO `sms_partners_two` VALUES(`1692`, `0`, `30`, `0`, `0`, `0`, `0`, `95.57.56.177`);
INSERT INTO `sms_partners_two` VALUES(`1693`, `0`, `30`, `0`, `0`, `0`, `0`, `77.51.98.196`);
INSERT INTO `sms_partners_two` VALUES(`1694`, `0`, `30`, `0`, `0`, `0`, `0`, `94.43.16.18`);
INSERT INTO `sms_partners_two` VALUES(`1695`, `0`, `30`, `0`, `0`, `0`, `0`, `212.98.185.162`);
INSERT INTO `sms_partners_two` VALUES(`1696`, `0`, `30`, `0`, `0`, `0`, `0`, `46.70.249.254`);
INSERT INTO `sms_partners_two` VALUES(`1697`, `0`, `30`, `0`, `0`, `0`, `0`, `176.28.87.9`);
INSERT INTO `sms_partners_two` VALUES(`1698`, `0`, `30`, `0`, `0`, `0`, `0`, `92.112.190.243`);
INSERT INTO `sms_partners_two` VALUES(`1699`, `0`, `30`, `0`, `0`, `0`, `0`, `178.127.140.20`);
INSERT INTO `sms_partners_two` VALUES(`1700`, `0`, `30`, `0`, `0`, `0`, `0`, `178.172.198.85`);
INSERT INTO `sms_partners_two` VALUES(`1701`, `0`, `30`, `0`, `0`, `0`, `0`, `194.28.70.136`);
INSERT INTO `sms_partners_two` VALUES(`1702`, `0`, `30`, `0`, `0`, `0`, `0`, `109.229.77.91`);
INSERT INTO `sms_partners_two` VALUES(`1703`, `0`, `30`, `0`, `0`, `0`, `0`, `77.45.153.183`);
INSERT INTO `sms_partners_two` VALUES(`1704`, `0`, `30`, `0`, `0`, `0`, `0`, `37.79.13.25`);
INSERT INTO `sms_partners_two` VALUES(`1705`, `0`, `30`, `0`, `0`, `0`, `0`, `80.92.225.22`);
INSERT INTO `sms_partners_two` VALUES(`1706`, `0`, `30`, `0`, `0`, `0`, `0`, `87.244.169.215`);
INSERT INTO `sms_partners_two` VALUES(`1707`, `0`, `30`, `0`, `0`, `0`, `0`, `193.16.247.14`);
INSERT INTO `sms_partners_two` VALUES(`1708`, `0`, `30`, `0`, `0`, `0`, `0`, `95.53.219.177`);
INSERT INTO `sms_partners_two` VALUES(`1709`, `0`, `30`, `0`, `0`, `0`, `0`, `195.22.112.25`);
INSERT INTO `sms_partners_two` VALUES(`1710`, `0`, `30`, `0`, `0`, `0`, `0`, `91.124.37.126`);
INSERT INTO `sms_partners_two` VALUES(`1711`, `0`, `30`, `0`, `0`, `0`, `0`, `178.93.234.8`);
INSERT INTO `sms_partners_two` VALUES(`1712`, `0`, `30`, `0`, `0`, `0`, `0`, `82.209.239.236`);
INSERT INTO `sms_partners_two` VALUES(`1713`, `0`, `30`, `0`, `0`, `0`, `0`, `37.45.90.50`);
INSERT INTO `sms_partners_two` VALUES(`1714`, `0`, `30`, `0`, `0`, `0`, `0`, `188.115.191.245`);
INSERT INTO `sms_partners_two` VALUES(`1715`, `0`, `30`, `0`, `0`, `0`, `0`, `93.170.41.168`);
INSERT INTO `sms_partners_two` VALUES(`1716`, `0`, `30`, `0`, `0`, `0`, `0`, `95.134.158.69`);
INSERT INTO `sms_partners_two` VALUES(`1717`, `0`, `30`, `0`, `0`, `0`, `0`, `109.188.236.92`);
INSERT INTO `sms_partners_two` VALUES(`1718`, `0`, `30`, `0`, `0`, `0`, `0`, `94.75.31.43`);
INSERT INTO `sms_partners_two` VALUES(`1719`, `0`, `30`, `0`, `0`, `0`, `0`, `178.126.241.93`);
INSERT INTO `sms_partners_two` VALUES(`1720`, `0`, `30`, `0`, `0`, `0`, `0`, `195.234.200.169`);
INSERT INTO `sms_partners_two` VALUES(`1721`, `0`, `30`, `0`, `0`, `0`, `0`, `109.191.119.43`);
INSERT INTO `sms_partners_two` VALUES(`1722`, `0`, `30`, `0`, `0`, `0`, `0`, `128.69.147.171`);
INSERT INTO `sms_partners_two` VALUES(`1723`, `0`, `30`, `0`, `0`, `0`, `0`, `82.207.120.38`);
INSERT INTO `sms_partners_two` VALUES(`1724`, `0`, `30`, `0`, `0`, `0`, `0`, `212.1.101.222`);
INSERT INTO `sms_partners_two` VALUES(`1725`, `0`, `30`, `0`, `0`, `0`, `0`, `176.8.217.201`);
INSERT INTO `sms_partners_two` VALUES(`1726`, `0`, `30`, `0`, `0`, `0`, `0`, `91.225.212.225`);
INSERT INTO `sms_partners_two` VALUES(`1727`, `0`, `30`, `0`, `0`, `0`, `0`, `213.87.134.24`);
INSERT INTO `sms_partners_two` VALUES(`1728`, `0`, `30`, `0`, `0`, `0`, `0`, `109.165.119.22`);
INSERT INTO `sms_partners_two` VALUES(`1729`, `0`, `30`, `0`, `0`, `0`, `0`, `46.203.142.79`);
INSERT INTO `sms_partners_two` VALUES(`1730`, `0`, `30`, `0`, `0`, `0`, `0`, `89.23.3.92`);
INSERT INTO `sms_partners_two` VALUES(`1731`, `0`, `30`, `0`, `0`, `0`, `0`, `188.0.73.187`);
INSERT INTO `sms_partners_two` VALUES(`1732`, `0`, `30`, `0`, `0`, `0`, `0`, `89.254.222.40`);
INSERT INTO `sms_partners_two` VALUES(`1733`, `0`, `30`, `0`, `0`, `0`, `0`, `178.177.195.184`);
INSERT INTO `sms_partners_two` VALUES(`1734`, `0`, `30`, `0`, `0`, `0`, `0`, `213.80.204.216`);
INSERT INTO `sms_partners_two` VALUES(`1735`, `0`, `30`, `0`, `0`, `0`, `0`, `92.115.48.101`);
INSERT INTO `sms_partners_two` VALUES(`1736`, `0`, `30`, `0`, `0`, `0`, `0`, `176.32.6.181`);
INSERT INTO `sms_partners_two` VALUES(`1737`, `0`, `30`, `0`, `0`, `0`, `0`, `188.233.131.7`);
INSERT INTO `sms_partners_two` VALUES(`1738`, `0`, `30`, `0`, `0`, `0`, `0`, `92.113.232.97`);
INSERT INTO `sms_partners_two` VALUES(`1739`, `0`, `30`, `0`, `0`, `0`, `0`, `46.162.237.63`);
INSERT INTO `sms_partners_two` VALUES(`1740`, `0`, `30`, `0`, `0`, `0`, `0`, `212.109.37.73`);
INSERT INTO `sms_partners_two` VALUES(`1741`, `0`, `30`, `0`, `0`, `0`, `0`, `37.79.11.44`);
INSERT INTO `sms_partners_two` VALUES(`1742`, `0`, `30`, `0`, `0`, `0`, `0`, `95.133.84.64`);
INSERT INTO `sms_partners_two` VALUES(`1743`, `0`, `30`, `0`, `0`, `0`, `0`, `95.69.136.6`);
INSERT INTO `sms_partners_two` VALUES(`1744`, `0`, `30`, `0`, `0`, `0`, `0`, `95.37.229.252`);
INSERT INTO `sms_partners_two` VALUES(`1745`, `0`, `30`, `0`, `0`, `0`, `0`, `178.120.108.176`);
INSERT INTO `sms_partners_two` VALUES(`1746`, `0`, `30`, `0`, `0`, `0`, `0`, `178.68.5.10`);
INSERT INTO `sms_partners_two` VALUES(`1747`, `0`, `30`, `0`, `0`, `0`, `0`, `91.203.190.180`);
INSERT INTO `sms_partners_two` VALUES(`1748`, `0`, `30`, `0`, `0`, `0`, `0`, `109.87.41.148`);
INSERT INTO `sms_partners_two` VALUES(`1749`, `0`, `30`, `0`, `0`, `0`, `0`, `90.151.33.192`);
INSERT INTO `sms_partners_two` VALUES(`1750`, `0`, `30`, `0`, `0`, `0`, `0`, `85.26.164.142`);
INSERT INTO `sms_partners_two` VALUES(`1751`, `0`, `30`, `0`, `0`, `0`, `0`, `84.106.208.222`);
INSERT INTO `sms_partners_two` VALUES(`1752`, `0`, `30`, `0`, `0`, `0`, `0`, `188.186.54.88`);
INSERT INTO `sms_partners_two` VALUES(`1753`, `0`, `30`, `0`, `0`, `0`, `0`, `213.80.212.94`);
INSERT INTO `sms_partners_two` VALUES(`1754`, `0`, `30`, `0`, `0`, `0`, `0`, `178.124.153.154`);
INSERT INTO `sms_partners_two` VALUES(`1755`, `0`, `30`, `0`, `0`, `0`, `0`, `212.86.112.65`);
INSERT INTO `sms_partners_two` VALUES(`1756`, `0`, `30`, `0`, `0`, `0`, `0`, `178.122.130.114`);
INSERT INTO `sms_partners_two` VALUES(`1757`, `0`, `30`, `0`, `0`, `0`, `0`, `94.179.154.25`);
INSERT INTO `sms_partners_two` VALUES(`1758`, `0`, `30`, `0`, `0`, `0`, `0`, `95.57.72.39`);
INSERT INTO `sms_partners_two` VALUES(`1759`, `0`, `30`, `0`, `0`, `0`, `0`, `37.55.179.24`);
INSERT INTO `sms_partners_two` VALUES(`1760`, `0`, `30`, `0`, `0`, `0`, `0`, `85.26.234.126`);
INSERT INTO `sms_partners_two` VALUES(`1761`, `0`, `30`, `0`, `0`, `0`, `0`, `86.57.137.30`);
INSERT INTO `sms_partners_two` VALUES(`1762`, `0`, `30`, `0`, `0`, `0`, `0`, `178.93.33.13`);
INSERT INTO `sms_partners_two` VALUES(`1763`, `0`, `30`, `0`, `0`, `0`, `0`, `77.120.138.57`);
INSERT INTO `sms_partners_two` VALUES(`1764`, `0`, `30`, `0`, `0`, `0`, `0`, `46.147.171.172`);
INSERT INTO `sms_partners_two` VALUES(`1765`, `0`, `30`, `0`, `0`, `0`, `0`, `178.45.156.40`);
INSERT INTO `sms_partners_two` VALUES(`1766`, `0`, `30`, `0`, `0`, `0`, `0`, `46.247.164.235`);
INSERT INTO `sms_partners_two` VALUES(`1767`, `0`, `30`, `0`, `0`, `0`, `0`, `193.93.16.230`);
INSERT INTO `sms_partners_two` VALUES(`1768`, `0`, `30`, `0`, `0`, `0`, `0`, `46.98.186.230`);
INSERT INTO `sms_partners_two` VALUES(`1769`, `0`, `30`, `0`, `0`, `0`, `0`, `178.94.20.80`);
INSERT INTO `sms_partners_two` VALUES(`1770`, `0`, `30`, `0`, `0`, `0`, `0`, `91.211.129.208`);
INSERT INTO `sms_partners_two` VALUES(`1771`, `0`, `30`, `0`, `0`, `0`, `0`, `109.236.219.125`);
INSERT INTO `sms_partners_two` VALUES(`1772`, `0`, `30`, `0`, `0`, `0`, `0`, `95.79.23.37`);
INSERT INTO `sms_partners_two` VALUES(`1773`, `0`, `30`, `0`, `0`, `0`, `0`, `1.55.92.167`);
INSERT INTO `sms_partners_two` VALUES(`1774`, `0`, `30`, `0`, `0`, `0`, `0`, `217.19.211.89`);
INSERT INTO `sms_partners_two` VALUES(`1775`, `0`, `30`, `0`, `0`, `0`, `0`, `213.87.129.10`);
INSERT INTO `sms_partners_two` VALUES(`1776`, `0`, `30`, `0`, `0`, `0`, `0`, `95.135.123.221`);
INSERT INTO `sms_partners_two` VALUES(`1777`, `0`, `30`, `0`, `0`, `0`, `0`, `178.123.177.219`);
INSERT INTO `sms_partners_two` VALUES(`1778`, `0`, `30`, `0`, `0`, `0`, `0`, `37.45.13.9`);
INSERT INTO `sms_partners_two` VALUES(`1779`, `0`, `30`, `0`, `0`, `0`, `0`, `94.241.30.107`);
INSERT INTO `sms_partners_two` VALUES(`1780`, `0`, `30`, `0`, `0`, `0`, `0`, `77.40.95.231`);
INSERT INTO `sms_partners_two` VALUES(`1781`, `0`, `30`, `0`, `0`, `0`, `0`, `178.90.200.55`);
INSERT INTO `sms_partners_two` VALUES(`1782`, `0`, `30`, `0`, `0`, `0`, `0`, `85.115.224.204`);
INSERT INTO `sms_partners_two` VALUES(`1783`, `0`, `30`, `0`, `0`, `0`, `0`, `178.89.36.210`);
INSERT INTO `sms_partners_two` VALUES(`1784`, `0`, `30`, `0`, `0`, `0`, `0`, `178.46.162.222`);
INSERT INTO `sms_partners_two` VALUES(`1785`, `0`, `30`, `0`, `0`, `0`, `0`, `81.17.128.182`);
INSERT INTO `sms_partners_two` VALUES(`1786`, `0`, `30`, `0`, `0`, `0`, `0`, `95.134.122.189`);
INSERT INTO `sms_partners_two` VALUES(`1787`, `0`, `30`, `0`, `0`, `0`, `0`, `95.134.163.81`);
INSERT INTO `sms_partners_two` VALUES(`1788`, `0`, `30`, `0`, `0`, `0`, `0`, `92.113.214.239`);
INSERT INTO `sms_partners_two` VALUES(`1789`, `0`, `30`, `0`, `0`, `0`, `0`, `176.36.166.167`);
INSERT INTO `sms_partners_two` VALUES(`1790`, `0`, `30`, `0`, `0`, `0`, `0`, `46.158.77.6`);
INSERT INTO `sms_partners_two` VALUES(`1791`, `0`, `30`, `0`, `0`, `0`, `0`, `178.133.43.153`);
INSERT INTO `sms_partners_two` VALUES(`1792`, `0`, `30`, `0`, `0`, `0`, `0`, `95.59.231.191`);
INSERT INTO `sms_partners_two` VALUES(`1793`, `0`, `30`, `0`, `0`, `0`, `0`, `178.120.127.177`);
INSERT INTO `sms_partners_two` VALUES(`1794`, `0`, `30`, `0`, `0`, `0`, `0`, `92.112.181.154`);
INSERT INTO `sms_partners_two` VALUES(`1795`, `0`, `30`, `0`, `0`, `0`, `0`, `37.19.183.173`);
INSERT INTO `sms_partners_two` VALUES(`1796`, `0`, `30`, `0`, `0`, `0`, `0`, `5.1.10.216`);
INSERT INTO `sms_partners_two` VALUES(`1797`, `0`, `30`, `0`, `0`, `0`, `0`, `37.55.191.209`);
INSERT INTO `sms_partners_two` VALUES(`1798`, `0`, `30`, `0`, `0`, `0`, `0`, `94.179.64.205`);
INSERT INTO `sms_partners_two` VALUES(`1799`, `0`, `30`, `0`, `0`, `0`, `0`, `91.201.177.13`);
INSERT INTO `sms_partners_two` VALUES(`1800`, `0`, `30`, `0`, `0`, `0`, `0`, `95.54.28.62`);
INSERT INTO `sms_partners_two` VALUES(`1801`, `0`, `30`, `0`, `0`, `0`, `0`, `188.134.89.158`);
INSERT INTO `sms_partners_two` VALUES(`1802`, `0`, `30`, `0`, `0`, `0`, `0`, `178.89.32.46`);
INSERT INTO `sms_partners_two` VALUES(`1803`, `0`, `30`, `0`, `0`, `0`, `0`, `94.41.118.4`);
INSERT INTO `sms_partners_two` VALUES(`1804`, `0`, `30`, `0`, `0`, `0`, `0`, `109.184.108.10`);
INSERT INTO `sms_partners_two` VALUES(`1805`, `0`, `30`, `0`, `0`, `0`, `0`, `178.125.226.67`);
INSERT INTO `sms_partners_two` VALUES(`1806`, `0`, `30`, `0`, `0`, `0`, `0`, `95.190.51.141`);
INSERT INTO `sms_partners_two` VALUES(`1807`, `0`, `30`, `0`, `0`, `0`, `0`, `78.25.180.73`);
INSERT INTO `sms_partners_two` VALUES(`1808`, `0`, `30`, `0`, `0`, `0`, `0`, `178.126.177.195`);
INSERT INTO `sms_partners_two` VALUES(`1809`, `0`, `30`, `0`, `0`, `0`, `0`, `31.207.246.29`);
INSERT INTO `sms_partners_two` VALUES(`1810`, `0`, `30`, `0`, `0`, `0`, `0`, `178.206.9.19`);
INSERT INTO `sms_partners_two` VALUES(`1811`, `0`, `30`, `0`, `0`, `0`, `0`, `109.254.48.3`);
INSERT INTO `sms_partners_two` VALUES(`1812`, `0`, `30`, `0`, `0`, `0`, `0`, `130.255.140.15`);
INSERT INTO `sms_partners_two` VALUES(`1813`, `0`, `30`, `0`, `0`, `0`, `0`, `31.128.137.31`);
INSERT INTO `sms_partners_two` VALUES(`1814`, `0`, `30`, `0`, `0`, `0`, `0`, `193.25.121.26`);
INSERT INTO `sms_partners_two` VALUES(`1815`, `0`, `30`, `0`, `0`, `0`, `0`, `46.201.143.169`);
INSERT INTO `sms_partners_two` VALUES(`1816`, `0`, `30`, `0`, `0`, `0`, `0`, `194.44.209.42`);
INSERT INTO `sms_partners_two` VALUES(`1817`, `0`, `30`, `0`, `0`, `0`, `0`, `86.57.156.168`);
INSERT INTO `sms_partners_two` VALUES(`1818`, `0`, `30`, `0`, `0`, `0`, `0`, `95.71.98.124`);
INSERT INTO `sms_partners_two` VALUES(`1819`, `0`, `30`, `0`, `0`, `0`, `0`, `91.214.34.12`);
INSERT INTO `sms_partners_two` VALUES(`1820`, `0`, `30`, `0`, `0`, `0`, `0`, `95.133.67.172`);
INSERT INTO `sms_partners_two` VALUES(`1821`, `0`, `30`, `0`, `0`, `0`, `0`, `109.95.73.14`);
INSERT INTO `sms_partners_two` VALUES(`1822`, `0`, `30`, `0`, `0`, `0`, `0`, `178.137.166.58`);
INSERT INTO `sms_partners_two` VALUES(`1823`, `0`, `30`, `0`, `0`, `0`, `0`, `31.24.24.3`);
INSERT INTO `sms_partners_two` VALUES(`1824`, `0`, `30`, `0`, `0`, `0`, `0`, `213.87.142.156`);
INSERT INTO `sms_partners_two` VALUES(`1825`, `0`, `30`, `0`, `0`, `0`, `0`, `95.135.145.29`);
INSERT INTO `sms_partners_two` VALUES(`1826`, `0`, `30`, `0`, `0`, `0`, `0`, `46.211.183.194`);
INSERT INTO `sms_partners_two` VALUES(`1827`, `0`, `30`, `0`, `0`, `0`, `0`, `95.72.84.247`);
INSERT INTO `sms_partners_two` VALUES(`1828`, `0`, `30`, `0`, `0`, `0`, `0`, `37.55.50.135`);
INSERT INTO `sms_partners_two` VALUES(`1829`, `0`, `30`, `0`, `0`, `0`, `0`, `89.28.202.50`);
INSERT INTO `sms_partners_two` VALUES(`1830`, `0`, `30`, `0`, `0`, `0`, `0`, `95.55.247.126`);
INSERT INTO `sms_partners_two` VALUES(`1831`, `0`, `30`, `0`, `0`, `0`, `0`, `217.118.81.29`);
INSERT INTO `sms_partners_two` VALUES(`1832`, `0`, `30`, `0`, `0`, `0`, `0`, `212.87.176.110`);
INSERT INTO `sms_partners_two` VALUES(`1833`, `0`, `30`, `0`, `0`, `0`, `0`, `109.95.47.28`);
INSERT INTO `sms_partners_two` VALUES(`1834`, `0`, `30`, `0`, `0`, `0`, `0`, `46.254.27.49`);
INSERT INTO `sms_partners_two` VALUES(`1835`, `0`, `30`, `0`, `0`, `0`, `0`, `95.134.72.196`);
INSERT INTO `sms_partners_two` VALUES(`1836`, `0`, `30`, `0`, `0`, `0`, `0`, `91.218.192.42`);
INSERT INTO `sms_partners_two` VALUES(`1837`, `0`, `30`, `0`, `0`, `0`, `0`, `77.235.124.45`);
INSERT INTO `sms_partners_two` VALUES(`1838`, `0`, `30`, `0`, `0`, `0`, `0`, `178.126.203.140`);
INSERT INTO `sms_partners_two` VALUES(`1839`, `0`, `30`, `0`, `0`, `0`, `0`, `46.249.6.155`);
INSERT INTO `sms_partners_two` VALUES(`1840`, `0`, `30`, `0`, `0`, `0`, `0`, `92.101.113.238`);
INSERT INTO `sms_partners_two` VALUES(`1841`, `0`, `30`, `0`, `0`, `0`, `0`, `178.49.150.122`);
INSERT INTO `sms_partners_two` VALUES(`1842`, `0`, `30`, `0`, `0`, `0`, `0`, `95.56.91.62`);
INSERT INTO `sms_partners_two` VALUES(`1843`, `0`, `30`, `0`, `0`, `0`, `0`, `84.32.228.111`);
INSERT INTO `sms_partners_two` VALUES(`1844`, `0`, `30`, `0`, `0`, `0`, `0`, `94.27.66.60`);
INSERT INTO `sms_partners_two` VALUES(`1845`, `0`, `30`, `0`, `0`, `0`, `0`, `178.94.8.32`);
INSERT INTO `sms_partners_two` VALUES(`1846`, `0`, `30`, `0`, `0`, `0`, `0`, `89.23.148.43`);
INSERT INTO `sms_partners_two` VALUES(`1847`, `0`, `30`, `0`, `0`, `0`, `0`, `83.149.45.58`);
INSERT INTO `sms_partners_two` VALUES(`1848`, `0`, `30`, `0`, `0`, `0`, `0`, `91.221.133.82`);
INSERT INTO `sms_partners_two` VALUES(`1849`, `0`, `30`, `0`, `0`, `0`, `0`, `62.182.66.81`);
INSERT INTO `sms_partners_two` VALUES(`1850`, `0`, `30`, `0`, `0`, `0`, `0`, `94.137.60.71`);
INSERT INTO `sms_partners_two` VALUES(`1851`, `0`, `30`, `0`, `0`, `0`, `0`, `31.8.235.4`);
INSERT INTO `sms_partners_two` VALUES(`1852`, `0`, `30`, `0`, `0`, `0`, `0`, `37.55.225.184`);
INSERT INTO `sms_partners_two` VALUES(`1853`, `0`, `30`, `0`, `0`, `0`, `0`, `178.214.191.15`);
INSERT INTO `sms_partners_two` VALUES(`1854`, `0`, `30`, `0`, `0`, `0`, `0`, `79.140.2.27`);
INSERT INTO `sms_partners_two` VALUES(`1855`, `0`, `30`, `0`, `0`, `0`, `0`, `178.95.24.80`);
INSERT INTO `sms_partners_two` VALUES(`1856`, `0`, `30`, `0`, `0`, `0`, `0`, `95.135.179.88`);
INSERT INTO `sms_partners_two` VALUES(`1857`, `0`, `30`, `0`, `0`, `0`, `0`, `178.65.62.87`);
INSERT INTO `sms_partners_two` VALUES(`1858`, `0`, `30`, `0`, `0`, `0`, `0`, `194.44.15.110`);
INSERT INTO `sms_partners_two` VALUES(`1859`, `0`, `30`, `0`, `0`, `0`, `0`, `46.119.211.182`);
INSERT INTO `sms_partners_two` VALUES(`1860`, `0`, `30`, `0`, `0`, `0`, `0`, `178.122.189.62`);
INSERT INTO `sms_partners_two` VALUES(`1861`, `0`, `30`, `0`, `0`, `0`, `0`, `95.69.231.156`);
INSERT INTO `sms_partners_two` VALUES(`1862`, `0`, `30`, `0`, `0`, `0`, `0`, `46.109.93.84`);
INSERT INTO `sms_partners_two` VALUES(`1863`, `0`, `30`, `0`, `0`, `0`, `0`, `46.167.107.182`);
INSERT INTO `sms_partners_two` VALUES(`1864`, `0`, `30`, `0`, `0`, `0`, `0`, `91.207.27.50`);
INSERT INTO `sms_partners_two` VALUES(`1865`, `0`, `30`, `0`, `0`, `0`, `0`, `195.54.42.48`);
INSERT INTO `sms_partners_two` VALUES(`1866`, `0`, `30`, `0`, `0`, `0`, `0`, `46.175.160.13`);
INSERT INTO `sms_partners_two` VALUES(`1867`, `0`, `30`, `0`, `0`, `0`, `0`, `89.23.21.71`);
INSERT INTO `sms_partners_two` VALUES(`1868`, `0`, `30`, `0`, `0`, `0`, `0`, `188.18.133.235`);
INSERT INTO `sms_partners_two` VALUES(`1869`, `0`, `30`, `0`, `0`, `0`, `0`, `128.70.83.110`);
INSERT INTO `sms_partners_two` VALUES(`1870`, `0`, `30`, `0`, `0`, `0`, `0`, `95.132.51.244`);
INSERT INTO `sms_partners_two` VALUES(`1871`, `0`, `30`, `0`, `0`, `0`, `0`, `178.127.73.5`);
INSERT INTO `sms_partners_two` VALUES(`1872`, `0`, `30`, `0`, `0`, `0`, `0`, `78.106.32.250`);
INSERT INTO `sms_partners_two` VALUES(`1873`, `0`, `30`, `0`, `0`, `0`, `0`, `85.26.241.18`);
INSERT INTO `sms_partners_two` VALUES(`1874`, `0`, `30`, `0`, `0`, `0`, `0`, `95.133.245.11`);
INSERT INTO `sms_partners_two` VALUES(`1875`, `0`, `30`, `0`, `0`, `0`, `0`, `178.88.87.162`);
INSERT INTO `sms_partners_two` VALUES(`1876`, `0`, `30`, `0`, `0`, `0`, `0`, `93.125.37.11`);
INSERT INTO `sms_partners_two` VALUES(`1877`, `0`, `30`, `0`, `0`, `0`, `0`, `78.29.111.190`);
INSERT INTO `sms_partners_two` VALUES(`1878`, `0`, `30`, `0`, `0`, `0`, `0`, `37.61.10.120`);
INSERT INTO `sms_partners_two` VALUES(`1879`, `0`, `30`, `0`, `0`, `0`, `0`, `46.147.84.87`);
INSERT INTO `sms_partners_two` VALUES(`1880`, `0`, `30`, `0`, `0`, `0`, `0`, `178.122.212.153`);
INSERT INTO `sms_partners_two` VALUES(`1881`, `0`, `30`, `0`, `0`, `0`, `0`, `141.101.31.123`);
INSERT INTO `sms_partners_two` VALUES(`1882`, `0`, `30`, `0`, `0`, `0`, `0`, `92.101.37.11`);
INSERT INTO `sms_partners_two` VALUES(`1883`, `0`, `30`, `0`, `0`, `0`, `0`, `91.124.12.59`);
INSERT INTO `sms_partners_two` VALUES(`1884`, `0`, `30`, `0`, `0`, `0`, `0`, `95.134.45.136`);
INSERT INTO `sms_partners_two` VALUES(`1885`, `0`, `30`, `0`, `0`, `0`, `0`, `85.26.231.70`);
INSERT INTO `sms_partners_two` VALUES(`1886`, `0`, `30`, `0`, `0`, `0`, `0`, `85.141.110.154`);
INSERT INTO `sms_partners_two` VALUES(`1887`, `0`, `30`, `0`, `0`, `0`, `0`, `109.200.149.220`);
INSERT INTO `sms_partners_two` VALUES(`1888`, `0`, `30`, `0`, `0`, `0`, `0`, `91.207.219.32`);
INSERT INTO `sms_partners_two` VALUES(`1889`, `0`, `30`, `0`, `0`, `0`, `0`, `178.122.180.128`);
INSERT INTO `sms_partners_two` VALUES(`1890`, `0`, `30`, `0`, `0`, `0`, `0`, `2.60.76.248`);
INSERT INTO `sms_partners_two` VALUES(`1891`, `0`, `30`, `0`, `0`, `0`, `0`, `81.30.187.48`);
INSERT INTO `sms_partners_two` VALUES(`1892`, `0`, `30`, `0`, `0`, `0`, `0`, `83.149.48.68`);
INSERT INTO `sms_partners_two` VALUES(`1893`, `0`, `30`, `0`, `0`, `0`, `0`, `95.132.28.1`);
INSERT INTO `sms_partners_two` VALUES(`1894`, `0`, `30`, `0`, `0`, `0`, `0`, `109.68.234.15`);
INSERT INTO `sms_partners_two` VALUES(`1895`, `0`, `30`, `0`, `0`, `0`, `0`, `77.66.157.177`);
INSERT INTO `sms_partners_two` VALUES(`1896`, `0`, `30`, `0`, `0`, `0`, `0`, `188.16.128.242`);
INSERT INTO `sms_partners_two` VALUES(`1897`, `0`, `30`, `0`, `0`, `0`, `0`, `92.46.180.7`);
INSERT INTO `sms_partners_two` VALUES(`1898`, `0`, `30`, `0`, `0`, `0`, `0`, `2.133.71.53`);
INSERT INTO `sms_partners_two` VALUES(`1899`, `0`, `30`, `0`, `0`, `0`, `0`, `84.240.248.150`);
INSERT INTO `sms_partners_two` VALUES(`1900`, `0`, `30`, `0`, `0`, `0`, `0`, `213.154.222.185`);
INSERT INTO `sms_partners_two` VALUES(`1901`, `0`, `30`, `0`, `0`, `0`, `0`, `95.26.154.102`);
INSERT INTO `sms_partners_two` VALUES(`1902`, `0`, `30`, `0`, `0`, `0`, `0`, `212.93.105.31`);
INSERT INTO `sms_partners_two` VALUES(`1903`, `0`, `30`, `0`, `0`, `0`, `0`, `95.132.127.117`);
INSERT INTO `sms_partners_two` VALUES(`1904`, `0`, `30`, `0`, `0`, `0`, `0`, `94.242.175.165`);
INSERT INTO `sms_partners_two` VALUES(`1905`, `0`, `30`, `0`, `0`, `0`, `0`, `78.85.234.232`);
INSERT INTO `sms_partners_two` VALUES(`1906`, `0`, `30`, `0`, `0`, `0`, `0`, `77.79.148.130`);
INSERT INTO `sms_partners_two` VALUES(`1907`, `0`, `30`, `0`, `0`, `0`, `0`, `31.207.144.215`);
INSERT INTO `sms_partners_two` VALUES(`1908`, `0`, `30`, `0`, `0`, `0`, `0`, `46.165.10.59`);
INSERT INTO `sms_partners_two` VALUES(`1909`, `0`, `30`, `0`, `0`, `0`, `0`, `92.248.249.164`);
INSERT INTO `sms_partners_two` VALUES(`1910`, `0`, `30`, `0`, `0`, `0`, `0`, `46.33.52.187`);
INSERT INTO `sms_partners_two` VALUES(`1911`, `0`, `30`, `0`, `0`, `0`, `0`, `176.109.218.22`);
INSERT INTO `sms_partners_two` VALUES(`1912`, `0`, `30`, `0`, `0`, `0`, `0`, `84.54.107.144`);
INSERT INTO `sms_partners_two` VALUES(`1913`, `0`, `30`, `0`, `0`, `0`, `0`, `195.184.208.11`);
INSERT INTO `sms_partners_two` VALUES(`1914`, `0`, `30`, `0`, `0`, `0`, `0`, `178.120.172.184`);
INSERT INTO `sms_partners_two` VALUES(`1915`, `0`, `30`, `0`, `0`, `0`, `0`, `95.58.128.197`);
INSERT INTO `sms_partners_two` VALUES(`1916`, `0`, `30`, `0`, `0`, `0`, `0`, `46.72.231.217`);
INSERT INTO `sms_partners_two` VALUES(`1917`, `0`, `30`, `0`, `0`, `0`, `0`, `46.98.97.128`);
INSERT INTO `sms_partners_two` VALUES(`1918`, `0`, `30`, `0`, `0`, `0`, `0`, `178.90.231.231`);
INSERT INTO `sms_partners_two` VALUES(`1919`, `0`, `30`, `0`, `0`, `0`, `0`, `213.231.54.30`);
INSERT INTO `sms_partners_two` VALUES(`1920`, `0`, `30`, `0`, `0`, `0`, `0`, `178.94.52.39`);
INSERT INTO `sms_partners_two` VALUES(`1921`, `0`, `30`, `0`, `0`, `0`, `0`, `46.138.116.26`);
INSERT INTO `sms_partners_two` VALUES(`1922`, `0`, `30`, `0`, `0`, `0`, `0`, `81.162.72.56`);
INSERT INTO `sms_partners_two` VALUES(`1923`, `0`, `30`, `0`, `0`, `0`, `0`, `88.135.63.64`);
INSERT INTO `sms_partners_two` VALUES(`1924`, `0`, `30`, `0`, `0`, `0`, `0`, `178.126.231.191`);
INSERT INTO `sms_partners_two` VALUES(`1925`, `0`, `30`, `0`, `0`, `0`, `0`, `195.191.12.107`);
INSERT INTO `sms_partners_two` VALUES(`1926`, `0`, `30`, `0`, `0`, `0`, `0`, `37.17.178.166`);
INSERT INTO `sms_partners_two` VALUES(`1927`, `0`, `30`, `0`, `0`, `0`, `0`, `95.67.188.183`);
INSERT INTO `sms_partners_two` VALUES(`1928`, `0`, `30`, `0`, `0`, `0`, `0`, `95.69.219.145`);
INSERT INTO `sms_partners_two` VALUES(`1929`, `0`, `30`, `0`, `0`, `0`, `0`, `78.132.161.16`);
INSERT INTO `sms_partners_two` VALUES(`1930`, `0`, `30`, `0`, `0`, `0`, `0`, `31.31.21.198`);
INSERT INTO `sms_partners_two` VALUES(`1931`, `0`, `30`, `0`, `0`, `0`, `0`, `109.75.201.83`);
INSERT INTO `sms_partners_two` VALUES(`1932`, `0`, `30`, `0`, `0`, `0`, `0`, `109.251.22.4`);
INSERT INTO `sms_partners_two` VALUES(`1933`, `0`, `30`, `0`, `0`, `0`, `0`, `79.177.26.211`);
INSERT INTO `sms_partners_two` VALUES(`1934`, `0`, `30`, `0`, `0`, `0`, `0`, `46.119.152.88`);
INSERT INTO `sms_partners_two` VALUES(`1935`, `0`, `30`, `0`, `0`, `0`, `0`, `77.88.231.96`);
INSERT INTO `sms_partners_two` VALUES(`1936`, `0`, `30`, `0`, `0`, `0`, `0`, `79.100.216.200`);
INSERT INTO `sms_partners_two` VALUES(`1937`, `0`, `30`, `0`, `0`, `0`, `0`, `2.92.21.248`);
INSERT INTO `sms_partners_two` VALUES(`1938`, `0`, `30`, `0`, `0`, `0`, `0`, `2.60.121.205`);
INSERT INTO `sms_partners_two` VALUES(`1939`, `0`, `30`, `0`, `0`, `0`, `0`, `217.66.152.10`);
INSERT INTO `sms_partners_two` VALUES(`1940`, `0`, `30`, `0`, `0`, `0`, `0`, `109.162.16.162`);
INSERT INTO `sms_partners_two` VALUES(`1941`, `0`, `30`, `0`, `0`, `0`, `0`, `46.70.58.76`);
INSERT INTO `sms_partners_two` VALUES(`1942`, `0`, `30`, `0`, `0`, `0`, `0`, `178.126.243.17`);
INSERT INTO `sms_partners_two` VALUES(`1943`, `0`, `30`, `0`, `0`, `0`, `0`, `88.135.126.44`);
INSERT INTO `sms_partners_two` VALUES(`1944`, `0`, `30`, `0`, `0`, `0`, `0`, `37.45.21.216`);
INSERT INTO `sms_partners_two` VALUES(`1945`, `0`, `30`, `0`, `0`, `0`, `0`, `95.132.215.185`);
INSERT INTO `sms_partners_two` VALUES(`1946`, `0`, `30`, `0`, `0`, `0`, `0`, `95.71.157.154`);
INSERT INTO `sms_partners_two` VALUES(`1947`, `0`, `30`, `0`, `0`, `0`, `0`, `178.78.180.0`);
INSERT INTO `sms_partners_two` VALUES(`1948`, `0`, `30`, `0`, `0`, `0`, `0`, `178.124.1.176`);
INSERT INTO `sms_partners_two` VALUES(`1949`, `0`, `30`, `0`, `0`, `0`, `0`, `92.115.189.251`);
INSERT INTO `sms_partners_two` VALUES(`1950`, `0`, `30`, `0`, `0`, `0`, `0`, `95.134.98.201`);
INSERT INTO `sms_partners_two` VALUES(`1951`, `0`, `30`, `0`, `0`, `0`, `0`, `37.49.207.40`);
INSERT INTO `sms_partners_two` VALUES(`1952`, `0`, `30`, `0`, `0`, `0`, `0`, `46.247.186.172`);
INSERT INTO `sms_partners_two` VALUES(`1953`, `0`, `30`, `0`, `0`, `0`, `0`, `178.125.147.246`);
INSERT INTO `sms_partners_two` VALUES(`1954`, `0`, `30`, `0`, `0`, `0`, `0`, `95.59.220.92`);
INSERT INTO `sms_partners_two` VALUES(`1955`, `0`, `30`, `0`, `0`, `0`, `0`, `176.8.95.159`);
INSERT INTO `sms_partners_two` VALUES(`1956`, `0`, `30`, `0`, `0`, `0`, `0`, `213.138.70.54`);
INSERT INTO `sms_partners_two` VALUES(`1957`, `0`, `30`, `0`, `0`, `0`, `0`, `83.149.44.1`);
INSERT INTO `sms_partners_two` VALUES(`1958`, `0`, `30`, `0`, `0`, `0`, `0`, `46.247.129.128`);
INSERT INTO `sms_partners_two` VALUES(`1959`, `0`, `30`, `0`, `0`, `0`, `0`, `91.210.23.128`);
INSERT INTO `sms_partners_two` VALUES(`1960`, `0`, `30`, `0`, `0`, `0`, `0`, `109.86.201.180`);
INSERT INTO `sms_partners_two` VALUES(`1961`, `0`, `30`, `0`, `0`, `0`, `0`, `178.94.30.106`);
INSERT INTO `sms_partners_two` VALUES(`1962`, `0`, `30`, `0`, `0`, `0`, `0`, `95.135.202.229`);
INSERT INTO `sms_partners_two` VALUES(`1963`, `0`, `30`, `0`, `0`, `0`, `0`, `159.224.108.6`);
INSERT INTO `sms_partners_two` VALUES(`1964`, `0`, `30`, `0`, `0`, `0`, `0`, `128.69.116.14`);
INSERT INTO `sms_partners_two` VALUES(`1965`, `0`, `30`, `0`, `0`, `0`, `0`, `178.157.153.246`);
INSERT INTO `sms_partners_two` VALUES(`1966`, `0`, `30`, `0`, `0`, `0`, `0`, `95.81.242.53`);
INSERT INTO `sms_partners_two` VALUES(`1967`, `0`, `30`, `0`, `0`, `0`, `0`, `217.28.72.96`);
INSERT INTO `sms_partners_two` VALUES(`1968`, `0`, `30`, `0`, `0`, `0`, `0`, `178.172.170.158`);
INSERT INTO `sms_partners_two` VALUES(`1969`, `0`, `30`, `0`, `0`, `0`, `0`, `109.122.0.214`);
INSERT INTO `sms_partners_two` VALUES(`1970`, `0`, `30`, `0`, `0`, `0`, `0`, `80.84.177.166`);
INSERT INTO `sms_partners_two` VALUES(`1971`, `0`, `30`, `0`, `0`, `0`, `0`, `178.92.118.235`);
INSERT INTO `sms_partners_two` VALUES(`1972`, `0`, `30`, `0`, `0`, `0`, `0`, `37.45.132.165`);
INSERT INTO `sms_partners_two` VALUES(`1973`, `0`, `30`, `0`, `0`, `0`, `0`, `178.252.87.149`);
INSERT INTO `sms_partners_two` VALUES(`1974`, `0`, `30`, `0`, `0`, `0`, `0`, `136.169.135.108`);
INSERT INTO `sms_partners_two` VALUES(`1975`, `0`, `30`, `0`, `0`, `0`, `0`, `178.213.175.23`);
INSERT INTO `sms_partners_two` VALUES(`1976`, `0`, `30`, `0`, `0`, `0`, `0`, `91.214.210.223`);
INSERT INTO `sms_partners_two` VALUES(`1977`, `0`, `30`, `0`, `0`, `0`, `0`, `95.79.191.6`);
INSERT INTO `sms_partners_two` VALUES(`1978`, `0`, `30`, `0`, `0`, `0`, `0`, `79.139.164.131`);
INSERT INTO `sms_partners_two` VALUES(`1979`, `0`, `30`, `0`, `0`, `0`, `0`, `46.229.140.62`);
INSERT INTO `sms_partners_two` VALUES(`1980`, `0`, `30`, `0`, `0`, `0`, `0`, `128.74.127.25`);
INSERT INTO `sms_partners_two` VALUES(`1981`, `0`, `30`, `0`, `0`, `0`, `0`, `92.112.46.90`);
INSERT INTO `sms_partners_two` VALUES(`1982`, `0`, `30`, `0`, `0`, `0`, `0`, `212.92.234.21`);
INSERT INTO `sms_partners_two` VALUES(`1983`, `0`, `30`, `0`, `0`, `0`, `0`, `109.187.200.173`);
INSERT INTO `sms_partners_two` VALUES(`1984`, `0`, `30`, `0`, `0`, `0`, `0`, `95.135.222.184`);
INSERT INTO `sms_partners_two` VALUES(`1985`, `0`, `30`, `0`, `0`, `0`, `0`, `178.94.193.39`);
INSERT INTO `sms_partners_two` VALUES(`1986`, `0`, `30`, `0`, `0`, `0`, `0`, `213.227.240.182`);
INSERT INTO `sms_partners_two` VALUES(`1987`, `0`, `30`, `0`, `0`, `0`, `0`, `83.149.35.63`);
INSERT INTO `sms_partners_two` VALUES(`1988`, `0`, `30`, `0`, `0`, `0`, `0`, `188.72.122.13`);
INSERT INTO `sms_partners_two` VALUES(`1989`, `0`, `30`, `0`, `0`, `0`, `0`, `94.43.179.7`);
INSERT INTO `sms_partners_two` VALUES(`1990`, `0`, `30`, `0`, `0`, `0`, `0`, `92.43.189.12`);
INSERT INTO `sms_partners_two` VALUES(`1991`, `0`, `30`, `0`, `0`, `0`, `0`, `178.89.20.194`);
INSERT INTO `sms_partners_two` VALUES(`1992`, `0`, `30`, `0`, `0`, `0`, `0`, `31.130.69.146`);
INSERT INTO `sms_partners_two` VALUES(`1993`, `0`, `30`, `0`, `0`, `0`, `0`, `178.120.26.104`);
INSERT INTO `sms_partners_two` VALUES(`1994`, `0`, `30`, `0`, `0`, `0`, `0`, `188.115.146.197`);
INSERT INTO `sms_partners_two` VALUES(`1995`, `0`, `30`, `0`, `0`, `0`, `0`, `95.129.172.224`);
INSERT INTO `sms_partners_two` VALUES(`1996`, `0`, `30`, `0`, `0`, `0`, `0`, `213.87.138.197`);
INSERT INTO `sms_partners_two` VALUES(`1997`, `0`, `30`, `0`, `0`, `0`, `0`, `95.153.71.189`);
INSERT INTO `sms_partners_two` VALUES(`1998`, `0`, `30`, `0`, `0`, `0`, `0`, `95.67.247.249`);
INSERT INTO `sms_partners_two` VALUES(`1999`, `0`, `30`, `0`, `0`, `0`, `0`, `93.85.137.38`);
INSERT INTO `sms_partners_two` VALUES(`2000`, `0`, `30`, `0`, `0`, `0`, `0`, `92.100.211.252`);
INSERT INTO `sms_partners_two` VALUES(`2001`, `0`, `30`, `0`, `0`, `0`, `0`, `92.55.52.118`);
INSERT INTO `sms_partners_two` VALUES(`2002`, `0`, `30`, `0`, `0`, `0`, `0`, `109.87.159.14`);
INSERT INTO `sms_partners_two` VALUES(`2003`, `0`, `30`, `0`, `0`, `0`, `0`, `77.93.57.149`);
INSERT INTO `sms_partners_two` VALUES(`2004`, `0`, `30`, `0`, `0`, `0`, `0`, `109.74.127.6`);
INSERT INTO `sms_partners_two` VALUES(`2005`, `0`, `30`, `0`, `0`, `0`, `0`, `95.53.79.187`);
INSERT INTO `sms_partners_two` VALUES(`2006`, `0`, `30`, `0`, `0`, `0`, `0`, `78.111.58.31`);
INSERT INTO `sms_partners_two` VALUES(`2007`, `0`, `30`, `0`, `0`, `0`, `0`, `46.162.228.225`);
INSERT INTO `sms_partners_two` VALUES(`2008`, `0`, `30`, `0`, `0`, `0`, `0`, `93.84.52.37`);
INSERT INTO `sms_partners_two` VALUES(`2009`, `0`, `30`, `0`, `0`, `0`, `0`, `212.87.169.254`);
INSERT INTO `sms_partners_two` VALUES(`2010`, `0`, `30`, `0`, `0`, `0`, `0`, `79.228.208.122`);
INSERT INTO `sms_partners_two` VALUES(`2011`, `0`, `30`, `0`, `0`, `0`, `0`, `178.121.51.53`);
INSERT INTO `sms_partners_two` VALUES(`2012`, `0`, `30`, `0`, `0`, `0`, `0`, `91.76.141.111`);
INSERT INTO `sms_partners_two` VALUES(`2013`, `0`, `30`, `0`, `0`, `0`, `0`, `37.55.203.6`);
INSERT INTO `sms_partners_two` VALUES(`2014`, `0`, `30`, `0`, `0`, `0`, `0`, `178.122.241.7`);
INSERT INTO `sms_partners_two` VALUES(`2015`, `0`, `30`, `0`, `0`, `0`, `0`, `89.223.47.43`);
INSERT INTO `sms_partners_two` VALUES(`2016`, `0`, `30`, `0`, `0`, `0`, `0`, `176.212.181.157`);
INSERT INTO `sms_partners_two` VALUES(`2017`, `0`, `30`, `0`, `0`, `0`, `0`, `91.219.141.95`);
INSERT INTO `sms_partners_two` VALUES(`2018`, `0`, `30`, `0`, `0`, `0`, `0`, `178.47.94.128`);
INSERT INTO `sms_partners_two` VALUES(`2019`, `0`, `30`, `0`, `0`, `0`, `0`, `46.241.249.145`);
INSERT INTO `sms_partners_two` VALUES(`2020`, `0`, `30`, `0`, `0`, `0`, `0`, `188.16.99.146`);
INSERT INTO `sms_partners_two` VALUES(`2021`, `0`, `30`, `0`, `0`, `0`, `0`, `94.241.245.73`);
INSERT INTO `sms_partners_two` VALUES(`2022`, `0`, `30`, `0`, `0`, `0`, `0`, `178.165.0.81`);
INSERT INTO `sms_partners_two` VALUES(`2023`, `0`, `30`, `0`, `0`, `0`, `0`, `37.45.250.136`);
INSERT INTO `sms_partners_two` VALUES(`2024`, `0`, `30`, `0`, `0`, `0`, `0`, `77.244.165.35`);
INSERT INTO `sms_partners_two` VALUES(`2025`, `0`, `30`, `0`, `0`, `0`, `0`, `37.192.250.16`);
INSERT INTO `sms_partners_two` VALUES(`2026`, `0`, `30`, `0`, `0`, `0`, `0`, `37.214.7.132`);
INSERT INTO `sms_partners_two` VALUES(`2027`, `0`, `30`, `0`, `0`, `0`, `0`, `88.206.13.221`);
INSERT INTO `sms_partners_two` VALUES(`2028`, `0`, `30`, `0`, `0`, `0`, `0`, `2.133.216.84`);
INSERT INTO `sms_partners_two` VALUES(`2029`, `0`, `30`, `0`, `0`, `0`, `0`, `87.117.190.77`);
INSERT INTO `sms_partners_two` VALUES(`2030`, `0`, `30`, `0`, `0`, `0`, `0`, `91.203.67.25`);
INSERT INTO `sms_partners_two` VALUES(`2031`, `0`, `30`, `0`, `0`, `0`, `0`, `178.91.198.204`);
INSERT INTO `sms_partners_two` VALUES(`2032`, `0`, `30`, `0`, `0`, `0`, `0`, `37.214.33.73`);
INSERT INTO `sms_partners_two` VALUES(`2033`, `0`, `30`, `0`, `0`, `0`, `0`, `77.120.181.119`);
INSERT INTO `sms_partners_two` VALUES(`2034`, `0`, `30`, `0`, `0`, `0`, `0`, `95.67.195.9`);
INSERT INTO `sms_partners_two` VALUES(`2035`, `0`, `30`, `0`, `0`, `0`, `0`, `93.171.118.102`);
INSERT INTO `sms_partners_two` VALUES(`2036`, `0`, `30`, `0`, `0`, `0`, `0`, `46.118.226.23`);
INSERT INTO `sms_partners_two` VALUES(`2037`, `0`, `30`, `0`, `0`, `0`, `0`, `92.112.122.52`);
INSERT INTO `sms_partners_two` VALUES(`2038`, `0`, `30`, `0`, `0`, `0`, `0`, `93.85.12.254`);
INSERT INTO `sms_partners_two` VALUES(`2039`, `0`, `30`, `0`, `0`, `0`, `0`, `46.71.73.37`);
INSERT INTO `sms_partners_two` VALUES(`2040`, `0`, `30`, `0`, `0`, `0`, `0`, `212.66.32.162`);
INSERT INTO `sms_partners_two` VALUES(`2041`, `0`, `30`, `0`, `0`, `0`, `0`, `83.149.44.8`);
INSERT INTO `sms_partners_two` VALUES(`2042`, `0`, `30`, `0`, `0`, `0`, `0`, `95.134.184.233`);
INSERT INTO `sms_partners_two` VALUES(`2043`, `0`, `30`, `0`, `0`, `0`, `0`, `176.67.2.161`);
INSERT INTO `sms_partners_two` VALUES(`2044`, `0`, `30`, `0`, `0`, `0`, `0`, `37.55.209.56`);
INSERT INTO `sms_partners_two` VALUES(`2045`, `0`, `30`, `0`, `0`, `0`, `0`, `94.179.228.93`);
INSERT INTO `sms_partners_two` VALUES(`2046`, `0`, `30`, `0`, `0`, `0`, `0`, `89.189.19.149`);
INSERT INTO `sms_partners_two` VALUES(`2047`, `0`, `30`, `0`, `0`, `0`, `0`, `95.52.51.141`);
INSERT INTO `sms_partners_two` VALUES(`2048`, `0`, `30`, `0`, `0`, `0`, `0`, `92.112.50.134`);
INSERT INTO `sms_partners_two` VALUES(`2049`, `0`, `30`, `0`, `0`, `0`, `0`, `37.213.68.141`);
INSERT INTO `sms_partners_two` VALUES(`2050`, `0`, `30`, `0`, `0`, `0`, `0`, `78.137.55.212`);
INSERT INTO `sms_partners_two` VALUES(`2051`, `0`, `30`, `0`, `0`, `0`, `0`, `89.149.109.26`);
INSERT INTO `sms_partners_two` VALUES(`2052`, `0`, `30`, `0`, `0`, `0`, `0`, `95.52.213.110`);
INSERT INTO `sms_partners_two` VALUES(`2053`, `0`, `30`, `0`, `0`, `0`, `0`, `94.137.48.133`);
INSERT INTO `sms_partners_two` VALUES(`2054`, `0`, `30`, `0`, `0`, `0`, `0`, `46.175.169.34`);
INSERT INTO `sms_partners_two` VALUES(`2055`, `0`, `30`, `0`, `0`, `0`, `0`, `31.131.218.161`);
INSERT INTO `sms_partners_two` VALUES(`2056`, `0`, `30`, `0`, `0`, `0`, `0`, `109.61.255.168`);
INSERT INTO `sms_partners_two` VALUES(`2057`, `0`, `30`, `0`, `0`, `0`, `0`, `46.250.120.136`);
INSERT INTO `sms_partners_two` VALUES(`2058`, `0`, `30`, `0`, `0`, `0`, `0`, `178.122.201.202`);
INSERT INTO `sms_partners_two` VALUES(`2059`, `0`, `30`, `0`, `0`, `0`, `0`, `95.54.93.234`);
INSERT INTO `sms_partners_two` VALUES(`2060`, `0`, `30`, `0`, `0`, `0`, `0`, `46.250.5.24`);
INSERT INTO `sms_partners_two` VALUES(`2061`, `0`, `30`, `0`, `0`, `0`, `0`, `46.0.152.175`);
INSERT INTO `sms_partners_two` VALUES(`2062`, `0`, `30`, `0`, `0`, `0`, `0`, `178.121.245.28`);
INSERT INTO `sms_partners_two` VALUES(`2063`, `0`, `30`, `0`, `0`, `0`, `0`, `130.185.14.165`);
INSERT INTO `sms_partners_two` VALUES(`2064`, `0`, `30`, `0`, `0`, `0`, `0`, `128.73.147.86`);
INSERT INTO `sms_partners_two` VALUES(`2065`, `0`, `30`, `0`, `0`, `0`, `0`, `94.43.215.191`);
INSERT INTO `sms_partners_two` VALUES(`2066`, `0`, `30`, `0`, `0`, `0`, `0`, `92.112.206.237`);
INSERT INTO `sms_partners_two` VALUES(`2067`, `0`, `30`, `0`, `0`, `0`, `0`, `79.133.135.128`);
INSERT INTO `sms_partners_two` VALUES(`2068`, `0`, `30`, `0`, `0`, `0`, `0`, `88.135.63.1`);
INSERT INTO `sms_partners_two` VALUES(`2069`, `0`, `30`, `0`, `0`, `0`, `0`, `178.214.168.182`);
INSERT INTO `sms_partners_two` VALUES(`2070`, `0`, `30`, `0`, `0`, `0`, `0`, `92.113.16.70`);
INSERT INTO `sms_partners_two` VALUES(`2071`, `0`, `30`, `0`, `0`, `0`, `0`, `195.39.211.242`);
INSERT INTO `sms_partners_two` VALUES(`2072`, `0`, `30`, `0`, `0`, `0`, `0`, `178.70.171.94`);
INSERT INTO `sms_partners_two` VALUES(`2073`, `0`, `30`, `0`, `0`, `0`, `0`, `86.106.255.223`);
INSERT INTO `sms_partners_two` VALUES(`2074`, `0`, `30`, `0`, `0`, `0`, `0`, `31.31.11.7`);
INSERT INTO `sms_partners_two` VALUES(`2075`, `0`, `30`, `0`, `0`, `0`, `0`, `92.112.104.22`);
INSERT INTO `sms_partners_two` VALUES(`2076`, `0`, `30`, `0`, `0`, `0`, `0`, `109.67.4.173`);
INSERT INTO `sms_partners_two` VALUES(`2077`, `0`, `30`, `0`, `0`, `0`, `0`, `178.127.216.119`);
INSERT INTO `sms_partners_two` VALUES(`2078`, `0`, `30`, `0`, `0`, `0`, `0`, `2.94.51.144`);
INSERT INTO `sms_partners_two` VALUES(`2079`, `0`, `30`, `0`, `0`, `0`, `0`, `109.227.97.129`);
INSERT INTO `sms_partners_two` VALUES(`2080`, `0`, `30`, `0`, `0`, `0`, `0`, `95.81.9.32`);
INSERT INTO `sms_partners_two` VALUES(`2081`, `0`, `30`, `0`, `0`, `0`, `0`, `37.229.62.134`);
INSERT INTO `sms_partners_two` VALUES(`2082`, `0`, `30`, `0`, `0`, `0`, `0`, `79.100.51.38`);
INSERT INTO `sms_partners_two` VALUES(`2083`, `0`, `30`, `0`, `0`, `0`, `0`, `79.126.81.60`);
INSERT INTO `sms_partners_two` VALUES(`2084`, `0`, `30`, `0`, `0`, `0`, `0`, `178.218.44.85`);
INSERT INTO `sms_partners_two` VALUES(`2085`, `0`, `30`, `0`, `0`, `0`, `0`, `91.143.4.156`);
INSERT INTO `sms_partners_two` VALUES(`2086`, `0`, `30`, `0`, `0`, `0`, `0`, `194.247.17.21`);
INSERT INTO `sms_partners_two` VALUES(`2087`, `0`, `30`, `0`, `0`, `0`, `0`, `141.101.26.135`);
INSERT INTO `sms_partners_two` VALUES(`2088`, `0`, `30`, `0`, `0`, `0`, `0`, `93.114.11.238`);
INSERT INTO `sms_partners_two` VALUES(`2089`, `0`, `30`, `0`, `0`, `0`, `0`, `212.117.11.235`);
INSERT INTO `sms_partners_two` VALUES(`2090`, `0`, `30`, `0`, `0`, `0`, `0`, `194.28.64.86`);
INSERT INTO `sms_partners_two` VALUES(`2091`, `0`, `30`, `0`, `0`, `0`, `0`, `178.92.116.223`);
INSERT INTO `sms_partners_two` VALUES(`2092`, `0`, `30`, `0`, `0`, `0`, `0`, `217.146.246.17`);
INSERT INTO `sms_partners_two` VALUES(`2093`, `0`, `30`, `0`, `0`, `0`, `0`, `178.94.228.19`);
INSERT INTO `sms_partners_two` VALUES(`2094`, `0`, `30`, `0`, `0`, `0`, `0`, `94.179.127.156`);
INSERT INTO `sms_partners_two` VALUES(`2095`, `0`, `30`, `0`, `0`, `0`, `0`, `178.172.210.39`);
INSERT INTO `sms_partners_two` VALUES(`2096`, `0`, `30`, `0`, `0`, `0`, `0`, `78.132.157.147`);
INSERT INTO `sms_partners_two` VALUES(`2097`, `0`, `30`, `0`, `0`, `0`, `0`, `178.125.58.90`);
INSERT INTO `sms_partners_two` VALUES(`2098`, `0`, `30`, `0`, `0`, `0`, `0`, `62.209.151.15`);
INSERT INTO `sms_partners_two` VALUES(`2099`, `0`, `30`, `0`, `0`, `0`, `0`, `93.79.62.99`);
INSERT INTO `sms_partners_two` VALUES(`2100`, `0`, `30`, `0`, `0`, `0`, `0`, `178.93.73.172`);
INSERT INTO `sms_partners_two` VALUES(`2101`, `0`, `30`, `0`, `0`, `0`, `0`, `82.207.42.89`);
INSERT INTO `sms_partners_two` VALUES(`2102`, `0`, `30`, `0`, `0`, `0`, `0`, `92.112.223.24`);
INSERT INTO `sms_partners_two` VALUES(`2103`, `0`, `30`, `0`, `0`, `0`, `0`, `193.25.121.58`);
INSERT INTO `sms_partners_two` VALUES(`2104`, `0`, `30`, `0`, `0`, `0`, `0`, `85.115.248.60`);
INSERT INTO `sms_partners_two` VALUES(`2105`, `0`, `30`, `0`, `0`, `0`, `0`, `91.239.104.126`);
INSERT INTO `sms_partners_two` VALUES(`2106`, `0`, `30`, `0`, `0`, `0`, `0`, `178.159.219.172`);
INSERT INTO `sms_partners_two` VALUES(`2107`, `0`, `30`, `0`, `0`, `0`, `0`, `78.24.10.235`);
INSERT INTO `sms_partners_two` VALUES(`2108`, `0`, `30`, `0`, `0`, `0`, `0`, `87.225.61.89`);
INSERT INTO `sms_partners_two` VALUES(`2109`, `0`, `30`, `0`, `0`, `0`, `0`, `91.124.143.100`);
INSERT INTO `sms_partners_two` VALUES(`2110`, `0`, `30`, `0`, `0`, `0`, `0`, `188.255.27.215`);
INSERT INTO `sms_partners_two` VALUES(`2111`, `0`, `30`, `0`, `0`, `0`, `0`, `92.46.182.88`);
INSERT INTO `sms_partners_two` VALUES(`2112`, `0`, `30`, `0`, `0`, `0`, `0`, `84.54.120.135`);
INSERT INTO `sms_partners_two` VALUES(`2113`, `0`, `30`, `0`, `0`, `0`, `0`, `62.122.203.231`);
INSERT INTO `sms_partners_two` VALUES(`2114`, `0`, `30`, `0`, `0`, `0`, `0`, `31.170.146.67`);
INSERT INTO `sms_partners_two` VALUES(`2115`, `0`, `30`, `0`, `0`, `0`, `0`, `31.181.233.179`);
INSERT INTO `sms_partners_two` VALUES(`2116`, `0`, `30`, `0`, `0`, `0`, `0`, `178.95.217.175`);
INSERT INTO `sms_partners_two` VALUES(`2117`, `0`, `30`, `0`, `0`, `0`, `0`, `188.237.214.161`);
INSERT INTO `sms_partners_two` VALUES(`2118`, `0`, `30`, `0`, `0`, `0`, `0`, `46.229.141.156`);
INSERT INTO `sms_partners_two` VALUES(`2119`, `0`, `30`, `0`, `0`, `0`, `0`, `78.85.17.131`);
INSERT INTO `sms_partners_two` VALUES(`2120`, `0`, `30`, `0`, `0`, `0`, `0`, `194.187.217.13`);
INSERT INTO `sms_partners_two` VALUES(`2121`, `0`, `30`, `0`, `0`, `0`, `0`, `176.214.36.22`);
INSERT INTO `sms_partners_two` VALUES(`2122`, `0`, `30`, `0`, `0`, `0`, `0`, `95.55.144.32`);
INSERT INTO `sms_partners_two` VALUES(`2123`, `0`, `30`, `0`, `0`, `0`, `0`, `92.242.113.60`);
INSERT INTO `sms_partners_two` VALUES(`2124`, `0`, `30`, `0`, `0`, `0`, `0`, `141.136.85.33`);
INSERT INTO `sms_partners_two` VALUES(`2125`, `0`, `30`, `0`, `0`, `0`, `0`, `188.134.46.212`);
INSERT INTO `sms_partners_two` VALUES(`2126`, `0`, `30`, `0`, `0`, `0`, `0`, `93.120.232.139`);
INSERT INTO `sms_partners_two` VALUES(`2127`, `0`, `30`, `0`, `0`, `0`, `0`, `176.195.79.211`);
INSERT INTO `sms_partners_two` VALUES(`2128`, `0`, `30`, `0`, `0`, `0`, `0`, `95.137.228.34`);
INSERT INTO `sms_partners_two` VALUES(`2129`, `0`, `30`, `0`, `0`, `0`, `0`, `77.235.106.163`);
INSERT INTO `sms_partners_two` VALUES(`2130`, `0`, `30`, `0`, `0`, `0`, `0`, `93.183.249.153`);
INSERT INTO `sms_partners_two` VALUES(`2131`, `0`, `30`, `0`, `0`, `0`, `0`, `178.168.165.94`);
INSERT INTO `sms_partners_two` VALUES(`2132`, `0`, `30`, `0`, `0`, `0`, `0`, `92.100.171.126`);
INSERT INTO `sms_partners_two` VALUES(`2133`, `0`, `5`, `0`, `0`, `0`, `0`, `66.249.71.249`);
INSERT INTO `sms_partners_two` VALUES(`2134`, `0`, `0`, `0`, `0`, `0`, `0`, `91.203.67.20`);
INSERT INTO `sms_partners_two` VALUES(`2136`, `0`, `5`, `0`, `0`, `0`, `0`, `89.106.198.110`);
INSERT INTO `sms_partners_two` VALUES(`2137`, `0`, `0`, `0`, `0`, `0`, `0`, `89.106.198.110`);
INSERT INTO `sms_partners_two` VALUES(`2138`, `0`, `5`, `0`, `0`, `0`, `0`, `89.106.198.161`);
INSERT INTO `sms_partners_two` VALUES(`2139`, `0`, `0`, `0`, `0`, `0`, `0`, `89.106.198.161`);
INSERT INTO `sms_partners_two` VALUES(`2140`, `0`, `5`, `0`, `0`, `0`, `0`, `95.83.164.12`);
INSERT INTO `sms_partners_two` VALUES(`2141`, `0`, `0`, `0`, `0`, `0`, `0`, `95.83.164.12`);
INSERT INTO `sms_partners_two` VALUES(`2142`, `0`, `5`, `0`, `0`, `0`, `0`, `91.203.67.24`);
INSERT INTO `sms_partners_two` VALUES(`2143`, `0`, `0`, `0`, `0`, `0`, `0`, `91.203.67.24`);
INSERT INTO `sms_partners_two` VALUES(`2144`, `0`, `30`, `0`, `0`, `0`, `0`, `89.110.8.157`);
INSERT INTO `sms_partners_two` VALUES(`2145`, `0`, `0`, `0`, `0`, `0`, `0`, `89.110.8.157`);
INSERT INTO `sms_partners_two` VALUES(`2146`, `0`, `5`, `0`, `0`, `0`, `0`, `95.106.88.157`);
INSERT INTO `sms_partners_two` VALUES(`2147`, `0`, `0`, `0`, `0`, `0`, `0`, `95.106.88.157`);
INSERT INTO `sms_partners_two` VALUES(`2148`, `0`, `5`, `0`, `0`, `0`, `0`, `176.96.229.93`);
INSERT INTO `sms_partners_two` VALUES(`2149`, `0`, `0`, `0`, `0`, `0`, `0`, `176.96.229.93`);
INSERT INTO `sms_partners_two` VALUES(`2150`, `0`, `30`, `0`, `0`, `0`, `0`, `109.188.215.16`);
INSERT INTO `sms_partners_two` VALUES(`2151`, `0`, `0`, `0`, `0`, `0`, `0`, `109.188.215.16`);
INSERT INTO `sms_partners_two` VALUES(`2152`, `0`, `5`, `0`, `0`, `0`, `0`, `89.106.198.81`);
INSERT INTO `sms_partners_two` VALUES(`2153`, `0`, `0`, `0`, `0`, `0`, `0`, `89.106.198.81`);
INSERT INTO `sms_partners_two` VALUES(`2154`, `0`, `5`, `0`, `0`, `0`, `0`, `109.94.176.254`);
INSERT INTO `sms_partners_two` VALUES(`2155`, `0`, `0`, `0`, `0`, `0`, `0`, `109.94.176.254`);
INSERT INTO `sms_partners_two` VALUES(`2156`, `0`, `5`, `0`, `0`, `0`, `0`, `95.83.142.101`);
INSERT INTO `sms_partners_two` VALUES(`2157`, `0`, `0`, `0`, `0`, `0`, `0`, `95.83.142.101`);
INSERT INTO `sms_partners_two` VALUES(`2158`, `0`, `5`, `0`, `0`, `0`, `0`, `176.212.178.71`);
INSERT INTO `sms_partners_two` VALUES(`2159`, `0`, `0`, `0`, `0`, `0`, `0`, `176.212.178.71`);
INSERT INTO `sms_partners_two` VALUES(`2160`, `0`, `5`, `0`, `0`, `0`, `0`, `95.83.142.194`);
INSERT INTO `sms_partners_two` VALUES(`2161`, `0`, `0`, `0`, `0`, `0`, `0`, `95.83.142.194`);
INSERT INTO `sms_partners_two` VALUES(`2162`, `0`, `5`, `0`, `0`, `0`, `0`, `178.187.254.147`);
INSERT INTO `sms_partners_two` VALUES(`2163`, `0`, `0`, `0`, `0`, `0`, `0`, `178.187.254.147`);
INSERT INTO `sms_partners_two` VALUES(`2164`, `0`, `5`, `0`, `0`, `0`, `0`, `176.96.228.149`);
INSERT INTO `sms_partners_two` VALUES(`2165`, `0`, `0`, `0`, `0`, `0`, `0`, `176.96.228.149`);
INSERT INTO `sms_partners_two` VALUES(`2166`, `0`, `5`, `0`, `0`, `0`, `0`, `176.212.161.127`);
INSERT INTO `sms_partners_two` VALUES(`2167`, `0`, `0`, `0`, `0`, `0`, `0`, `176.212.161.127`);
INSERT INTO `sms_partners_two` VALUES(`2168`, `0`, `5`, `0`, `0`, `0`, `0`, `176.96.249.150`);
INSERT INTO `sms_partners_two` VALUES(`2169`, `0`, `0`, `0`, `0`, `0`, `0`, `176.96.249.150`);
INSERT INTO `sms_partners_two` VALUES(`2170`, `0`, `5`, `0`, `0`, `0`, `0`, `89.106.198.189`);
INSERT INTO `sms_partners_two` VALUES(`2171`, `0`, `0`, `0`, `0`, `0`, `0`, `89.106.198.189`);
INSERT INTO `sms_partners_two` VALUES(`2172`, `0`, `5`, `0`, `0`, `0`, `0`, `217.118.83.231`);
INSERT INTO `sms_partners_two` VALUES(`2173`, `0`, `0`, `0`, `0`, `0`, `0`, `217.118.83.231`);
INSERT INTO `sms_partners_two` VALUES(`2174`, `0`, `30`, `0`, `0`, `0`, `0`, `66.249.73.137`);
INSERT INTO `sms_partners_two` VALUES(`2175`, `46`, `5`, `0`, `20`, `10`, `0`, `95.83.137.225`);
INSERT INTO `sms_partners_two` VALUES(`2176`, `0`, `0`, `0`, `0`, `0`, `0`, `95.83.137.225`);
INSERT INTO `sms_partners_two` VALUES(`2177`, `0`, `5`, `0`, `0`, `0`, `0`, `66.249.72.45`);
INSERT INTO `sms_partners_two` VALUES(`2178`, `0`, `5`, `0`, `0`, `0`, `0`, `66.249.66.235`);
INSERT INTO `sms_partners_two` VALUES(`2179`, `0`, `5`, `0`, `0`, `0`, `0`, `95.83.132.233`);
INSERT INTO `sms_partners_two` VALUES(`2180`, `0`, `0`, `0`, `0`, `0`, `0`, `95.83.132.233`);
INSERT INTO `sms_partners_two` VALUES(`2181`, `0`, `5`, `0`, `0`, `0`, `0`, `176.96.228.215`);
INSERT INTO `sms_partners_two` VALUES(`2182`, `0`, `0`, `0`, `0`, `0`, `0`, `176.96.228.215`);
INSERT INTO `sms_partners_two` VALUES(`2183`, `0`, `5`, `0`, `0`, `0`, `0`, `176.96.251.20`);
INSERT INTO `sms_partners_two` VALUES(`2184`, `0`, `0`, `0`, `0`, `0`, `0`, `176.96.251.20`);
INSERT INTO `sms_partners_two` VALUES(`2185`, `0`, `5`, `0`, `0`, `0`, `0`, `66.249.68.146`);
INSERT INTO `sms_partners_two` VALUES(`2186`, `0`, `5`, `0`, `0`, `0`, `0`, `176.96.224.113`);
INSERT INTO `sms_partners_two` VALUES(`2187`, `0`, `0`, `0`, `0`, `0`, `0`, `176.96.224.113`);
INSERT INTO `sms_partners_two` VALUES(`2188`, `0`, `5`, `0`, `0`, `0`, `0`, `94.231.127.229`);
INSERT INTO `sms_partners_two` VALUES(`2189`, `0`, `5`, `0`, `0`, `0`, `0`, `66.249.72.103`);
INSERT INTO `sms_partners_two` VALUES(`2190`, `51`, `5`, `0`, `20`, `10`, `0`, `95.106.92.224`);
INSERT INTO `sms_partners_two` VALUES(`2191`, `0`, `0`, `0`, `0`, `0`, `0`, `95.106.92.224`);
INSERT INTO `sms_partners_two` VALUES(`2192`, `0`, `5`, `0`, `0`, `0`, `0`, `80.239.242.146`);
INSERT INTO `sms_partners_two` VALUES(`2193`, `0`, `0`, `0`, `0`, `0`, `0`, `80.239.242.146`);
INSERT INTO `sms_partners_two` VALUES(`2194`, `0`, `5`, `0`, `0`, `0`, `0`, `95.83.139.208`);
INSERT INTO `sms_partners_two` VALUES(`2195`, `0`, `0`, `0`, `0`, `0`, `0`, `95.83.139.208`);
INSERT INTO `sms_partners_two` VALUES(`2196`, `0`, `5`, `0`, `0`, `0`, `0`, `91.77.21.161`);
INSERT INTO `sms_partners_two` VALUES(`2197`, `0`, `0`, `0`, `0`, `0`, `0`, `91.77.21.161`);
INSERT INTO `sms_partners_two` VALUES(`2198`, `0`, `5`, `0`, `0`, `0`, `0`, `176.213.194.82`);
INSERT INTO `sms_partners_two` VALUES(`2199`, `0`, `0`, `0`, `0`, `0`, `0`, `176.213.194.82`);
INSERT INTO `sms_partners_two` VALUES(`2200`, `0`, `5`, `0`, `0`, `0`, `0`, `176.241.224.246`);
INSERT INTO `sms_partners_two` VALUES(`2201`, `0`, `0`, `0`, `0`, `0`, `0`, `176.241.224.246`);
INSERT INTO `sms_partners_two` VALUES(`2202`, `0`, `5`, `0`, `0`, `0`, `0`, `176.96.229.33`);
INSERT INTO `sms_partners_two` VALUES(`2203`, `0`, `0`, `0`, `0`, `0`, `0`, `176.96.229.33`);
INSERT INTO `sms_partners_two` VALUES(`2204`, `0`, `5`, `0`, `0`, `0`, `0`, `95.83.189.198`);
INSERT INTO `sms_partners_two` VALUES(`2205`, `0`, `0`, `0`, `0`, `0`, `0`, `95.83.189.198`);
INSERT INTO `sms_partners_two` VALUES(`2206`, `0`, `5`, `0`, `0`, `0`, `0`, `176.96.224.35`);
INSERT INTO `sms_partners_two` VALUES(`2207`, `0`, `0`, `0`, `0`, `0`, `0`, `176.96.224.35`);
INSERT INTO `sms_partners_two` VALUES(`2208`, `0`, `5`, `0`, `0`, `0`, `0`, `83.149.47.130`);
INSERT INTO `sms_partners_two` VALUES(`2209`, `0`, `0`, `0`, `0`, `0`, `0`, `83.149.47.130`);
INSERT INTO `sms_partners_two` VALUES(`2210`, `0`, `30`, `0`, `0`, `0`, `0`, `141.170.226.58`);
INSERT INTO `sms_partners_two` VALUES(`2211`, `0`, `0`, `0`, `0`, `0`, `0`, `141.170.226.58`);
INSERT INTO `sms_partners_two` VALUES(`2212`, `0`, `5`, `0`, `0`, `0`, `0`, `89.106.197.27`);
INSERT INTO `sms_partners_two` VALUES(`2213`, `0`, `0`, `0`, `0`, `0`, `0`, `89.106.197.27`);
INSERT INTO `sms_partners_two` VALUES(`2214`, `0`, `5`, `0`, `0`, `0`, `0`, `176.96.244.105`);
INSERT INTO `sms_partners_two` VALUES(`2215`, `0`, `0`, `0`, `0`, `0`, `0`, `176.96.244.105`);
INSERT INTO `sms_partners_two` VALUES(`2216`, `0`, `5`, `0`, `0`, `0`, `0`, `95.106.1.47`);
INSERT INTO `sms_partners_two` VALUES(`2217`, `0`, `0`, `0`, `0`, `0`, `0`, `95.106.1.47`);
INSERT INTO `sms_partners_two` VALUES(`2218`, `0`, `5`, `0`, `0`, `0`, `0`, `213.87.132.252`);
INSERT INTO `sms_partners_two` VALUES(`2219`, `0`, `0`, `0`, `0`, `0`, `0`, `213.87.132.252`);
INSERT INTO `sms_partners_two` VALUES(`2220`, `0`, `5`, `0`, `0`, `0`, `0`, `31.44.53.175`);
INSERT INTO `sms_partners_two` VALUES(`2221`, `0`, `0`, `0`, `0`, `0`, `0`, `31.44.53.175`);
INSERT INTO `sms_partners_two` VALUES(`2222`, `0`, `30`, `0`, `0`, `0`, `0`, `92.100.182.182`);
INSERT INTO `sms_partners_two` VALUES(`2223`, `0`, `0`, `0`, `0`, `0`, `0`, `92.100.182.182`);
INSERT INTO `sms_partners_two` VALUES(`2224`, `0`, `5`, `0`, `0`, `0`, `0`, `176.96.246.77`);
INSERT INTO `sms_partners_two` VALUES(`2225`, `0`, `0`, `0`, `0`, `0`, `0`, `176.96.246.77`);
INSERT INTO `sms_partners_two` VALUES(`2226`, `0`, `5`, `0`, `0`, `0`, `0`, `91.203.66.66`);
INSERT INTO `sms_partners_two` VALUES(`2227`, `0`, `0`, `0`, `0`, `0`, `0`, `91.203.66.66`);
INSERT INTO `sms_partners_two` VALUES(`2228`, `0`, `5`, `0`, `0`, `0`, `0`, `95.83.173.81`);
INSERT INTO `sms_partners_two` VALUES(`2229`, `0`, `0`, `0`, `0`, `0`, `0`, `95.83.173.81`);
INSERT INTO `sms_partners_two` VALUES(`2230`, `0`, `5`, `0`, `0`, `0`, `0`, `93.189.11.246`);
INSERT INTO `sms_partners_two` VALUES(`2231`, `0`, `0`, `0`, `0`, `0`, `0`, `93.189.11.246`);
INSERT INTO `sms_partners_two` VALUES(`2232`, `56`, `5`, `0`, `20`, `10`, `0`, `91.203.67.162`);
INSERT INTO `sms_partners_two` VALUES(`2233`, `0`, `0`, `0`, `0`, `0`, `0`, `91.203.67.162`);
INSERT INTO `sms_partners_two` VALUES(`2234`, `0`, `5`, `0`, `0`, `0`, `0`, `91.203.67.162`);
INSERT INTO `sms_partners_two` VALUES(`2235`, `0`, `5`, `0`, `0`, `0`, `0`, `83.149.45.35`);
INSERT INTO `sms_partners_two` VALUES(`2236`, `0`, `0`, `0`, `0`, `0`, `0`, `83.149.45.35`);
INSERT INTO `sms_partners_two` VALUES(`2237`, `0`, `5`, `0`, `0`, `0`, `0`, `95.83.172.25`);
INSERT INTO `sms_partners_two` VALUES(`2238`, `0`, `0`, `0`, `0`, `0`, `0`, `95.83.172.25`);
INSERT INTO `sms_partners_two` VALUES(`2239`, `0`, `5`, `0`, `0`, `0`, `0`, `95.83.190.183`);
INSERT INTO `sms_partners_two` VALUES(`2240`, `0`, `0`, `0`, `0`, `0`, `0`, `95.83.190.183`);
INSERT INTO `sms_partners_two` VALUES(`2241`, `0`, `5`, `0`, `0`, `0`, `0`, `82.145.208.44`);
INSERT INTO `sms_partners_two` VALUES(`2242`, `0`, `0`, `0`, `0`, `0`, `0`, `82.145.208.44`);
INSERT INTO `sms_partners_two` VALUES(`2243`, `0`, `5`, `0`, `0`, `0`, `0`, `95.83.178.165`);
INSERT INTO `sms_partners_two` VALUES(`2244`, `0`, `0`, `0`, `0`, `0`, `0`, `95.83.178.165`);
INSERT INTO `sms_partners_two` VALUES(`2245`, `0`, `5`, `0`, `0`, `0`, `0`, `176.96.228.174`);
INSERT INTO `sms_partners_two` VALUES(`2246`, `0`, `0`, `0`, `0`, `0`, `0`, `176.96.228.174`);
INSERT INTO `sms_partners_two` VALUES(`2247`, `0`, `5`, `0`, `0`, `0`, `0`, `46.229.140.142`);
INSERT INTO `sms_partners_two` VALUES(`2248`, `0`, `0`, `0`, `0`, `0`, `0`, `46.229.140.142`);
INSERT INTO `sms_partners_two` VALUES(`2249`, `0`, `5`, `0`, `0`, `0`, `0`, `89.106.197.90`);
INSERT INTO `sms_partners_two` VALUES(`2250`, `0`, `0`, `0`, `0`, `0`, `0`, `89.106.197.90`);
INSERT INTO `sms_partners_two` VALUES(`2251`, `0`, `30`, `0`, `0`, `0`, `0`, `217.118.79.36`);
INSERT INTO `sms_partners_two` VALUES(`2252`, `0`, `0`, `0`, `0`, `0`, `0`, `217.118.79.36`);
INSERT INTO `sms_partners_two` VALUES(`2253`, `0`, `5`, `0`, `0`, `0`, `0`, `178.127.198.8`);
INSERT INTO `sms_partners_two` VALUES(`2254`, `0`, `0`, `0`, `0`, `0`, `0`, `178.127.198.8`);
INSERT INTO `sms_partners_two` VALUES(`2255`, `0`, `5`, `0`, `0`, `0`, `0`, `213.87.130.77`);
INSERT INTO `sms_partners_two` VALUES(`2256`, `0`, `0`, `0`, `0`, `0`, `0`, `213.87.130.77`);
INSERT INTO `sms_partners_two` VALUES(`2257`, `0`, `5`, `0`, `0`, `0`, `0`, `87.240.182.142`);
INSERT INTO `sms_partners_two` VALUES(`2258`, `0`, `5`, `0`, `0`, `0`, `0`, `176.212.184.144`);
INSERT INTO `sms_partners_two` VALUES(`2259`, `0`, `0`, `0`, `0`, `0`, `0`, `176.212.184.144`);
INSERT INTO `sms_partners_two` VALUES(`2260`, `0`, `5`, `0`, `0`, `0`, `0`, `176.104.194.246`);
INSERT INTO `sms_partners_two` VALUES(`2261`, `0`, `0`, `0`, `0`, `0`, `0`, `176.104.194.246`);
INSERT INTO `sms_partners_two` VALUES(`2262`, `0`, `5`, `0`, `0`, `0`, `0`, `176.96.236.232`);
INSERT INTO `sms_partners_two` VALUES(`2263`, `0`, `0`, `0`, `0`, `0`, `0`, `176.96.236.232`);
INSERT INTO `sms_partners_two` VALUES(`2264`, `0`, `5`, `0`, `0`, `0`, `0`, `95.83.129.8`);
INSERT INTO `sms_partners_two` VALUES(`2265`, `0`, `0`, `0`, `0`, `0`, `0`, `95.83.129.8`);
INSERT INTO `sms_partners_two` VALUES(`2266`, `0`, `5`, `0`, `0`, `0`, `0`, `217.212.230.154`);
INSERT INTO `sms_partners_two` VALUES(`2267`, `0`, `0`, `0`, `0`, `0`, `0`, `217.212.230.154`);
INSERT INTO `sms_partners_two` VALUES(`2268`, `65`, `5`, `0`, `20`, `10`, `0`, `95.221.28.73`);
INSERT INTO `sms_partners_two` VALUES(`2269`, `0`, `0`, `0`, `0`, `0`, `0`, `95.221.28.73`);
INSERT INTO `sms_partners_two` VALUES(`2270`, `0`, `5`, `0`, `0`, `0`, `0`, `95.221.28.73`);
INSERT INTO `sms_partners_two` VALUES(`2271`, `66`, `5`, `0`, `20`, `10`, `0`, `176.96.224.62`);
INSERT INTO `sms_partners_two` VALUES(`2272`, `0`, `0`, `0`, `0`, `0`, `0`, `176.96.224.62`);
INSERT INTO `sms_partners_two` VALUES(`2273`, `0`, `5`, `0`, `0`, `0`, `0`, `176.96.224.62`);
INSERT INTO `sms_partners_two` VALUES(`2274`, `0`, `70`, `0`, `0`, `0`, `0`, `69.171.237.12`);
INSERT INTO `sms_partners_two` VALUES(`2275`, `0`, `70`, `0`, `0`, `0`, `0`, `87.240.182.173`);
INSERT INTO `sms_partners_two` VALUES(`2276`, `0`, `70`, `0`, `0`, `0`, `0`, `65.52.1.11`);
INSERT INTO `sms_partners_two` VALUES(`2277`, `0`, `70`, `0`, `0`, `0`, `0`, `217.20.145.17`);
CREATE TABLE `sms_statics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `template` text NOT NULL,
  `url` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `metatitle` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `metadescr` varchar(200) NOT NULL,
  `metakeys` text NOT NULL,
  `author` varchar(255) NOT NULL,
  `views` int(11) NOT NULL DEFAULT '0',
  `time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=latin1

INSERT INTO `sms_statics` VALUES(`15`, `Тарифы`, `<p style=\"text-align: center;\">\n	<a href=\"http://world-sms.ru/tarifssms.html\"><img alt=\"\" class=\"button\" src=\"/upload/Zeni_SMS_rassilka.png\" style=\"width: 231px; height: 200px;\" /></a> &nbsp;&nbsp; &nbsp; &nbsp;&nbsp; &nbsp; <a href=\"http://world-sms.ru/tarifsbilling.html\"><img alt=\"\" class=\"button\" src=\"/upload/Zeni_SMS_billing.png\" style=\"width: 190px; height: 200px;\" /></a>&nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; <a href=\"http://world-sms.ru/tarifszip.html\"><img alt=\"\" class=\"button\" src=\"/upload/Zeni_Zip_arhiv.png\" style=\"width: 228px; height: 200px;\" /></a></p>`, `tarifs`, `Тарифы`, ``, `Тарифы`, ``, ``, `Сергей`, `524`, `1353733107`);
INSERT INTO `sms_statics` VALUES(`18`, `О нас`, `<p>\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">&nbsp; &nbsp; &nbsp;В XX веке передовыми средствами информации были газеты, телевидение и почта. Затем стала популярна электронная почта, но из-за большого объема рассылаемого спама теперь многие не обращают внимание на большую часть приходящих писем. В такой ситуации делать рассылки по электронной почтой становится все менее актуальным.</span></span></p>\n<p>\n	&nbsp;</p>\n<p>\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">&nbsp; &nbsp; За последние 20 лет мобильные телефоны появились практически<strong> у каждого</strong> человека и стали незаменимым атрибутом жизни. Поэтому в XXI веке SMS рассылки становятся самым лучшим средством донесения информации до клиентов, партнёров и сотрудников <strong>всех возрастных категорий</strong>. Каждое SMS сообщение приходящие на мобильный телефон читается его владельцем. Этот факт свидетельствует о том, что sms рассылка очень эффективна. Поэтому многие фирмы начинают применять их в рекламной отрасли и деловой среде. Но массовые рассылки с мобильного телефона через сотового оператора делать неудобно и дорого, поэтому мы организовали этот сервис для Вас. Благодаря интуитивно понятному WEB интерфейсу и удобному для использования виртуальному личному кабинету делать SMS рассылки стали проще и удобнее. Мы позволяем Вам стереть грань между телефоном и глобальной сетью интернет. Наш сервис это еще и удобная система контроля, поскольку наблюдать за ходом рассылки Вы можете в режиме реального времени.</span></span></p>`, `about`, `О нас`, ``, `описание нашего сервиса`, ``, ``, `Сергей`, `286`, `1353732962`);
INSERT INTO `sms_statics` VALUES(`19`, `Партнерам`, `<pre align=\"center\">\n</pre>\n<h2 align=\"center\">\n	<span style=\"font-size:22px;\"><span style=\"font-family:times new roman,times,serif;\"><strong>Партнерская программа</strong></span></span></h2>\n<p>\n	<span style=\"font-family:times new roman,times,serif;\"><span style=\"font-size:18px;\">Участие в партнёрской программе даёт возможность получать постоянные вознаграждения, рекомендуя услуги компании и, таким образом, привлекая новых клиентов.</span></span></p>\n<p>\n	<span style=\"font-family:times new roman,times,serif;\"><span style=\"font-size:18px;\">Особенность нашей партнерской программы состоит в том, что не нужно ждать пока на счету накопится минимальная сумма, которую возможно вывести со счета. Мы производим автоматически вывод любого количества денег 1 раз в месяц с 1 по 5 число следующего месяца.</span></span></p>\n<p>\n	<span style=\"font-family:times new roman,times,serif;\"><span style=\"font-size:18px;\">Для того чтобы принять участие в партнерской программе необходимо при регистрации поставить галочку в графе &laquo;Я принимаю участие в партнерской программе&raquo; и указать номер WMR-кошелька на который будут перечисляться деньги (WMR-кошелек можно зарегистрировать перейдя по ссылке http://start.webmoney.ru/). </span></span></p>\n<h2 align=\"center\">\n	<span style=\"font-size:22px;\"><span style=\"font-family:times new roman,times,serif;\"><strong>Что такое партнерская программа?</strong></span></span></h2>\n<p>\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">Смысл партнёрских программ &ndash; это привлечение клиентов от сторонних сайтов. Вы становитесь нашим партнером, продвигаете сервис и получаете <strong>%%</strong> со всех потраченных средств привлеченного клиента на протяжение <strong>всего срока</strong> работы. Например, в вы заходите на наш сайт, регистрируетесь в качестве партнёра и размещаете партнёрскую ссылку у себя на сайте или в любом месте в Интернете. Если в дальнейшем покупатель, заходя на ваш сайт, переходит по партнёрской ссылке и затем покупает любое колличество SMS сообщений, то Вам начисляется процент от портраченных им денег на покупку SMS.</span></span></p>\n<p>\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">Вам достаточно зарегистрироваться в сервисе и разместить индивидуальную партнерскую ссылку у себя на сайте или в любом месте в интернете, либо выдавать индивидуальную партнерскую ссылку заинтересованным клиентам другими средствами. Получить индивидуальную партнерскую ссылку Вы можете в <a href=\"http://world-sms.ru/partners\">личном кабинете</a>, там же Вы будете видеть подробную статистику по количеству привлеченных клиентов, а также по начислениям. Если по Вашей ссылке зарегистрировался человек, то информация о нем автоматически появляется у Вас в статистике и сохраняется на протяжении всего времени.</span></span></p>\n<p>\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">От Вас требуется только привлекать новых клиентов, остальное обеспечим мы. Мы предлагаем Вам возможность зарабатывать вместе с нами!</span></span></p>\n<p>\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\"><strong>Мы выплачиваем любую сумму</strong> по нашей партнерской программе, накопленную за расчетный период (календарный месяц). Выплаты Вашего заработка производятся на кошельки <strong>WebMoney (</strong>WMR-кошелек).</span></span></p>\n<h2 align=\"center\">\n	<span style=\"font-size:22px;\"><span style=\"font-family:times new roman,times,serif;\"><strong>Выгодная партнерская программа!</strong></span></span></h2>\n<p>\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">Принимая участие в партнерской программе Вы будете получать <strong>%%</strong> от всех потраченных средств привлеченных Вами клиентов на протяжение <strong>всего срока</strong> работы.</span></span></p>\n<h2 align=\"center\">\n	<span style=\"font-size:22px;\"><span style=\"font-family:times new roman,times,serif;\"><strong>Структура выплат по партнерской программе</strong></span></span></h2>\n<p>\n	<span style=\"font-size: 18px;\"><span style=\"font-family: times new roman,times,serif;\">1. С каждого зарегистрированного партнера <strong>первого уровня (</strong><strong>I</strong><strong>)</strong> вы раз в месяц получаете по 20% от </span></span><span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">потраченных им денег на приобретение SMS сообщений.</span></span></p>\n<p>\n	<span style=\"font-family:times new roman,times,serif;\"><img alt=\"\" src=\"/upload/img.png\" style=\"width: 234px; height: 240px\" /></span></p>\n<p style=\"text-align: center\">\n	&nbsp;</p>\n<p>\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">2. Привлеченные партнерами первого уровня клиенты для Вас становятся партнерами <strong>второго уровня (</strong><strong>II</strong><strong>),</strong> с которыми вы возможно даже и не знакомы. Раз в месяц Вы получаете по 10% от потраченных ими денег на приобретение SMS сообщений. </span></span></p>\n<p>\n	<span style=\"font-family:times new roman,times,serif;\"><img alt=\"\" src=\"/upload/img_02.png\" style=\"width: 307px; height: 230px\" /></span></p>\n<h2 style=\"text-align: center;\">\n	<span style=\"font-family:times new roman,times,serif;\"><span style=\"font-size:26px;\"><strong>Можно сидеть и думать о деньгах, а можно начать зарабатывать прямо сейчас!</strong></span></span></h2>\n<p>\n	&nbsp;</p>`, `partners`, `Партнерская программа`, `world sms, партнерской программе, смс рассылка, партнерскую ссылку, sms сообщений, партнерская программа, приобретение sms, индивидуальную партне�`, `Раздел для партнеров`, ``, ``, `Владимир`, `838`, `1354463259`);
INSERT INTO `sms_statics` VALUES(`20`, `Правила сервиса`, `<p align=\"center\">\n	<span style=\"font-family:times new roman,times,serif;\"><span style=\"font-size:24px;\"><strong>Предложение (Публичная оферта)</strong></span></span></p>\n<p align=\"center\">\n	<span style=\"font-family:times new roman,times,serif;\"><span style=\"font-size:24px;\"><strong>на оказание услуг по рассылке </strong><strong>SMS сообщений</strong></span></span></p>\n<p align=\"center\">\n	<span style=\"font-family:times new roman,times,serif;\"><span style=\"font-size:24px;\"><strong>1. Общие положения</strong></span></span></p>\n<p style=\"margin-left:35.45pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">1.1. Данный документ является официальным предложением (публичной офертой именуемой далее &laquo;Договор&raquo;) (именуемой далее &laquo;<strong>Исполнитель</strong>&raquo;) и содержит все существенные условия предоставления услуг по рассылке SMS сообщений.</span></span></p>\n<p style=\"margin-left:35.4pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">1.2. В соответствии с пунктом 2 статьи 437 Гражданского Кодекса Российской Федерации (ГК РФ) в случае принятия изложенных ниже условий и оплаты услуг юридическое или физическое лицо, производящее акцепт этой оферты становится <strong>Заказчиком </strong>(в соответствии с пунктом 3 статьи 438 ГК РФ акцепт оферты равносилен заключению договора на условиях, изложенных в оферте).</span></span></p>\n<p style=\"margin-left:35.4pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">1.3. В связи с вышеизложенным, внимательно прочитайте текст данной публичной оферты и если Вы не согласны с каким-либо пунктом оферты, ИСПОЛНИТЕЛЬ предлагает Вам отказаться от использования услуг.</span></span></p>\n<p style=\"margin-left:35.4pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">1.4. <strong>Заказчик</strong>, решивший принять участие в партнерской программе и указавший номер кошелька WebMoney становится партнером и имеет право получать предусмотренное вознаграждение.</span></span></p>\n<p align=\"center\">\n	<span style=\"font-size:22px;\"><span style=\"font-family:times new roman,times,serif;\"><strong>2. Предмет договора</strong></span></span></p>\n<p style=\"margin-left: 40px\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">2.1. <strong>Исполнитель</strong> обязуется предоставить <strong>Заказчику</strong> специальную страницу доступа в сервисе &laquo;WORLD SMS&raquo;, именуемую по тексту договора<strong> &laquo;Личный кабинет</strong>&raquo;, позволяющий в любое удобное для <strong>Заказчика</strong> время производить рассылки SMS-сообщений через сеть Интернет на мобильные телефоны своих клиентов или по клиентской базе <strong>Исполнителя</strong>.</span></span></p>\n<p style=\"margin-left:35.4pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">2.2. <strong>Заказчик </strong>обязуется оплатить оказанные услуги.</span></span></p>\n<p style=\"margin-left:35.4pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">2.3. Предметом настоящего Договора является предоставление <strong>Заказчику</strong> услуг в соответствии с Правилами предоставления Услуг (Приложение № 1 к настоящему Договору) и действующими Тарифами <strong>Исполнителя</strong>, согласованными Сторонами в Приложении № 2 к настоящему Договору, а также условиями использования услуги динамической цифробуквенной смены адреса отправителя (Приложение № 3), в случае эксплуатации ее <strong>Заказчиком</strong>.</span></span></p>\n<p align=\"center\">\n	<span style=\"font-size:22px;\"><span style=\"font-family:times new roman,times,serif;\"><strong>3. Срок действия договора</strong></span></span></p>\n<p style=\"margin-left:36.0pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">3.1. Срок действия данного Договора начинается с момента завершения регистрации <strong>Заказчика</strong> на сайте и заканчивается в момент расторжения Договора.</span></span></p>\n<p style=\"margin-left:35.4pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">3.2. Первоначальный срок действия Договора составляет 12 (двенадцать) месяцев.</span></span></p>\n<p style=\"margin-left:35.4pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">3.3. Настоящий договор автоматически продлевается на такой же срок, если ни одна из сторон не заявит о его расторжении.</span></span></p>\n<p style=\"margin-left:35.4pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">3.4. <strong>Исполнитель</strong> имеет право расторгнуть отношения с <strong>Заказчиком</strong> в случае нарушения последним любого из пунктов настоящего Договора.</span></span></p>\n<p align=\"center\">\n	<span style=\"font-size:22px;\"><span style=\"font-family:times new roman,times,serif;\"><strong>4. Права и обязанности Сторон</strong></span></span></p>\n<p style=\"margin-left: 80px\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">4.1.<strong> Исполнитель</strong> обязан:</span></span></p>\n<p style=\"margin-left: 40px\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">4.1.1. Предоставить <strong>Заказчику</strong> возможность самостоятельно осуществлять отправку SMS-сообщений от любого имени отправителя через сервис Сайта.</span></span></p>\n<p style=\"margin-left: 40px\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">4.1.2. Технически обеспечивать круглосуточную, бесперебойную работу сервиса.</span></span></p>\n<p style=\"margin-left: 40px\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">4.1.3. Консультировать <strong>Заказчика</strong> по электронной почте <a href=\"mailto:support@world-sms\">support@world-sms</a>.ru, но не регламентирует время специалистов поддержки на ответ.</span></span></p>\n<p style=\"margin-left:35.4pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">4.1.4. Уведомить <strong>Заказчика</strong> о проведении профилактических работ на сервере за 1 день до начала работ.</span></span></p>\n<p style=\"margin-left: 80px\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">4.2. <strong>Заказчик</strong> обязуется:</span></span></p>\n<p style=\"margin-left:36.0pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">4.2.1. Производить предоплату услуг до момента их исполнения. Оплата производится на основании цен, выставляемых <strong>Исполнителем</strong> в соответствующем разделе сайта.</span></span></p>\n<p style=\"margin-left:35.4pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">4.2.2. Не рассылать спам и прочие сообщения, могущих привести к нарушению работоспособности оборудования <strong>Исполнителя</strong>, для массовой передачи сообщений оскорбительного или клеветнического характера или сообщений, разжигающих национальную, расовую или религиозную рознь и другие, противоречащие Законодательству РФ</span></span></p>\n<p style=\"margin-left:35.4pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">4.2.3. В обязательном порядке получить от адресата (непосредственно или через клиента <strong>Заказчика</strong>), на телефон которого планируется отправка SMS-сообщений с информацией <strong>Заказчика</strong>, согласие на получение таких сообщений в такой форме, которая может быть предъявлена Оператору в случае необходимости в качестве безоговорочного доказательства добровольности адресата на получение SMS-сообщений.</span></span></p>\n<p style=\"margin-left:35.4pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">4.2.4. Самостоятельно знакомиться на Сайте с информацией об Услугах, тарифах на них и условиях обслуживания <strong>Заказчика</strong>.</span></span></p>\n<p style=\"margin-left:35.4pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">4.2.5. Строго соблюдать Правила предоставления Услуг (Приложение № 1).</span></span></p>\n<p style=\"margin-left:35.4pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">4.2.6. Информировать в письменной форме <strong>Исполнителя</strong> об изменениях адреса, банковских и иных реквизитов при переименовании организации.</span></span></p>\n<p style=\"margin-left:35.45pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">4.3.<strong> Исполнитель</strong> имеет право:</span></span></p>\n<p style=\"margin-left:35.4pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">4.3.1. Отказать <strong>Заказчику</strong> в оказании услуг и немедленно расторгнуть в одностороннем порядке Договор, в случае нарушения им п.п. 4.2.2. При этом сумма, оплаченная <strong>Заказчиком</strong>, не возвращается.</span></span></p>\n<p style=\"margin-left:35.4pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">4.3.2. Прекратить отношения с <strong>Заказчиком</strong> по настоящему договору в одностороннем порядке с одновременной отправкой электронного уведомления. Моментом расторжения Договора считается дата направления соответствующего сообщения <strong>Заказчику</strong>.</span></span></p>\n<p style=\"margin-left:35.45pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">4.3.3. Удалить виртуальный кабинет Заказчика, если по истечении 3(трех) месяцев <strong>Заказчик </strong>не осуществил ни одной рассылки.</span></span></p>\n<p style=\"margin-left:36.0pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">4.4. Партнер принимает на себя следующие обязательства:</span></span></p>\n<p style=\"margin-left:36.0pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">4.4.1. Распространять информацию о услуге платежей при наличии утвержденного <strong>Исполнителем</strong> информационного набора данных о стоимости услуги.</span></span></p>\n<p style=\"margin-left:36.0pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">4.4.2. Распространять информацию о предоставлении услуг платежей, в том числе путем размещения рекламы в СМИ, исключительно в полном соответствии с законодательством РФ.</span></span></p>\n<p style=\"margin-left:36.0pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">4.5. Партнер приобретает следующие права:</span></span></p>\n<p style=\"margin-left:36.0pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">4.5.1.Получать статистику зарегистрированных у него партнеров первого и второго уровня при помощи специального раздела в личном кабинете.</span></span></p>\n<p style=\"margin-left:36.0pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">4.5.2. Получать денежные средства за оказанные SMS-услуги в порядке, предусмотренном настоящим документом.</span></span></p>\n<p align=\"center\">\n	<span style=\"font-size:22px;\"><span style=\"font-family:times new roman,times,serif;\"><strong>5. Стоимость услуг и порядок расчетов</strong></span></span></p>\n<p style=\"margin-left:35.45pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">5.1.<strong> Заказчик</strong> осуществляет оплату пакета SMS сообщений через сервис WebMoney или со счета мобильного телефона, после получения уведомления о платеже на сайте можно осуществлять отправку сообщения.</span></span></p>\n<p style=\"margin-left:35.4pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">5.2. В случае изменения стоимости услуг согласно действующего прайс-листа, <strong>Исполнитель</strong> обязан предупредить <strong>Заказчика</strong> об этом заблаговременно, то есть за 10 (десять) календарных дней.</span></span></p>\n<p style=\"margin-left:35.45pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">5.3. <strong>Заказчик</strong> самостоятельно несет ответственность за правильность производимых им платежей.</span></span></p>\n<p style=\"margin-left:35.45pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">5.4. Вознаграждение Партнера определяется в соответствии с тарификацией партнерской программы.</span></span></p>\n<p style=\"margin-left:35.45pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">5.5. Данным документом <strong>Исполнитель</strong> имеет право в одностороннем порядке изменять размер вознаграждения Партнера своевременно уведомив его об этом.</span></span></p>\n<p style=\"margin-left:35.45pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">5.6. По настоящему документу Партнер компенсирует <strong>Исполнителю</strong> все понесенные расходы по исполнению своего поручения только в том случае, если наименование и размер, либо порядок определения размера указанных расходов согласованны Сторонами, либо они были произведены по предварительному или последующему согласованию с Партнером. <strong>Исполнитель</strong> вправе не предоставлять Партнеру документы, подтверждающие расходы Компании, компенсируемые Партнером по настоящему Соглашению.</span></span></p>\n<p style=\"margin-left:35.45pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">5.7. При расчетах между Сторонами учитываются только оплаченные Партнерами SMS-запросы.</span></span></p>\n<p style=\"margin-left:35.45pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">5.8. Стоимость SMS-услуги может быть определена в национальной валюте, при этом все расчеты между сторонами осуществляются в рублях любым удобным способом.</span></span></p>\n<p style=\"margin-left:35.45pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">5.9. <strong>Исполнитель</strong> перечисляет Партнеру причитающееся ему за Отчетный период вознаграждение в течение 5 календарных дней месяца, следующего за Отчетным.</span></span></p>\n<p align=\"center\" style=\"margin-left:35.45pt;\">\n	<span style=\"font-size:22px;\"><span style=\"font-family:times new roman,times,serif;\"><strong>6. Порядок завершения работ</strong></span></span></p>\n<p style=\"margin-left:36.0pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">6.1. Моментом завершения <strong>Исполнителем</strong> работ по настоящему договору является дата и время отправки последнего сообщения абоненту, указанные <strong>Заказчиком</strong> в своем &laquo;Личном кабинете&raquo;.</span></span></p>\n<p style=\"margin-left:35.4pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">6.2. Для подтверждения выполнения работы <strong>Заказчику</strong> автоматически представляется отчет в электронном виде, содержащий дату, время, текст и список абонентов, которым произведена рассылка.</span></span></p>\n<p style=\"margin-left:35.45pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">6.4. Отчетным периодом является один календарный месяц.</span></span></p>\n<p align=\"center\">\n	<span style=\"font-size:22px;\"><span style=\"font-family:times new roman,times,serif;\"><strong>7. Ответственность сторон</strong></span></span></p>\n<p style=\"margin-left:36.0pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">7.1. <strong>Исполнитель</strong> не несет ответственность за качество линий связи, при помощи которых <strong>Заказчик</strong> устанавливает соединение с сервисом <strong>Исполнителя</strong> и операторов сотовой связи, обеспечивающих передачу SMS-сообщений.</span></span></p>\n<p style=\"margin-left:35.45pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">7.2. Вся ответственность за содержание рассылаемого текста, достоверность сведений, ошибки, неточности, которые содержатся в рассылаемых сообщениях, полностью лежит на <strong>Заказчике.</strong></span></span></p>\n<p style=\"margin-left:35.4pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">7.3 <strong>Заказчик</strong> несет ответственность перед абонентом, осуществляя информирование по собственной базе о согласии абонента получать информацию.</span></span></p>\n<p style=\"margin-left:36.0pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">7.4. При рассылке <strong>Заказчиком</strong> сообщений по базе сервиса &laquo;WORLD SMS&raquo; <strong>Исполнитель, </strong>гарантирует, что имеет согласие абонентов на получение рекламных и информационных сообщений и этим берет на себя ответственность перед абонентами, за рассылаемую им информацию.</span></span></p>\n<p style=\"margin-left:36.0pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">7.5. В случае предъявления к <strong>Исполнителю</strong> претензий, наложения Оператором на <strong>Исполнителя</strong> штрафов или иных взысканий в связи с осуществляемым <strong>Заказчиком</strong> в рамках настоящего Договора Информированием, <strong>Заказчик</strong> обязуется компенсировать <strong>Исполнителю</strong> взысканные Оператором денежные суммы в полном объеме, в течение 5 (пяти) банковских дней с момента получения соответствующего требования от <strong>Исполнителя</strong>.</span></span></p>\n<p style=\"margin-left:35.45pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">7.6. В случае неисполнения или ненадлежащего исполнения Стороной своих обязанностей по настоящему договору, она несет ответственность, установленную действующим законодательством.</span></span></p>\n<p style=\"margin-left:35.45pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">7.7. <strong>Исполнитель</strong> не несет ответственности за убытки и другие последствия, наступившие в связи с использованием или невозможностью использования <strong>Заказчиком </strong>сервисом <strong>Исполнителя</strong>.</span></span></p>\n<p align=\"center\">\n	<span style=\"font-size:22px;\"><span style=\"font-family:times new roman,times,serif;\"><strong>8. Заключительные положения</strong></span></span></p>\n<p style=\"margin-left: 40px\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">9.1. Условия настоящего договора могут быть в любое время изменены или дополнены по соглашению сторон.</span></span></p>\n<p style=\"margin-left:35.4pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">9.2. Изменения и дополнения к настоящему договору вступают в силу после их подписания полномочными представителями Сторон и скрепления подписей печатями Сторон.</span></span></p>\n<p style=\"margin-left:35.4pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">9.3. Все споры, возникшие по данному Договору, разрешаются путем переговоров. В случае если <strong>Стороны </strong>не могут прийти к соглашению, все споры и разногласия, возникшие в результате неисполнения Настоящего Договора, разрешаются в соответствующих судебных органах, согласно действующему законодательству РФ.</span></span></p>\n<p style=\"margin-left:36.0pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">9.4. Принимая условия настоящей Оферты, <strong>Заказчик</strong> заверяет и гарантирует что:</span></span></p>\n<p style=\"margin-left:36.0pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">&mdash; <strong>Заказчик</strong> заключает Договор добровольно, при этом:<br />\n	а) полностью ознакомился с условиями Оферты<br />\n	б) полностью понимает предмет Оферты<br />\n	в) полностью понимает значение и последствия своих действий в отношении заключения и исполнения Договора</span></span></p>\n<p style=\"margin-left:36.0pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">&mdash; <strong>Заказчик</strong> обладает всеми правами и полномочиями, необходимыми для заключения и исполнения Договора; отправка сообщений не нарушает и не влечет за собой нарушение действующего законодательства и/или прав третьих лиц.</span></span></p>\n<p style=\"margin-left:36.0pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">9.5. В случае не согласия <strong>Заказчика</strong> с какими-либо пунктами данного Договора, <strong>Заказчик</strong> должен немедленно покинуть сайт.</span></span></p>\n<p style=\"margin-left:36.0pt;\">\n	&nbsp;</p>\n<p align=\"right\" style=\"margin-left:35.4pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">Приложение № 1</span></span></p>\n<p align=\"center\">\n	<span style=\"font-size:22px;\"><span style=\"font-family:times new roman,times,serif;\"><strong>ПРАВИЛА ПРЕДОСТАВЛЕНИЯ УСЛУГ</strong></span></span></p>\n<p style=\"margin-left:35.4pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\"><strong>1.</strong> Услуги предоставляются только <strong>Заказчикам</strong>, заключившим с <strong>Исполнителем</strong> Договор о предоставлении Услуг и зарегистрированным в Системе.</span></span></p>\n<p style=\"margin-left:35.4pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\"><strong>2.</strong> При регистрации <strong>Заказчик</strong> заполняет персональные логин и пароль, позволяющие получить доступ к защищенной области сайта <strong>Исполнителя</strong>. <strong>Исполнитель</strong> имеет право предоставить <strong>Заказчику</strong> возможность регистрации своих абонентов на сайте <strong>Исполнителя</strong>.</span></span></p>\n<p style=\"margin-left:35.4pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\"><strong>3. </strong>Техническая служба поддержки <strong>Исполнителя</strong> работает с 10<sup>00</sup> - 19<sup>00 </sup>по московскому времени.</span></span></p>\n<p style=\"margin-left:35.4pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\"><strong>4. </strong>Услуги предоставляются круглосуточно.</span></span></p>\n<p style=\"margin-left:35.4pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\"><strong>5.</strong> <strong>Заказчик</strong> должен обеспечивать конфиденциальность присвоенного ему пароля. <strong>Исполнитель</strong> не несет ответственности перед <strong>Заказчиком</strong> за любые убытки, понесенные <strong>Заказчиком</strong> в связи с утерей своего пароля.</span></span></p>\n<p style=\"margin-left:35.4pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\"><strong>6. </strong><strong>Заказчику</strong> категорически запрещается, в ходе эксплуатации услуги цифробуквенной смены адреса отправителя, использовать в адресе отправителя названия любой юридической структуры (оператора мобильной связи, банковских, страховых структур, государственных и правительственных учреждений и т.д.) к которым он не относится, за исключением случаев, когда правомерность использования подобного адреса отправителя документально подтверждено самой юридической структурой.</span></span></p>\n<p style=\"margin-left:35.4pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">В случае выявления <strong>Исполнителем</strong> нарушений <strong>Заказчиком</strong> условий данного приложения, <strong>Исполнитель</strong> имеет право заблокировать отправку сообщений <strong>Заказчика</strong>, и расторгнуть договор в одностороннем порядке, без возврата средств, находящихся на балансе личного кабинета.</span></span></p>\n<p style=\"margin-left:35.4pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">В случае предъявления <strong>Исполнителю</strong> письменно подтвержденных финансовых претензий от любой организации, название которой использовал <strong>Заказчик</strong> в своем адресе отправителя, <strong>Заказчик</strong> обязуется возместить их в полном объеме.</span></span></p>\n<p style=\"margin-left:36.0pt;\">\n	&nbsp;</p>`, `rules`, `Правила сервиса`, ``, `Правила сервиса`, ``, ``, `Сергей`, `120`, `1353842959`);
INSERT INTO `sms_statics` VALUES(`21`, `Контакты`, `<p>\n	<span style=\"font-family:times new roman,times,serif;\"><span style=\"font-size:18px;\">По всем возникшим техническим вопросам обращайтесь в нашу техническую поддержку <a href=\"mailto:support@world-sms.ru\"><strong>support@world-sms.ru</strong></a></span></span></p>\n<p>\n	<span style=\"font-family:times new roman,times,serif;\"><span style=\"font-size:18px;\">Предложения о сотрудничестве высылайте по адресу&nbsp;<a href=\"mailto:info@world-sms.ru\"><strong>info@world-sms.ru</strong></a></span></span></p>\n<p>\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Группа в контате&nbsp;<a href=\"http://vk.com/club37635217\">http://vk.com/club37635217</a></span></span></p>\n<p>\n	&nbsp;</p>\n`, `contacts`, ``, ``, ``, ``, ``, ``, `289`, `1340564196`);
INSERT INTO `sms_statics` VALUES(`26`, `Сетевой маркетинг`, `<p>\n	&nbsp;</p>\n<p>\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">Владельцам сетевого бизнеса открываются огромные возможности увеличить число своих клиентов и как следствие расширения бизнеса в целом, при этом получая дополнительные деньги от использования <a href=\"http://world-sms.ru/partners.html\">партнерской программы</a>.</span></span></p>\n<p>\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\"><strong>Для начала поговорим о том, как может помочь Вам сервис </strong><strong>SMS</strong> <strong>рассылок. </strong></span></span></p>\n<p style=\"text-align: center\">\n	<img alt=\"\" src=\"/upload/12.png\" style=\"width: 608px; height: 200px\" /></p>\n<h2 style=\"text-align: center;\">\n	<span style=\"font-size:22px;\"><span style=\"font-family: times new roman,times,serif;\"><strong>Секрет успешного бизнеса в использовании множества рычагов, </strong></span></span></h2>\n<h2 style=\"text-align: center;\">\n	<span style=\"font-size: 22px;\"><span style=\"font-family: times new roman,times,serif;\"><strong>один из них сейчас перед вами!</strong></span></span></h2>\n<p>\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\"><em>Способ 1.</em> Итак, одним из вариантов привлечения клиентов является массовая рассылка сообщений после промо акций. Вы проводите акцию, собираете номера телефонов, затем делаете рассылку сообщений примерно с таким текстом: &laquo;Получите подарок от &laquo;Название компании&raquo; в нашем офисе, по адресу&hellip;..в среду с 15:00 до 17:00. Консультант Екатерина&raquo;. Наш сервис предоставляет возможность использования любой подписи при отправке сообщения, следовательно Вы можете подписаться &laquo;Название компании&raquo;. Это увеличит доверие ваших клиентов к Вам еще до личной встрече. Текст сообщения может быть любым другим. В качестве подарка клиенту можно использовать любую недорогую продукцию. После того как клиент получит подарок и у него поднимется настроение можно рассказать ему более подробно о все преимуществах сетевого бизнеса. Дальше все будет зависеть только от Вас.</span></span></p>\n<p>\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\"><em>Способ 2.</em> Во время заполнения клиентом анкеты, Вы предлагаете ему указать телефоны 5 друзей, которым в последствии будет вручен подарок от компании &laquo;Название компании&raquo;. Клиент с радостью укажет 5 номеров и предупредит друзей о будущем подарку. Дальше Вы опять же делаете рассылку по всем полученным номерам и действуете как в первом случае.</span></span></p>\n<p>\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\"><em>Способ 3. </em>У Вас есть своя выстроенная сеть. Вам нужно постоянно информировать своих партнеров и клиентов о новых акциях, семинарах, тренингах и других встречах. Делать это непосредственно обзванивая всех и отправляя сообщения с мобильного телефона долго и дорого. При этом наверняка не у всех есть Ваш номер телефона в записной книжке, поэтому не всегда ясно от кого пришло сообщение или кто звонил (если вдруг звонок был пропущен). WORLD-SMS позволяет решить эту проблему раз и навсегда. В личном кабинете можно создать разные группы (например друзья, партнеры, клиенты и т. д.) и делать рассылки сразу целой группе людей. Кроме того можно заранее запланировать рассылку, просто указав дату и время, когда сообщения будут доставлены. Уведомления о доставке позволят определить кто получил сообщение, а кто еще нет.</span></span></p>\n<p>\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">Существует множество способов привлечения клиентов по средствам SMS рассылок. Это недорогой, удобный и действенный способ привлечения новых клиентов и партнеров. SMS читают все и если они приходят от конкретной организации или человека, а не с неизвестного номера, то это сразу вызывает больше доверия.</span></span></p>\n<p>\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\"><strong>Теперь Вы узнаете как можно зарабатывать дополнительные деньги на рассылках.</strong></span></span></p>\n<p style=\"text-align: center\">\n	<span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\"><strong><img alt=\"\" src=\"/upload/.jpg\" style=\"width: 344px; height: 200px\" /></strong></span></span></p>\n<h2 style=\"text-align: center;\">\n	<span style=\"font-size:22px;\"><strong><span style=\"font-family: times new roman,times,serif;\">Стабильный доход состоит из нескольких частей, сделайте заработок от рассылки SMS сообщений одной из его частей!</span></strong></span></h2>\n<p>\n	<span style=\"font-size: 18px;\"><span style=\"font-family: times new roman,times,serif;\">Раз Вы владелец сетевого бизнеса, значит у Вас есть партнеры, входящие в вашу сеть и много знакомых у которых тоже есть партнеры, которых вы лично не знаете. &nbsp;Значит <a href=\"http://world-sms.ru/partners.html\">партнерская программа</a>, разработанная компанией WORLD-SMS, прекрасно подойдет Вам в это случае. Просто порекомендуйте сервис SMS рассылок WORLD-SMS всем этим людям получите за это <strong>30%</strong> от покупаемых ими сообщений. Эта двухуровневая программа, поэтому сначала Вы получите <strong>20%</strong> от </span></span><span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">потраченных денег на приобретение SMS сообщений</span></span><span style=\"font-size: 18px;\"><span style=\"font-family: times new roman,times,serif;\"> партнеров первого уровня и <strong>10%</strong> от </span></span><span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\">потраченных денег на приобретение SMS сообщений</span></span><span style=\"font-size:18px;\"><span style=\"font-family:times new roman,times,serif;\"> партнеров второго уровня. Преимущество в том что партнеров второго уровня Вы можете даже не знать. Одним из способов привлечения партнеров являются семинары, на которых присутствуют представители из разных городов. Просто порекомендуйте им оценить эффективность SMS рассылок. Ссылка для регистрации партнеров находится в личном кабинете. &nbsp;Для того чтобы стать участником <a href=\"http://world-sms.ru/partners.html\">партнерской программы</a> необходимо при регистрации указать WMR-кошелек, на который Вам будут выводиться заработанные деньги (зарегистрировать кошелек можно на сайте WebMoney, регистрация простая происходит в течении 5 минут). Вывод денег происходит с 1 по 5 число каждого следующего за отчетным месяца.</span></span></p>\n<p style=\"text-align: right;\">\n	<a href=\"http://world-sms.ru/buy\"><span style=\"font-size: 18px;\"><span style=\"font-family: times new roman,times,serif;\"><img alt=\"\" class=\"button\" src=\"/upload/Buy_SMS.png\" style=\"width: 256px; height: 100px;\" /></span></span></a></p>`, `mlm`, `Сетевой маркетинг`, `world, партнеров, world sms, sms рассылок, сетевого бизнеса, смс рассылка, рассылка, клиентов, сервис, подарок, компании`, `Для сетевого маркетинга`, ``, ``, `Владимир`, `158`, `1354290232`);
INSERT INTO `sms_statics` VALUES(`27`, `Сервисные центры, автосалоны, автодиллеры`, `<p>\n	<span style=\"font-size: 18px;\"><span style=\"font-family: times new roman,times,serif;\">Быть впереди всех конкурентов и завоевывать лояльность клиентов непрос</span></span><span style=\"font-size: 18px;\"><span style=\"font-family: times new roman,times,serif;\">тая, но очень важная задача для каждого бизнеса. Для </span></span><span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\"><img alt=\"\" src=\"/upload/.png\" style=\"width: 353px; height: 200px; float: right;\" /></span></span><span style=\"font-size: 18px;\"><span style=\"font-family: times new roman,times,serif;\">этого нужно использовать новые технические </span></span><span style=\"font-size: 18px;\"><span style=\"font-family: times new roman,times,serif;\">решения, позволяющие избавиться от рутинной работы и автоматизировать бизнес, освободив время для расширения своей компании. WOR</span></span><span style=\"font-size: 18px;\"><span style=\"font-family: times new roman,times,serif;\">LD-SMS позволит Вам д</span></span><span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">оносить информацию до клиентов быстро и эффективно.</span></span></p>\n<p>\n	<strong><span style=\"font-size: 18px;\"><span style=\"font-family: times new roman,times,serif;\">При использовании сервиса SMS рассылок Вы сможете:</span></span></strong></p>\n<ul>\n	<li>\n		<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Пригласить всех клиентов на тест-драйв новых моделей автомобилей.</span></span></li>\n	<li>\n		<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Поставить автоматическую рассылку с напоминаниями клиенту о том, что подходит время очередного техобслуживания или проверки, либо о необходимости замены резины на зимнюю или летнюю. Просто установите рассылку сообщений на нужный день и час, и занимайтесь своими делами, отправка сообщений будет произведена по расписанию.</span></span></li>\n	<li>\n		<span style=\"font-size: 18px;\"><span style=\"font-family: times new roman,times,serif;\">Быстро оповещать клиента о том, что работы по ремонту завершены, при этом</span></span><span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\"> указав место где находится автомобиль и время, когда его можно забрать.</span></span></li>\n	<li>\n		<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Предупреждать о бонусных акциях, действующих у Вас в компании, а также скидках.</span></span></li>\n	<li>\n		<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Сообщать о появлении в салонах новой линейки автомобилей.</span></span></li>\n	<li>\n		<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Сообщать об открытии новых автосалонов и сервисных центра.</span></span></li>\n	<li>\n		<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Поздравить всех клиентов с днем рождения, с Днем автомобилиста с новым годом и другими праздниками.</span></span></li>\n</ul>\n<p>\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Если Вы занимаетесь транспортными видами услуг, то по средством рассылки SMS сообщений можно информировать клиентов об изменении цен на грузовые и пассажирские перевозки, о времени прибытия груза и др.</span></span></p>\n<p>\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Станьте участником нашей <a href=\"http://world-sms.ru/partners.html\">партнерской программы</a>, рекомендуйте услуги рассылки SMS сообщений и получайте дополнительные бонусы от компании WORLD-SMS!</span></span></p>\n<p style=\"text-align: right;\">\n	<a href=\"http://world-sms.ru/buy\"><img alt=\"\" class=\"button\" src=\"/upload/Buy_SMS.png\" style=\"width: 256px; height: 100px;\" /></a></p>`, `avto`, `Сервисные центры, автосалоны, автодиллеры`, `world sms, клиентов, рассылка, смс рассылка, услуги, сервис`, `Для сервисных центров, автосалонов, автодиллеров`, ``, ``, `Владимир`, `95`, `1354290034`);
INSERT INTO `sms_statics` VALUES(`28`, `Банки и кредитные организации`, `<p>\n	<span style=\"font-family:times new roman,times,serif;\"><span style=\"font-size: 18px;\">Работу как с физическими, так и с юридическими лицами нужно автоматизировать, разгружая при этом сотрудников банка. Одним из инструментов может стать массовая рассылка SMS сообщений через интернет. Это просто, удобно, занимает мало времени, а благодаря возможности отправки SMS в заранее назначенный день и час банк может работать в автоматическом режиме в любое время суток даже в праздничные дни. Благодаря бесплатной услуги подмены номера Ваши клиенты всегда будут знать от кого пришло им сообщение.</span></span></p>\n<h3>\n	<span style=\"font-family:times new roman,times,serif;\"><span style=\"font-size: 18px;\"><strong>О чем можно информировать клиентов?</strong></span></span></h3>\n<ul>\n	<li>\n		<span style=\"font-family:times new roman,times,serif;\"><span style=\"font-size: 18px;\">появлении новых услуг;</span></span></li>\n	<li>\n		<span style=\"font-family:times new roman,times,serif;\"><span style=\"font-size: 18px;\">специальных предложениях по процентным ставкам, депозитам и кредитам;</span></span></li>\n	<li>\n		<span style=\"font-family:times new roman,times,serif;\"><span style=\"font-size: 18px;\">необходимы платежах (напоминание сроков погашения кредитов, начислений пени, просрочки платежей и др.);</span></span></li>\n	<li>\n		<span style=\"font-family:times new roman,times,serif;\"><span style=\"font-size: 18px;\">выполнении каких-либо операций (снятие и зачисление денежных средств, начисление процентов);</span></span></li>\n	<li>\n		<span style=\"font-family:times new roman,times,serif;\"><span style=\"font-size: 18px;\">скором окончании срока действия платежной карты;</span></span></li>\n	<li>\n		<span style=\"font-family:times new roman,times,serif;\"><span style=\"font-size: 18px;\">блокировании и разблокировании платежной карты.</span></span></li>\n</ul>\n<p style=\"margin-left:18.0pt;\">\n	<span style=\"font-family:times new roman,times,serif;\"><span style=\"font-size: 18px;\">Клиенты будут рады получать поздравления с праздниками через SMS сообщения.</span></span></p>\n<p style=\"margin-left: 18pt; text-align: right;\">\n	<a href=\"http://world-sms.ru/buy\"><img alt=\"\" class=\"button\" src=\"/upload/Buy_SMS.png\" style=\"width: 256px; height: 100px;\" /></a></p>`, `bank`, `Банки и кредитные организации`, `world sms, рассылка, услуги, сервис`, `Для банков и кредитных организаций`, ``, ``, `Владимир`, `126`, `1354208308`);
INSERT INTO `sms_statics` VALUES(`29`, `Кафе, рестораны, ночные клубы, кинотеатры`, `<h3>\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\"><strong>Решение проблемы пустых столиков в Вашем заведении</strong></span></span></h3>\n<p>\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Эта проблема существует не только во многих вновь открывшихся заведениях, но даже в давно работающих. Причин для этого может быть множество, но главная &ndash; это нехватка информации у клиентов. Донести всю необходимую информацию поможет сервис массовой рассылки сообщений WORLD-SMS. Это простой, удобный и выгодный интернет-помощник.</span></span></p>\n<p>\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Проблема пустых столиков будет решена, как только посетители будут своевременно получать информацию. Это информация должна содержать предложения получить бесплатное угощение от шеф повара при заказе на определенную сумму, скидках для большой компании и др. заманчивых предложениях.</span></span></p>\n<h3>\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\"><strong>Персональные </strong><strong>SMS</strong> <strong>приглашения</strong></span></span></h3>\n<p>\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Чтобы собрать большую базу телефонных номеров клиентов разложите на столиках приглашения для участия в SMS рассылке и разместите его на отдельной странице меню. Кроме того при выставлении счета за обслуживание, официант может предложить оформить подписку на персональную SMS рассылку, если обслуживание понравилось клиенту.</span></span></p>\n<h3>\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\"><strong>SMS</strong> <strong>уведомления могут быть следующими:</strong></span></span></h3>\n<ul style=\"list-style-type:circle;\">\n	<li>\n		<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Реклама новых блюд</span></span></li>\n</ul>\n<p style=\"margin-left:36.0pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Гурманы, любящие ваше заведение, обязательно захотят придти к Вам и отведать новое блюдо в уютной атмосфере.</span></span></p>\n<ul style=\"list-style-type:circle;\">\n	<li>\n		<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Бронирование столиков через SMS</span></span></li>\n</ul>\n<p style=\"margin-left:36.0pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Это удобно, когда под руками есть только мобильный телефон. В присылаемом SMS сообщении клиенту необходимо указать контактное лицо, дату и время для резервирования столика.</span></span></p>\n<ul style=\"list-style-type:circle;\">\n	<li>\n		<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Прием заказов доставки блюд на дом с SMS подтверждением и уведомлением о времени выполнения заказа</span></span></li>\n</ul>\n<p style=\"margin-left:36.0pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Клиенты будут уверены что в их заказе ничего не напутают. Они будут рады получить сообщение с точным временем готовности и доставки заказа.</span></span></p>\n<ul style=\"list-style-type:circle;\">\n	<li>\n		<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Открытие новых кафе и ресторанов</span></span></li>\n</ul>\n<p style=\"margin-left:36.0pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">При открытии нового заведения существенным является реклама. Постоянные клиенты будут рады получить эту информацию, поскольку расположение нового заведения может быть удобнее для них или их знакомых.</span></span></p>\n<ul style=\"list-style-type:circle;\">\n	<li>\n		<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Уведомления о новых акциях</span></span></li>\n</ul>\n<p style=\"margin-left:36.0pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Информация об акциях позволяющих сэкономить на посещении кафе, ресторана или ночного клуба определенно порадует Ваших клиентов.</span></span></p>\n<ul style=\"list-style-type:circle;\">\n	<li>\n		<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Выступление артистов и музыкальных групп</span></span></li>\n</ul>\n<p style=\"margin-left:36.0pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Свежая и своевременная информации о выступлении любимого артиста или группы заставит фанатов посетить Ваше заведение.</span></span></p>\n<p style=\"margin-left:36.0pt;\">\n	&nbsp;</p>\n<h3 style=\"margin-left: 36pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\"><strong>Информация &ndash; главный инструмент привлечения новых клиентов и удержания старых!</strong></span></span></h3>\n<p style=\"text-align: right;\">\n	<a href=\"http://world-sms.ru/buy\"><img alt=\"\" class=\"button\" src=\"/upload/Buy_SMS.png\" style=\"width: 256px; height: 100px;\" /></a></p>`, `entertainment`, `Кафе, рестораны, ночные клубы, кинотеатры`, ``, `Для кафе, рестораны, ночные клубы, кинотеатры`, `world sms, кафе, рестораны, ночные клубы, клиентов`, ``, `Владимир`, `132`, `1354289643`);
INSERT INTO `sms_statics` VALUES(`31`, `Торговые сети и маленькие магазины`, `<p>\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\"><img alt=\"\" src=\"/upload/2.png\" style=\"width: 93px; height: 100px; float: left;\" /></span></span><span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">В современном мире компаниям постоянно приходится конкурировать друг с другом, изобретая все новые и новые способы рекламы. К сожалению устаревание информации идет слишком быстро, поэтому нужно постоянно отслеживать все новое. Компании, предоставляющие такую информацию опережают своих конкурентов на несколько шагов. Грамотно используя сервис рассылок WORLD-SMS вы сможете доносить самую передовую информацию до каждого клиента в отдельности. Каждому человеку приятно, когда его информируют персонально, главное это делать не навязчиво, тогда случайный покупатель легко превратится в постоянного.</span></span></p>\n<p>\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">SMS сообщения читают все! Информация, отправленная SMS рассылкой, будет доставлена до адресата и прочитана им.</span></span></p>\n<p>\n	<span style=\"font-size: 18px;\"><span style=\"font-family: times new roman,times,serif;\"><strong>Распространяете ли Вы купоны на скидки?</strong> Если да, то теперь это можно делать гораздо эффективнее. Распространение электронных купонов </span></span><span style=\"font-size: 18px;\"><span style=\"font-family: times new roman,times,serif;\">по </span></span><span style=\"font-size: 18px;\"><span style=\"font-family: times new roman,times,serif;\">средствам </span></span><span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">SMS рассылок удобно не только Вам, но и Вашим клиентам. Такие купоны не теряются, они всегда с собой в мобильном телефоне и Вы можете распространить их за считанные минуты тысячам человек. И не нужно заказывать изготовление купонов, нанимать людей которые будут раздавать эти купоны, людей которые будут проверять действительно ли купоны розданы. Купон будет представлять из себя SMS сообщение от Вашей компании (WORLD-SMS предоставляет бесплатную услугу подмены номера). Если же вы не распространяете купоны, то задумайтесь, возможно это стоит попробовать!</span></span></p>\n<p>\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\"><img alt=\"\" src=\"/upload/1.png\" style=\"width: 100px; height: 100px; float: left;\" /></span></span><span style=\"font-size: 18px;\"><span style=\"font-family: times new roman,times,serif;\"><strong>Информирование о скидках и акциях.</strong> Всем известно что скидки и всевозможные акция являются для девушек магическими словами. Они </span></span><span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\"><img alt=\"\" src=\"/upload/3.png\" style=\"width: 144px; height: 100px; float: right;\" /></span></span><span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">притягивают и завораживают. Но часто информация о них приходит слишком поздно. Это легко исправить с сервисом WORLD-SMS. Давая желаемую информацию своим клиентам Вы повышаете их настроение, что очень важно при совершении покупок. Они будут рассказывать своим друзьям о Вашем магазине.</span></span></p>\n<p style=\"text-align: right;\">\n	<a href=\"http://world-sms.ru/buy\"><span style=\"font-size: 18px;\"><span style=\"font-family: times new roman,times,serif;\"><img alt=\"\" class=\"button\" src=\"/upload/Buy_SMS.png\" style=\"width: 256px; height: 100px;\" /></span></span></a></p>`, `shop`, `Торговые сети и маленькие магазины`, `world sms, смс рассылка, купоны, сервис, рассылка, информацию, скидки`, `Раздел для торговых сетей и маленьких магазинов`, ``, ``, `Владимир`, `91`, `1354290613`);
INSERT INTO `sms_statics` VALUES(`32`, `Интернет торговля`, `<p>\n	<span style=\"font-size:24px;\"><strong><span style=\"font-family:times new roman,times,serif;\">Страница находится в разработке</span></strong></span></p>\n<p style=\"text-align: right;\">\n	<a href=\"http://world-sms.ru/buy\"><span style=\"font-size: 24px;\"><strong><span style=\"font-family: times new roman,times,serif;\"><img alt=\"\" class=\"button\" src=\"/upload/Buy_SMS.png\" style=\"width: 256px; height: 100px;\" /></span></strong></span></a></p>`, `internetcommerce`, `Интернет торговля`, ``, `Раздел для интернет торговли`, ``, ``, `Владимир`, `83`, `1354289703`);
INSERT INTO `sms_statics` VALUES(`33`, `Спортивные центры, фитнес клубы`, `<h3>\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\"><strong>Собрать большую базу телефонных номеров и привлечь новых клиентов</strong></span></span></h3>\n<p>\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Этот вопрос легко решить следуя простым инструкциям. Предложите клиентам, занимающимся у Вас в клубе написать 5 телефонных номеров друзей и знакомых, которым будет выслано SMS сообщение с подарком в виде скидки на месячный абонемент. В SMS сообщении Вы можете указать ФИО человека, который дал этот номер телефона, поэтому новый клиент всегда сможет проверить действительно ли это так и заодно расспросить о преимуществах Вашего центра. Благодаря этому решению Ваш фитнес клуб или спортивный центр сможет в короткие сроки значительно увеличить число новых клиентов. А при постоянном использовании этого решения можно обеспечить постоянный поток клиентов.</span></span></p>\n<h3>\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\"><strong>Что еще можно делать через </strong><strong>SMS</strong><strong>?</strong></span></span></h3>\n<p>\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Очень важно не только привлекать новых клиентов, но и удерживать старых. Для этого необходимо поддерживать с ними постоянный контакт. Информировать их обо всех новостях Вашего центра. Это можно делать при помощи рассылки SMS сообщений.</span></span></p>\n<h3>\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\"><strong>В сообщения можно указывать:</strong></span></span></h3>\n<ul>\n	<li>\n		<span style=\"font-size: 18px;\"><span style=\"font-family: times new roman,times,serif;\">Напоминание о том что срок действия абонемента скоро истекает</span></span></li>\n	<li>\n		<span style=\"font-size: 18px;\"><span style=\"font-family: times new roman,times,serif;\">Приглашения поучаствовать в спортивных мероприятиях</span></span></li>\n	<li>\n		<span style=\"font-size: 18px;\"><span style=\"font-family: times new roman,times,serif;\">Информация о появлении новых услуг</span></span></li>\n	<li>\n		<span style=\"font-size: 18px;\"><span style=\"font-family: times new roman,times,serif;\">Напоминание о записи на услугу в определенное время</span></span></li>\n	<li>\n		<span style=\"font-size: 18px;\"><span style=\"font-family: times new roman,times,serif;\">Информация об открытии новых центров или клубов</span></span></li>\n	<li>\n		<span style=\"font-size: 18px;\"><span style=\"font-family: times new roman,times,serif;\">Информация об изменении расписания занятий</span></span></li>\n	<li>\n		<span style=\"font-size: 18px;\"><span style=\"font-family: times new roman,times,serif;\">Поздравления с праздниками</span></span></li>\n</ul>\n<p style=\"text-align: right;\">\n	<img alt=\"\" class=\"button\" src=\"/upload/Buy_SMS.png\" style=\"width: 256px; height: 100px;\" /></p>`, `sport`, `Спортивные центры, фитнес клубы`, `world sms, смс рассылка, новых клиентов, новых, клиентов, информация, фитнес, сервис`, `Раздел для спортивных центров, фитнес клубов`, ``, ``, `Владимир`, `98`, `1354290372`);
INSERT INTO `sms_statics` VALUES(`34`, `Провайдеры связи, интернет, телевидение`, `<p>\n	<span style=\"font-size:24px;\"><strong><span style=\"font-family:times new roman,times,serif;\">Страница находится в разработке</span></strong></span></p>\n<p style=\"text-align: right;\">\n	<a href=\"http://world-sms.ru/buy\"><img alt=\"\" class=\"button\" src=\"/upload/Buy_SMS.png\" style=\"width: 256px; height: 100px;\" /></a></p>`, `interent`, `Провайдеры связи, интернет, телевидение`, ``, `Раздел для провайдеров связи, интернета, телевидения`, ``, ``, `Владимир`, `96`, `1354289900`);
INSERT INTO `sms_statics` VALUES(`35`, ``, `<h2 align=\"center\">\n	<span style=\"font-size:22px;\"><span style=\"font-family: times new roman,times,serif;\">Добро пожаловать на сайт сервиса рассылок SMS сообщений WORLD-SMS!</span></span></h2>\n<p style=\"text-align: center;\">\n	<span style=\"font-family:times new roman,times,serif;\"><a href=\"http://world-sms.ru/sms.html\"><img alt=\"\" class=\"button\" src=\"/upload/SMS_rassilka.png\" style=\"width: 173px; height: 150px;\" /></a>&nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp;&nbsp; &nbsp;<a href=\"http://world-sms.ru/billing.html\"><img alt=\"\" class=\"button\" src=\"/upload/SMS_billing.png\" style=\"width: 143px; height: 150px;\" /></a>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; <a href=\"http://world-sms.ru/sms_zip_about.html\"><img alt=\"\" class=\"button\" src=\"/upload/Zip_arhiv.png\" style=\"width: 171px; height: 150px;\" /></a></span>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<a href=\"http://world-sms.ru/faq.html\"><img alt=\"\" class=\"button\" src=\"/upload/F.A.Q.png\" style=\"width: 171px; height: 150px;\" /></a>&nbsp;&nbsp;</p>\n<h2 align=\"center\">\n	<span style=\"font-size:22px;\"><span style=\"font-family: times new roman,times,serif;\">Массовая рассылка SMS сообщений по Вашей базе клиентов</span></span></h2>\n<p>\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">&nbsp;&nbsp;Сервис WORLD-SMS позволяет массово рассылать SMS сообщения из личного кабинета на нашем сайте. Для этого необходимо только <a href=\"http://world-sms.ru/register\">зарегистрироваться</a>, загрузить свою базу номеров, составить текст сообщения и в любое удобное для Вас время производить рассылки SMS. После отправки вы получаете оповещения о принятых и обработанных сообщениях.</span></span></p>\n<h2 style=\"text-align: right;\">\n	<a href=\"http://world-sms.ru/buy\"><img alt=\"\" class=\"button\" src=\"/upload/Buy_SMS.png\" style=\"width: 256px; height: 100px;\" /></a></h2>\n<h2 align=\"center\">\n	<span style=\"font-size:22px;\"><span style=\"font-family: times new roman,times,serif;\"><strong>Платные </strong><strong>Zip</strong><strong>-архивы</strong></span></span></h2>\n<p>\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Это сервис позволяющий заработать на Ваших файлах. Перед распаковкой архива пользователю предлагается отправить SMS.&nbsp; В ответном SMS пользователь получает уникальный ключ, а Вы получаете сумму, которую указали в настройках. При помощи этого ключа, пользователь может распаковать архив. Приемущество данного метода заключается в том, что не нужен устанавливать на Ваш сатй дополнительные программы. Любой пользователь Интернета может выступать как в качестве покупателя, так и в качестве продавца.</span></span></p>\n<h2 align=\"center\">\n	<span style=\"font-size:22px;\"><span style=\"font-family: times new roman,times,serif;\">&nbsp;<strong>SMS биллинг</strong></span></span></h2>\n<p>\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">SMS биллинг &ndash; система оплаты для сайтов при помощи SMS сообщений с уникальным текстом на короткий сервисный номер. С биллинговой системой &nbsp;возможно приобретать в интернете любые товары и оплачивать услуги. Это удобный и быстрый способ получения товара или услуги.</span></span></p>`, `index`, `Главная страница`, ``, `Главная страница`, ``, ``, `Владимир`, `6342`, `1354206321`);
INSERT INTO `sms_statics` VALUES(`39`, `Туристические компании`, `<h3>\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\"><strong>Сделайте свою компанию самой успешной в городе!</strong></span></span></h3>\n<p>\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Подключив услугу рассылки SMS сообщений Вы сможете информировать клиентов в любое удобное время, при этом можно быть уверенным что сообщение будет прочитано. А благодаря бесплатной услуге подмены номера клиенты всегда будут знать от кого им пришло сообщение. Регулярно получая SMS с разнообразными предложениями туров в разные страны, Ваши клиенты смогут определиться с местом отдыха. Получить заманчивое сообщение с предложением поехать отдохнуть, если вдруг появляется неожиданный отпуск, может быть очень кстати.</span></span></p>\n<p>\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\"><strong>В каких случаях делают рассылку</strong></span></span></p>\n<ul>\n	<li>\n		<span style=\"font-size: 18px;\"><span style=\"font-family: times new roman,times,serif;\">Предложение горящих туров</span></span></li>\n</ul>\n<p style=\"margin-left:18.0pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Можно соблазниться возможностью отдохнуть в другом городе или стране после напряженного месяца работы, ведь так часто хочется бросить все и уехать отдыхать.</span></span></p>\n<ul>\n	<li>\n		<span style=\"font-size: 18px;\"><span style=\"font-family: times new roman,times,serif;\">Напоминание и подтверждение даты отправления</span></span></li>\n</ul>\n<p style=\"margin-left:18.0pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">В повседневной суете можно забыть о том что скоро нужно уезжать. В этой ситуации очень актуально своевременное напоминание о дате и времени выезда. Клиентам не нужно будет несколько раз звонить и уточнять когда состоится выезд, если вдруг они забудут время отправления.</span></span></p>\n<ul>\n	<li value=\"5\">\n		<span style=\"font-size: 18px;\"><span style=\"font-family: times new roman,times,serif;\">Оповещение об изменении расписания</span></span></li>\n</ul>\n<p style=\"margin-left:18.0pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Погодные условия и человеческий фактор могут повлиять изменения в расписании. Заранее получив уведомление клиент не будет волноваться и при необходимости сможет скорректировать свои планы.</span></span></p>\n<ul>\n	<li value=\"5\">\n		<span style=\"font-size: 18px;\"><span style=\"font-family: times new roman,times,serif;\">Скидки по SMS</span></span></li>\n</ul>\n<p style=\"margin-left:18.0pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Оригинальной услугой является рассылка электронных купонов со скидками. Такой купон нельзя потерять, он всегда с собой в телефоне. Это очень удобно и актуально в век цифровых технологий.</span></span></p>\n<ul>\n	<li value=\"5\">\n		<span style=\"font-size: 18px;\"><span style=\"font-family: times new roman,times,serif;\">Уведомление о завершении оформления документов</span></span></li>\n</ul>\n<p style=\"margin-left:18.0pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Волнение туристов по поводу хода оформления документов естественно, поэтому своевременное уведомление о ходе дел будет очень приятно каждому.</span></span></p>\n<ul>\n	<li value=\"5\">\n		<span style=\"font-size: 18px;\"><span style=\"font-family: times new roman,times,serif;\">Розыгрыши призов</span></span></li>\n</ul>\n<p style=\"margin-left:18.0pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">По окончании сезона массовых путешествий можно провести лотерею, на которую можно пригласить через SMS рассылку отдохнувших в этом году клиентов.</span></span></p>\n<ul>\n	<li value=\"5\">\n		<span style=\"font-size: 18px;\"><span style=\"font-family: times new roman,times,serif;\">Поздравления</span></span></li>\n</ul>\n<p style=\"margin-left:18.0pt;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Ваши клиенты будут видеть что они важны, о них помнят и уделяют внимание.</span></span></p>\n<p style=\"margin-left: 18pt; text-align: right;\">\n	<a href=\"http://world-sms.ru/buy\"><img alt=\"\" class=\"button\" src=\"/upload/Buy_SMS.png\" style=\"width: 256px; height: 100px;\" /></a></p>`, `touristcompany`, `Туристические компании`, `world sms, смс рассылка	, рассылка, уведомление	, клиенты, сообщение, сервис`, `Раздел для туристических компаний`, ``, ``, `Владимир`, `120`, `1354290739`);
INSERT INTO `sms_statics` VALUES(`40`, `Платные Zip-архивы`, `<h2 align=\"center\">\n	<span style=\"font-size:22px;\"><span style=\"font-family: times new roman,times,serif;\"><strong>Платные </strong><strong>Zip</strong><strong> архивы</strong></span></span></h2>\n<p>\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Подходит для тех, кто хочет продавать цифровой контент после доставки его клиенту. Теперь Ваши клиенты смогут убедиться в наличии файла, оценить размер и расширение, и только потом осуществить оплату. Все как в обычном магазине, сначала выбираешь товар, а затем платишь за него. Доверие к покупаемому товару будет выше, когда человек видит то что покупает. Любой пользователь сети интернет может стать как продавцом, так и покупателем.</span></span></p>\n<h2 align=\"center\">\n	<span style=\"font-size:22px;\"><span style=\"font-family: times new roman,times,serif;\"><strong>Как это работает?</strong></span></span></h2>\n<p style=\"text-align: center;\">\n	<img alt=\"\" src=\"/upload/SMSZIP_full.png\" style=\"width: 947px; height: 202px;\" /></p>\n<p>\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">В архив Вы можете помещать как один файл или папку, так и несколько. Размер создаваемого архива не ограничен. Архивы можно размещать на своем сайте, любом бесплатном хостинге, файлообменниках.</span></span></p>\n<p>\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Клиент скачивает нужный ему архив, проверяет размер, расширение нужного файла или файлов. При распаковке архива на экране монитора появляется окошко, в котором указан номер телефона и стоимость SMS сообщения. Деньги за каждый распакованный архив зачисляются на Вас счет в личном кабинете. Выплаты производятся каждую неделю по пятницам за предыдущую неделю (т. е. с понедельника по воскресенье).</span></span></p>\n<h2 align=\"center\">\n	<span style=\"font-size:22px;\"><span style=\"font-family: times new roman,times,serif;\"><strong>Как указывать стоимость архива?</strong></span></span></h2>\n<p>\n	&nbsp;</p>\n<h2 align=\"center\">\n	<span style=\"font-size:22px;\"><span style=\"font-family: times new roman,times,serif;\"><strong>Запрещается!</strong></span></span></h2>\n<p>\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Запрещается продажа архивов с детским порно, zoo, rape. Также запрещена продажа файлов не соответствующих заявленному в описании, многократная архивация файлов и т. п. При обнаружении такие архивы будут сразу же удалены, аккаунт пользователя заблокирован вместе со всеми заработанными средствами. Кроме того, данные этого пользователя будут переданы в правоохранительные органы.</span></span></p>\n<p>\n	&nbsp;</p>\n<p>\n	&nbsp;</p>\n<p style=\"text-align: center;\">\n	&nbsp;</p>`, `sms_zip_about`, `Платные Zip-архивы`, `world sms, смс рассылка	, zip архивы, рассылка, сервис, архив`, `Раздел Zip-архивов`, ``, ``, `Владимир`, `116`, `1354463403`);
INSERT INTO `sms_statics` VALUES(`41`, `SMS биллинг`, `<p style=\"text-align: justify;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">SMS биллинг &ndash; система оплаты для сайтов при помощи SMS сообщений с уникальным текстом на короткий сервисный номер. С биллинговой системой &nbsp;возможно приобретать в интернете любые товары и оплачивать услуги. Это удобный и быстрый способ получения товара или услуги.</span></span></p>\n<h2 align=\"center\">\n	<span style=\"font-size:22px;\"><span style=\"font-family: times new roman,times,serif;\"><strong>Как работает </strong><strong>SMS</strong><strong> биллинг</strong></span></span></h2>\n<p align=\"center\">\n	<span style=\"font-size: 22px;\"><span style=\"font-family: times new roman,times,serif;\"><strong><img alt=\"\" src=\"/upload/billing_full.png\" style=\"width: 850px; height: 213px;\" /></strong></span></span></p>\n<p style=\"text-align: justify;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">SMS биллинг работает аналогично банку. В Вашем личном кабинете есть виртуальный счет, на который идут все платежи за использование услуг или покупок вашего товара. Благодаря этому не нужно тратить время на обработку каждого платежа, они все прохидят на ваш лицевой счет.</span></span></p>\n<p style=\"text-align: justify;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Клиент, заинтересовавшийся Вашим товаром или услугой на сайте, отправляет SMS на короткий номер, указанный на сайте, с указанным текстом, прикрепленному к этому конкретному товару или услуге. Со счета клиента снимается указанная сумма, после чего он получает отплаченный товар или услугу. Иначе говоря, клиент выполняет любые электронные платежи через SMS, при этом ему не надо пользоваться специальными электронными платежными системами. Стоимость оплаты через SMS выше обычных тарифов операторов связи и лежит в пределах от 3 до 300 рублей, в зависимости от выбранного Вами короткого номера. После вычета комиссии сотовым оператором и сервисом world-sms.ru, сумма переходит на Ваш счет.</span></span></p>\n<h2 align=\"center\">\n	<span style=\"font-size:22px;\"><span style=\"font-family: times new roman,times,serif;\"><strong>Сферы применения </strong><strong>SMS</strong><strong> биллинга</strong></span></span></h2>\n<ul>\n	<li>\n		<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Интернет магазины и WEB-сайты</span></span></li>\n	<li>\n		<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Развлекательные клубы, кафе, рестораны</span></span></li>\n	<li>\n		<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Фитнес центры, спортивные залы</span></span></li>\n	<li>\n		<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Банки</span></span></li>\n	<li>\n		<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Лечебные учреждения</span></span></li>\n	<li>\n		<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">IT компании</span></span></li>\n	<li>\n		<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Издательства</span></span></li>\n	<li>\n		<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Интернет-провайдеры</span></span></li>\n	<li>\n		<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Рекламные агентства</span></span></li>\n	<li>\n		<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Страховые компании</span></span></li>\n	<li>\n		<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Коллекторский бизнес</span></span></li>\n	<li>\n		<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Маркетинговые акции</span></span></li>\n	<li>\n		<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Логистика</span></span></li>\n	<li>\n		<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Социальные сети</span></span></li>\n	<li>\n		<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Коммунальные услуги</span></span></li>\n	<li>\n		<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Туристические компании и туроператоры</span></span></li>\n	<li>\n		<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Сайты знакомств</span></span></li>\n	<li>\n		<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Образование и учебные заведения</span></span></li>\n	<li>\n		<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Радио и Телевидение</span></span></li>\n	<li>\n		<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">SMS-чаты, SMS-игры, SMS-голосования</span></span></li>\n	<li>\n		<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Онлайн игры</span></span></li>\n	<li>\n		<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Аукционы, викторины</span></span></li>\n	<li>\n		<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Партнерские программы</span></span></li>\n	<li>\n		<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Размещение информации на форумах и досках объявлений</span></span></li>\n	<li>\n		<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Информационные услуги для мобильных телефонов</span></span></li>\n	<li>\n		<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Букмекерские конторы для внесения ставок с оплатой через SMS</span></span></li>\n</ul>\n<h2 align=\"center\">\n	<span style=\"font-size:22px;\"><span style=\"font-family: times new roman,times,serif;\"><strong>Выплаты по </strong><strong>SMS</strong> <strong>биллингу</strong></span></span></h2>\n<p style=\"text-align: justify;\">\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Для того чтобы получать выплаты, в личном кабинете вам нужно указать свой WMR кошелек системы WebMoney. Выплаты производятся еженедельно среда-пятница за предыдующую неделю после сверки фродов по курсу ЦБ РФ на последний день отчетного периода. Для того чтобы сменить номер рублевого кошелька в системе WebMoney необходимо отправить письмо в службу технической поддержки.</span></span></p>`, `billing`, `SMS биллинг`, `world sms, смс рассылка, sms биллинг, world sms ru, услуги, биллинг, рассылка, выплаты, сервис`, `Раздел биллинга`, ``, ``, `Владимир`, `100`, `1354463564`);
INSERT INTO `sms_statics` VALUES(`42`, `SMS рассылки`, `<h2 style=\"text-align: right;\">\n	<a href=\"http://world-sms.ru/buy\"><img alt=\"\" class=\"button\" src=\"/upload/Buy_SMS.png\" style=\"width: 256px; height: 100px;\" /></a></h2>\n<h2 align=\"center\">\n	<span style=\"font-size:22px;\"><span style=\"font-family: times new roman,times,serif;\">Массовая рассылка SMS сообщений по Вашей базе клиентов</span></span></h2>\n<p>\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">&nbsp;&nbsp;Сервис WORLD-SMS позволяет массово рассылать SMS сообщения из личного кабинета на нашем сайте. Для этого необходимо только <a href=\"register\">зарегистрироваться</a>, загрузить свою базу номеров, составить текст сообщения и в любое удобное для Вас время производить рассылки SMS. После отправки вы получаете оповещения о принятых и обработанных сообщениях.</span></span></p>\n<p style=\"text-align: center;\">\n	<img alt=\"\" src=\"/upload/sms_full.png\" style=\"width: 947px; height: 242px;\" /></p>\n<p>\n	<span style=\"font-size:18px;\">&nbsp;<span style=\"font-family: times new roman,times,serif;\">&nbsp;<strong>Информация &ndash; это деньги</strong>. Это уже осознало множество компаний, пользующихся мобильным маркетингом для увеличения лояльности каждого отдельно взятого клиента и как следствие, своей прибыли. Донесение информации до клиента тратя как можно меньше времени, сил и денег важнейшая задача, которую позволяет решить наш SMS сервис.</span></span></p>\n<p>\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">&nbsp;&nbsp;<strong>Произвольный обратный адрес.</strong> При рассылке SMS обратный адрес может быть любым &ndash; ваш номер телефона, название компании, электронный адрес и т.д.</span></span></p>\n<p>\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">&nbsp;&nbsp;Вспомните сколько рекламы вы видели сегодня на улице, в магазинах, маршрутных такси, троллейбусах? Теперь вспомните сколько из всей этой рекламы вы запомнили? Наверняка совсем немного. Если вы спросите об этом у своих знакомых, то результат будет тем же. А теперь вспомните, как часто вы покупаете что-либо увидев наружную рекламу? Думаю что тоже не очень много раз. Вывод: такая реклама <strong>не работает!</strong> Решение в такой ситуации просто: нужно сделать так, чтобы информация о Вас доходила до каждого клиента <strong>индивидуально</strong>. Именно этого и помогает добиться сервис WORLD-SMS по средствам рассылки SMS сообщений. Это дешевый и в тоже время продуктивный способ донести информацию до клиентов.</span></span></p>\n<p>\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">&nbsp;&nbsp;WORLD-SMS создан для умного и современного бизнеса. Сегодня можно с уверенностью сказать что <strong>будущее за </strong><strong>SMS</strong><strong> рассылками!</strong></span></span></p>\n<p>\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">&nbsp;&nbsp;SMS рассылка производится на любые номера операторов МТС, Билайн, Мегафон, Теле 2 и многих других.</span></span></p>\n<h2 align=\"center\">\n	<span style=\"font-size:22px;\"><span style=\"font-family: times new roman,times,serif;\"><strong>SMS сервис подходит всем!</strong></span></span></h2>\n<ul style=\"list-style-type:circle;\">\n	<li>\n		<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\"><a href=\"mlm.html\">Сетевой маркетинг</a></span></span></li>\n	<li>\n		<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\"><a href=\"avto.html\">Сервисные центры, автосалоны, автодиллеры</a></span></span></li>\n	<li>\n		<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\"><a href=\"bank.html\">Банки и кредитные организации</a></span></span></li>\n	<li>\n		<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\"><a href=\"entertainment.html\">Кафе, рестораны, ночные клубы, кинотеатры</a></span></span></li>\n	<li>\n		<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\"><a href=\"insurer.html\">Страховые компании</a></span></span></li>\n	<li>\n		<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\"><a href=\"shop.html\">Торговые сети и маленькие магазины</a></span></span></li>\n	<li>\n		<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\"><a href=\"internetcommerce.html\">Интернет торговля</a></span></span></li>\n	<li>\n		<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\"><a href=\"sport.html\">Спортивные центры и фитнес клубы</a></span></span></li>\n	<li>\n		<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\"><a href=\"interent.html\">Провайдеры связи, интернет, телевидение</a></span></span></li>\n	<li>\n		<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\"><a href=\"touristcompany.html\">Туристические компании</a></span></span></li>\n</ul>\n<p>\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">&hellip;и многое, многое другое, здесь Вас может ограничить только ваша фантазия.</span></span></p>\n<p>\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Рассылка SMS сообщений отлично подходит для коммуникации с Вашими клиентами. Делая рассылку Вы можете легко и быстро информировать клиентов о скидках, акциях, новых поступлениях товаров и различных мероприятиях. Вы можете рассказать о себе целевой аудитории, привлекать новых клиентов и увеличить продажи. Что даст именно вашему бизнесу рассылка sms сообщений решать Вам.</span></span></p>\n<h2 align=\"center\">\n	<span style=\"font-size:22px;\"><span style=\"font-family: times new roman,times,serif;\"><strong>Что Вам нужно?</strong></span></span></h2>\n<p>\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Как добиться увеличения прибыльности Вашего бизнеса на %%:</span></span></p>\n<ul type=\"1\">\n	<li>\n		<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Зарегистрироваться на сайте www.world-sms.ru</span></span></li>\n	<li>\n		<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Заранее определитесь будете ли Вы участвовать в <a href=\"partners.html\">партнерской программе</a>. Это дает возможность получить дополнительную прибыль или хотя бы просто сделать свою sms рассылку <strong>бесплатной</strong>.</span></span></li>\n	<li>\n		<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Создавать свою базу телефонных номеров клиентов.</span></span></li>\n	<li>\n		<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Составлять короткие, но емкие слоганы. Например: слоганы туристических фирм: &laquo;Тур такой-то, тогда-то, стоит столько-то&raquo;. И все, информация получена.</span></span></li>\n	<li>\n		<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Начните вести статистику насколько это работает. Через некоторое время сможете сравнить результаты до и после, увидев, помогают ли Вам и Вашему бизнесу наши предложения.</span></span></li>\n</ul>\n<p>\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Главное что при покупки пакета SMS Вы ничего не теряете, оплаченные SMS сохраняются за Вами навсегда и они дешевле чем у операторов сотовой связи. Можно &laquo;убить двух зайцев одним ударом&raquo;, а именно с одной стороны развивать свой бизнес, ценою меньших затрат, с другой получать деньги по <a href=\"partners.html\">партнерской программе</a>. Если присмотреться к окружающему миру (посмотрите в свой телефон, наверняка Вам уже приходи SMS рассылки от разных организаций), то легко заметить, что уже многие успешные бизнесмены пользуются этими возможностями, реализуя часть своей мартетинговой стратегии через SMS рассылки. В такой ситуации совершенно очевидно, что будущее за SMS рассылками. Вы можете включиться в этот процесс сейчас, пока рынок еще не так велик, при этом заняв его часть или же стоять и смотреть как ваши конкуренты забирают часть вашей прибыли. Сегодня это инновационная идея, поэтому не упускайте момент. Однажды люди могут перестать обращать внимание и на этот вид рекламы. Успейте воспользоваться возможностью SMS рассылок раньше своих конкурентов! Помните, что Ваше промедление отнимает у вас возможных клиентов и отдает их в руки конкурентов, способствуя увеличению их прибыли.</span></span></p>\n<h2 style=\"text-align: right;\">\n	<a href=\"http://world-sms.ru/buy\"><img alt=\"\" class=\"button\" src=\"/upload/Buy_SMS.png\" style=\"width: 256px; height: 100px;\" /></a></h2>`, `sms`, `SMS`, `world sms, sms рассылки, sms сообщений, рассылка sms сообщений, рассылка, сервис, рассылки, клиентов, вспомните, информация, компании, адрес, время, ре�`, `Раздел для SMS рассылок`, ``, ``, `Владимир`, `302`, `1354290918`);
INSERT INTO `sms_statics` VALUES(`43`, `Часто задаваемые вопросы FAQ`, `<h2 style=\"text-align: center;\">\n	<span style=\"font-size:20px;\"><span style=\"font-family: times new roman,times,serif;\"><strong>Как отправлять SMS?</strong></span></span></h2>\n<p>\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Для отправки SMS необходимо в личном кабинете войти во вкладку &quot;СЕРВИСЫ&quot;, нажать &quot;СМС рассылка&quot;, выбрать время рассылки (по умолчанию стоит отправка сейчас) и подпись (по умолчанию стоит подпись world-sms), далее указать название расслки и текст сообщения, добавить телефонные номера, на которые будет произведена рассылка или загрузить их из файла, нажать кнопку &quot;Отправить&quot;.</span></span></p>\n<h2 style=\"text-align: center;\">\n	<span style=\"font-size:20px;\"><span style=\"font-family: times new roman,times,serif;\"><strong>Только что зарегистрировался, и в самом верху написано &quot;Количество SMS: 3&quot; баланс 0 руб. откуда эти смс?</strong></span></span></h2>\n<p>\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Это бонус по SMS-рассылкам, пробные 3 SMS.</span></span></p>\n<h2 align=\"center\">\n	<span style=\"font-size:20px;\"><span style=\"font-family: times new roman,times,serif;\">Как я могу управлять своими рассылками?</span></span></h2>\n<p>\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Вы можете задавать дату и время отправки SMS сообщения.</span></span></p>\n<h2 align=\"center\">\n	<span style=\"font-size:20px;\"><span style=\"font-family: times new roman,times,serif;\">Обязательно ли заполнять все поля в телефонной книге для того чтобы можно было отправлять сообщения?</span></span></h2>\n<p>\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Для отправки сообщения не обязательно заполнять все поля, достаточно заполнить только номер мобильного телефона, состоящий из 11 цифр (например, 79123456789) и имя абонента. Остальные поля нужны для удобства Вашей работы с телефонным справочником.</span></span></p>\n<h2 align=\"center\">\n	<span style=\"font-size:20px;\"><span style=\"font-family: times new roman,times,serif;\"><strong>В какие регионы можно отправлять </strong><strong>SMS</strong> <strong>сообщения и как зависит от этого цена?</strong></span></span></h2>\n<p>\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Вы можете отправлять сообщения в любой регион РФ. Цена не зависит от того в какой регион Вы отправляете сообщение.</span></span></p>\n<h2 align=\"center\">\n	<span style=\"font-size:20px;\"><span style=\"font-family: times new roman,times,serif;\">Кому мне можно отправлять SMS сообщения?</span></span></h2>\n<p>\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">В соответствии с законом о рекламе, сообщения можно отправлять только абонентам, которые дали согласие на получение от Вас SMS сообщений. В этом случае отправляемые Вами сообщения не являются спамом.</span></span></p>\n<h2 align=\"center\">\n	<span style=\"font-size:20px;\"><span style=\"font-family: times new roman,times,serif;\"><strong>Смогут ли получатели </strong><strong>SMS</strong> <strong>сообщений отправлять мне ответные </strong><strong>SMS</strong><strong>?</strong></span></span></h2>\n<p>\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Смогут, но лишь в том случае если в поле &laquo;Подпись к SMS&raquo; Вы укажете свой номер телефона. Если же в этом поле Вы указываете буквенный номер, то Вы ответить не смогут.</span></span></p>\n<h2 align=\"center\">\n	<span style=\"font-size:20px;\"><span style=\"font-family: times new roman,times,serif;\"><strong>Я не помню свои логин и пароль, что делать?</strong></span></span></h2>\n<p>\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Вам нужно отправить email со своего почтового ящика в техническую поддержку <a href=\"mailto:support@world-sms.ru\">support@world-sms.ru</a>. В письме укажите примерную или точную дату регистрации, а также все личные данные которые указаны в вашем аккаунте. После сверки полученной от Вас информации мы вышлем новый пароль на почтовый ящик, указанный Вами при регистрации.</span></span></p>\n<h2 align=\"center\">\n	<span style=\"font-size:20px;\"><span style=\"font-family: times new roman,times,serif;\"><strong>Какое максимальное количество символов в </strong><strong>SMS</strong> <strong>сообщени?</strong></span></span></h2>\n<p>\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">70 символов кириллицей или 160 символов латиницей. Более длинные SMS сообщения разбиваются на части по 67 (кириллицей) и 153 (латиницей) символа, после чего склеиваются на телефоне получателя в единое сообщений. Оплата длинного SMS сообщения складывается из числа отправленных частей.</span></span></p>\n<h2 align=\"center\">\n	<span style=\"font-size:20px;\"><span style=\"font-family: times new roman,times,serif;\"><strong>Сколько времени будут хранить купленные мною </strong><strong>SMS</strong><strong>?</strong></span></span></h2>\n<p>\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">Срок хранения купленных Вами SMS не ограничен.</span></span></p>\n<h2 style=\"text-align: center;\">\n	<span style=\"font-size:20px;\"><span style=\"font-family: times new roman,times,serif;\"><strong>Где мне можно посмотреть свою индивидуальную ссылку для партнерской программы?</strong></span></span></h2>\n<p>\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">В лично кабинете, во вклдке &quot;ПАРТНЕРЫ&quot;.</span></span></p>`, `faq`, `Часто задаваемые вопросы FAQ`, `world sms, sms сообщения, смс рассылка, отправлять sms, сообщения, отправлять, рассылка, подпись, сервис`, `Раздел FAQ`, ``, ``, `Владимир`, `99`, `1354463739`);
INSERT INTO `sms_statics` VALUES(`44`, `Тарифы SMS рассылки`, `<table align=\"center\" border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"width: 500px\">\n	<tbody>\n		<tr>\n			<td style=\"text-align: center\">\n				<span style=\"font-family:times new roman,times,serif;\"><span style=\"font-size: 18px;\"><b>Услуга</b></span></span></td>\n			<td style=\"text-align: center\">\n				<span style=\"font-family:times new roman,times,serif;\"><span style=\"font-size: 18px;\"><b>Цена Руб.</b></span></span></td>\n		</tr>\n		<tr>\n			<td>\n				<span style=\"font-family:times new roman,times,serif;\"><span style=\"font-size: 18px;\">Подключение</span></span></td>\n			<td style=\"text-align: center\">\n				<span style=\"font-family:times new roman,times,serif;\"><span style=\"font-size: 18px;\">0</span></span></td>\n		</tr>\n		<tr>\n			<td>\n				<span style=\"font-family:times new roman,times,serif;\"><span style=\"font-size: 18px;\">Выбор подписи отправителя</span></span></td>\n			<td style=\"text-align: center\">\n				<span style=\"font-family:times new roman,times,serif;\"><span style=\"font-size: 18px;\">0</span></span></td>\n		</tr>\n		<tr>\n			<td>\n				<span style=\"font-family:times new roman,times,serif;\"><span style=\"font-size: 18px;\">Абонентская плата</span></span></td>\n			<td style=\"text-align: center\">\n				<span style=\"font-family:times new roman,times,serif;\"><span style=\"font-size: 18px;\">0</span></span></td>\n		</tr>\n		<tr>\n			<td>\n				<span style=\"font-family:times new roman,times,serif;\"><span style=\"font-size: 18px;\">Отчет о доставке</span></span></td>\n			<td style=\"text-align: center\">\n				<span style=\"font-family:times new roman,times,serif;\"><span style=\"font-size: 18px;\">0</span></span></td>\n		</tr>\n	</tbody>\n</table>\n<p>\n	<span style=\"font-family:times new roman,times,serif;\"><span style=\"font-size: 18px;\">Срок действия приобретенного объёма SMS сообщений <b>неограничен</b>.</span></span></p>\n<h2 style=\"text-align: center;\">\n	<span style=\"font-size:22px;\"><span style=\"font-family: times new roman,times,serif;\"><strong>Отправка SMS сообщений по России</strong></span></span></h2>\n<div align=\"center\">\n	<table border=\"1\" cellpadding=\"0\" cellspacing=\"2\" id=\"tarif\" style=\"text-align: center; width: 90%;\">\n		<thead>\n			<tr>\n				<td>\n					<span style=\"font-family:times new roman,times,serif;\"><span style=\"font-size: 18px;\"><b>Объём SMS пакета</b></span></span></td>\n				<td>\n					<span style=\"font-family:times new roman,times,serif;\"><span style=\"font-size: 18px;\"><b>Цена 1 SMS c учетом НДС</b></span></span></td>\n			</tr>\n		</thead>\n		<tbody>\n		</tbody>\n	</table>\n</div>\n<script type=\"text/javascript\">\n$.getJSON( \"http://world-sms.ru/json.php?callback=?\", {\'mod\': \'buy\' }, function(data) {\n   $(\'#tarif tbody\').html(data.html);\n});\n</script>`, `tarifssms`, ``, ``, ``, ``, ``, ``, `156`, `1351268967`);
INSERT INTO `sms_statics` VALUES(`45`, `Тарифы SMS биллинга`, `<p>\n	<span style=\"font-size:24px;\"><strong><span style=\"font-family:times new roman,times,serif;\">Страница находится в разработке</span></strong></span></p>\n`, `tarifsbilling`, ``, ``, ``, ``, ``, ``, `87`, `1351268220`);
INSERT INTO `sms_statics` VALUES(`46`, `Тарифы Zip-архивов`, `<p>\n	<span style=\"font-size:24px;\"><strong><span style=\"font-family:times new roman,times,serif;\">Страница находится в разработке</span></strong></span></p>\n`, `tarifszip`, ``, ``, ``, ``, ``, ``, `51`, `1351268232`);
INSERT INTO `sms_statics` VALUES(`49`, `Страховые компании`, `<p>\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\">На данный момент существует множество страховых компаний, поэтому выбрать одну для себя зачастую непросто. Стоимость услуг не всегда становится решающим фактором выбора. В современном мире на первое место выходит комфорт и &nbsp;уровень обслуживания. Это и определяет выбор той или иной компании. В наше время самую большую ценность представляет <strong>информация</strong>. Поэтому высокого уровня обслуживания можно добиться предоставлением оперативной информации, способной упростить жизнь и избежать лишних проблем.</span></span></p>\n<h3>\n	<span style=\"font-size:18px;\"><span style=\"font-family: times new roman,times,serif;\"><strong>Какую информацию хотят получать Ваши клиенты?</strong></span></span></h3>\n<ul>\n	<li>\n		<span style=\"font-family: times new roman,times,serif;\"><span style=\"font-size: 18px;\">Оповещение о сроке истечения действия страхового полиса</span></span></li>\n	<li>\n		<span style=\"font-family: times new roman,times,serif;\"><span style=\"font-size: 18px;\">Оповещение о появлении новых услуг и акций</span></span></li>\n	<li>\n		<span style=\"font-family: times new roman,times,serif;\"><span style=\"font-size: 18px;\">Оповещение о выплате страховки</span></span></li>\n	<li>\n		<span style=\"font-family: times new roman,times,serif;\"><span style=\"font-size: 18px;\">Оповещение о необходимости пролонгации договора</span></span></li>\n	<li>\n		<span style=\"font-family: times new roman,times,serif;\"><span style=\"font-size: 18px;\">Оповещение о поступлении денег в кассу</span></span></li>\n	<li>\n		<span style=\"font-family: times new roman,times,serif;\"><span style=\"font-size: 18px;\">Оповещение о приближении срока платежа</span></span></li>\n	<li>\n		<span style=\"font-family: times new roman,times,serif;\"><span style=\"font-size: 18px;\">Оповещение о том на каком этапе рассмотрения находится страховой случай</span></span></li>\n</ul>\n<p style=\"text-align: right;\">\n	<a href=\"http://world-sms.ru/buy\"><img alt=\"\" class=\"button\" src=\"/upload/Buy_SMS.png\" style=\"width: 256px; height: 100px;\" /></a></p>`, `insurer`, `Страховые компании`, `world sms, смс рассылка, рассылка, сервис, оповещение, компании`, `Раздел для страховых компаний`, ``, ``, `Владимир`, `9`, `1354290484`);
CREATE TABLE `sms_statistica_two` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `packetid` int(11) NOT NULL,
  `packettitle` varchar(255) NOT NULL,
  `createtime` int(11) NOT NULL,
  `sendtime` int(11) NOT NULL,
  `statustime` int(11) NOT NULL,
  `status` varchar(2) NOT NULL,
  `phone` varchar(16) NOT NULL,
  `sender` varchar(16) NOT NULL,
  `message` text NOT NULL,
  `parts` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1

INSERT INTO `sms_statistica_two` VALUES(`1`, `1`, `64930`, `ntcn`, `1353755394`, `1353755394`, `1353755403`, `3`, `79511075989`, `89209612875`, `ntтесвуп%%:*((*№\"№4`, `1`);
INSERT INTO `sms_statistica_two` VALUES(`2`, `5`, `14555`, `Рассылка-892`, `1353911975`, `1353911975`, `1353911983`, `3`, `79209908877`, `89209747774`, `Поздравляю с Днем Рождения!Счастья в жизни,успехов,удачи!(твоя склерозница)`, `2`);
INSERT INTO `sms_statistica_two` VALUES(`3`, `5`, `48045`, `Рассылка-693`, `1353911995`, `1353911995`, `1353911999`, `2`, `79209747774`, `89209747774`, `Поздравляю с Днем Рождения!Счастья в жизни,успехов,удачи!(твоя склерозница)`, `2`);
INSERT INTO `sms_statistica_two` VALUES(`4`, `1`, `4160`, `тестовая`, `1353941422`, `1353941422`, `1353941433`, `3`, `79511075989`, `2sms`, `2sms`, `1`);
INSERT INTO `sms_statistica_two` VALUES(`5`, `1`, `4160`, `тестовая`, `1353941422`, `1353941422`, `1353941431`, `3`, `79065483577`, `2sms`, `2sms`, `1`);
INSERT INTO `sms_statistica_two` VALUES(`6`, `70`, `94822`, `Рассылка-351`, `1354161846`, `1354161846`, `1354161850`, `2`, `79134991901`, `world-sms`, `ИНВЕСТИЦИИ 15-20% В МЕСЯЦ https://landora-investing.com/?ref=vitiaz `, `1`);
INSERT INTO `sms_statistica_two` VALUES(`7`, `70`, `94822`, `Рассылка-351`, `1354161846`, `1354161846`, `1354161858`, `3`, `79134991902`, `world-sms`, `ИНВЕСТИЦИИ 15-20% В МЕСЯЦ https://landora-investing.com/?ref=vitiaz `, `1`);
INSERT INTO `sms_statistica_two` VALUES(`8`, `70`, `94822`, `Рассылка-351`, `1354161846`, `1354161846`, `1354161859`, `3`, `79135318510`, `world-sms`, `ИНВЕСТИЦИИ 15-20% В МЕСЯЦ https://landora-investing.com/?ref=vitiaz `, `1`);
INSERT INTO `sms_statistica_two` VALUES(`9`, `70`, `94822`, `Рассылка-351`, `1354161846`, `1354161846`, `1354161856`, `3`, `79134991906`, `world-sms`, `ИНВЕСТИЦИИ 15-20% В МЕСЯЦ https://landora-investing.com/?ref=vitiaz `, `1`);
INSERT INTO `sms_statistica_two` VALUES(`10`, `1`, `72248`, `Рассылка-824`, `1354199287`, `1354199287`, `1354199299`, `3`, `79511075989`, `world-sms`, `тест по впемени 1`, `1`);
CREATE TABLE `sms_tariffs_two` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `count` int(11) NOT NULL,
  `cost` float(20,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10006 DEFAULT CHARSET=utf8

INSERT INTO `sms_tariffs_two` VALUES(`1`, `501`, `0.60`);
INSERT INTO `sms_tariffs_two` VALUES(`2`, `1001`, `0.55`);
INSERT INTO `sms_tariffs_two` VALUES(`3`, `5001`, `0.50`);
INSERT INTO `sms_tariffs_two` VALUES(`4`, `10001`, `0.40`);
INSERT INTO `sms_tariffs_two` VALUES(`10002`, `50001`, `0.35`);
INSERT INTO `sms_tariffs_two` VALUES(`10003`, `100001`, `0.30`);
INSERT INTO `sms_tariffs_two` VALUES(`10004`, `500001`, `0.27`);
INSERT INTO `sms_tariffs_two` VALUES(`10005`, `1000001`, `0.25`);
CREATE TABLE `sms_ticket` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `text` text NOT NULL,
  `retext` text NOT NULL,
  `retime` int(11) NOT NULL,
  `author` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1

CREATE TABLE `sms_transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `amount` float(11,2) NOT NULL,
  `service` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `direct` varchar(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1

INSERT INTO `sms_transactions` VALUES(`1`, `6`, `1353949268`, `-0.60`, ``, ``, `Покупка 1 смс`, ``);
INSERT INTO `sms_transactions` VALUES(`2`, `6`, `1353949351`, `-550.00`, ``, ``, `Покупка 1000 смс`, ``);
INSERT INTO `sms_transactions` VALUES(`3`, `70`, `1354161226`, `0.00`, ``, `Регистрация`, `Подарочные 3 смс`, ``);
INSERT INTO `sms_transactions` VALUES(`4`, `1`, `1354205370`, `99.30`, ``, ``, ``, `pay`);
INSERT INTO `sms_transactions` VALUES(`5`, `71`, `1354843107`, `0.00`, ``, ``, `Подарочные 3 смс`, `buy`);
CREATE TABLE `sms_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `password` varchar(32) NOT NULL,
  `session` varchar(32) NOT NULL,
  `sestime` int(11) NOT NULL,
  `regtime` int(11) NOT NULL,
  `regip` varchar(255) NOT NULL,
  `lasttime` int(11) NOT NULL,
  `lostlink` varchar(32) NOT NULL,
  `losttime` int(11) NOT NULL,
  `balance` float(11,2) NOT NULL DEFAULT '0.00',
  `sms` int(11) NOT NULL,
  `nameone` varchar(255) NOT NULL,
  `nametwo` varchar(255) NOT NULL,
  `phone` varchar(16) NOT NULL,
  `purse` varchar(13) NOT NULL,
  `icq` varchar(12) NOT NULL,
  `skype` varchar(60) NOT NULL,
  `code` varchar(10) NOT NULL,
  `uptime` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=latin1

INSERT INTO `sms_users` VALUES(`1`, `kr0n4ik@mail.ru`, `dfa35fd0b47e5f4181ed1732cb232537`, ``, `1359481153`, `1335095060`, `91.203.67.49`, `1354297153`, ``, `0`, `0.00`, `0`, `Пименов`, `Сергей`, `79209632904`, `r123456789012`, ``, ``, ``, `1354549535`);
INSERT INTO `sms_users` VALUES(`5`, `aniretake_fire@mail.ru`, `dbcde272d111881b041d1032ac960481`, `33e7d77f2904c81f02645fafd3958992`, `1359095727`, `1335202322`, `176.96.246.115`, `1353911727`, ``, `0`, `0.00`, `37`, `Власова`, `Екатерина`, `79209747774`, `r706236362741`, ``, ``, ``, `1353911733`);
INSERT INTO `sms_users` VALUES(`6`, `volodia-starosta@mail.ru`, `5548d2bb978ed840d14d03625917dada`, `7415b7889513381433440b6df535886c`, `1359042064`, `0`, ``, `1353858064`, ``, `0`, `0.00`, `10`, `Белокуров`, `Владимир`, `79605723943`, `r184784330860`, ``, ``, ``, `1354463760`);
INSERT INTO `sms_users` VALUES(`8`, `director358@mail.ru`, `3e31bf26d8c870c4f58f7d8e99fe1217`, `0e0a2cd034fe76556b631a032a137de6`, `1335380195`, `1335292708`, `31.148.34.233`, `1335293795`, ``, `0`, `0.00`, `3`, `Krasavtsev`, `Alex`, `79053440274`, `r201142776375`, `46705590`, ``, ``, `0`);
INSERT INTO `sms_users` VALUES(`9`, `lyalechka-koks@mail.ru`, `1408b534d04595db08c64af164aaffc7`, ``, `0`, `1335790166`, `95.83.190.72`, `0`, ``, `0`, `0.00`, `3`, ``, ``, ``, ``, ``, ``, ``, `0`);
INSERT INTO `sms_users` VALUES(`11`, `saanyaa1990@mail.ru`, `52fc656caf9a57e72e1ab9957f9788c9`, ``, `0`, `1336048297`, `91.223.246.3`, `0`, ``, `0`, `0.00`, `3`, ``, ``, ``, ``, ``, ``, ``, `0`);
INSERT INTO `sms_users` VALUES(`12`, `chibisova33@ya.ru`, `500a3bfc61780e3614d876cf9c0f089e`, ``, `0`, `1336247769`, `193.19.120.237`, `0`, ``, `0`, `0.00`, `3`, ``, ``, ``, ``, ``, ``, ``, `0`);
INSERT INTO `sms_users` VALUES(`13`, `positives2008@yandex.ru`, `0c5b12834e767765c4db20141094e381`, ``, `0`, `1336369583`, `83.149.45.49`, `0`, ``, `0`, `0.00`, `3`, ``, ``, ``, ``, ``, ``, ``, `0`);
INSERT INTO `sms_users` VALUES(`14`, `anna_kustova_89@mail.ru`, `ad4a053c9341e308bfbe053a4f9087a2`, ``, `0`, `1336806608`, `46.229.140.197`, `0`, ``, `0`, `0.00`, `3`, ``, ``, ``, ``, ``, ``, ``, `0`);
INSERT INTO `sms_users` VALUES(`15`, `anna-kustova-@mail.ru`, `be3f51b4a7378359c394b2e5d01e3cf5`, ``, `0`, `1336808713`, `46.229.140.197`, `0`, ``, `0`, `0.00`, `3`, ``, ``, ``, ``, ``, ``, ``, `0`);
INSERT INTO `sms_users` VALUES(`16`, `kustova-89@mail.ru`, `be3f51b4a7378359c394b2e5d01e3cf5`, ``, `0`, `1336808807`, `46.229.140.197`, `0`, ``, `0`, `0.00`, `3`, ``, ``, ``, ``, ``, ``, ``, `0`);
INSERT INTO `sms_users` VALUES(`20`, `biomars@yandex.ru`, `3101e4fbb650cfd939e39d7fde2d923e`, `fa5a5fb6d002fc24ecbd5a6118c30eca`, `1337583600`, `1337497178`, `31.23.129.41`, `1337497200`, ``, `0`, `0.00`, `3`, ``, ``, ``, ``, ``, ``, ``, `0`);
INSERT INTO `sms_users` VALUES(`21`, `oleg.knbish@gmail.com`, `7c2c637e0a2d8be2888e838027094439`, ``, `0`, `1337552976`, `178.162.108.90`, `0`, ``, `0`, `0.00`, `3`, ``, ``, ``, ``, ``, ``, ``, `0`);
INSERT INTO `sms_users` VALUES(`22`, `kosmosekrt@gmail.com`, `6bb7d99a8ee48672d44aedfa4561d5dd`, ``, `0`, `1337609122`, `91.203.67.20`, `0`, ``, `0`, `0.00`, `3`, ``, ``, ``, ``, ``, ``, ``, `0`);
INSERT INTO `sms_users` VALUES(`23`, `igfedtigra@yandex.ru`, `2d12ae7e394c139fe7e50a0128801b5b`, `5515b4b65a7413e42d3cae53563f3a9d`, `1344726572`, `1337625594`, `213.87.134.13`, `1344640172`, ``, `0`, `0.00`, `3`, `Федоров`, `Игорь`, `79177049804`, `R805671712473`, ``, ``, ``, `0`);
INSERT INTO `sms_users` VALUES(`25`, `789.987@mail.ru`, `4a454dda213ec25eba3628d2a30b3150`, ``, `1338207654`, `1338121241`, `176.32.183.122`, `1338121254`, ``, `0`, `0.00`, `3`, ``, ``, ``, ``, ``, ``, ``, `0`);
INSERT INTO `sms_users` VALUES(`26`, `uyagan@mail.ru`, `ad89f9b845df3728c4a72e2a713b9f96`, ``, `0`, `1338247889`, `85.28.204.68`, `0`, ``, `0`, `0.00`, `3`, ``, ``, ``, ``, ``, ``, ``, `0`);
INSERT INTO `sms_users` VALUES(`27`, `paulin.k@yandex.ru`, `082ad3cd06b4efa1f6e7e52823ac8ba6`, ``, `0`, `1338718619`, `176.212.183.44`, `0`, ``, `0`, `0.00`, `3`, ``, ``, ``, ``, ``, ``, ``, `0`);
INSERT INTO `sms_users` VALUES(`28`, `irina-sidneva.ermoshina@yandex.ru`, `5b676cb60e994fb97c63c2d85e833985`, ``, `0`, `1338800835`, `85.249.113.102`, `0`, ``, `0`, `0.00`, `3`, ``, ``, ``, ``, ``, ``, ``, `0`);
INSERT INTO `sms_users` VALUES(`29`, `spartak.seredenk@rambler.ru`, `c9e26c6ce6b8625ac6761c64e3b6ff6e`, `4aef53d933cd1c24d5e1ce5ad789fb23`, `1339188477`, `1339102058`, `194.126.224.66`, `1339102077`, ``, `0`, `0.00`, `3`, ``, ``, ``, ``, ``, ``, ``, `0`);
INSERT INTO `sms_users` VALUES(`30`, `gun84@bk.ru`, `0fe6c2c9edf68eb2e6a37e45e571f50f`, `0bcf098ca4f47a651ac705f47e5c135e`, `1346744152`, `1339238718`, `92.100.176.62`, `1346657752`, ``, `0`, `0.00`, `3`, ``, `Алексей`, ``, ``, ``, ``, ``, `0`);
INSERT INTO `sms_users` VALUES(`31`, `kolya.krasny@yandex.ru`, `c1cd392b09ea6d845553742c550cc274`, `be8a583ef2e9f1e46dd2424e924a47eb`, `1339396355`, `1339309938`, `95.111.149.69`, `1339309955`, ``, `0`, `0.00`, `3`, `Красный`, `Коля`, ``, `R649661585580`, `616785169`, ``, ``, `0`);
INSERT INTO `sms_users` VALUES(`32`, `v-talisman@mail.ru`, `cba1c46758c0062bd56887776a85ed1b`, ``, `1339559455`, `1339336886`, `176.36.148.253`, `1339473055`, ``, `0`, `0.00`, `3`, `Полищук`, `Виталий`, ``, `R395846504547`, `593353272`, ``, ``, `0`);
INSERT INTO `sms_users` VALUES(`33`, `nikitenko_vitaliy@mail.ru`, `9d29e90aa793fe990a77338e6138dfe0`, `79f7b5ee051ff1c42de2226e0557d665`, `1339426008`, `1339339581`, `178.94.33.134`, `1339339608`, ``, `0`, `0.00`, `3`, `Никитенко`, `Виталий`, ``, `R526959687006`, ``, ``, ``, `0`);
INSERT INTO `sms_users` VALUES(`34`, `sgn1969@yandex.ru`, `aef9a61ddcb145ef0fc83578e059bba3`, `5d47952c7582889a7bc354016c4a9f14`, `1339427241`, `1339340752`, `93.79.155.229`, `1339340841`, ``, `0`, `0.00`, `3`, `Склярук`, `Геннадий`, ``, `R320660613927`, ``, ``, ``, `0`);
INSERT INTO `sms_users` VALUES(`35`, `vitek-y@mail.ru`, `d5dc751eed43a454a901e10c9ffa057b`, ``, `0`, `1339369576`, `213.87.132.38`, `0`, ``, `0`, `0.00`, `3`, ``, ``, ``, ``, ``, ``, ``, `0`);
INSERT INTO `sms_users` VALUES(`36`, `vch1960@gmail.com`, `e0525071bf08e07c3878bf68d28364aa`, ``, `0`, `1339388106`, `178.125.152.3`, `0`, ``, `0`, `0.00`, `3`, ``, ``, ``, ``, ``, ``, ``, `0`);
INSERT INTO `sms_users` VALUES(`37`, `yaguar_@mail.ru`, `7db12ab7624e85c9a851ee63e410f86f`, `cbb5e25307a08bf92c6c004c10e11bd8`, `1339486211`, `1339399781`, `91.203.67.111`, `1339399811`, ``, `0`, `0.00`, `3`, ``, ``, ``, ``, ``, ``, ``, `0`);
INSERT INTO `sms_users` VALUES(`38`, `solvytes@gmail.com`, `d02040bf03527bdb7524a696bb5e1ee1`, ``, `0`, `1339406101`, `84.15.188.131`, `0`, ``, `0`, `0.00`, `3`, ``, ``, ``, ``, ``, ``, ``, `0`);
INSERT INTO `sms_users` VALUES(`39`, `bodyan86@mail.ru`, `fe6ac769ab57ed09f8cdb10b670c9bf0`, ``, `0`, `1339407127`, `86.106.234.136`, `0`, ``, `0`, `0.00`, `3`, ``, ``, ``, ``, ``, ``, ``, `0`);
INSERT INTO `sms_users` VALUES(`41`, `aleks.romanovsckaja@yandex.ua`, `271c17d88143c22f2d22a03dd07f9e13`, `6f219625fcffe69507b665e63b3dfc8d`, `1340386307`, `1340299859`, `178.137.148.232`, `1340299907`, ``, `0`, `0.00`, `3`, `Romanovsckaja`, `Sacha21`, ``, ``, ``, ``, ``, `0`);
INSERT INTO `sms_users` VALUES(`42`, `sacha@yandex.ua`, `d1bae12555e0eda7d2e8e79b307cc69a`, ``, `0`, `1340313757`, `178.137.148.232`, `0`, ``, `0`, `0.00`, `3`, ``, ``, ``, ``, ``, ``, ``, `0`);
INSERT INTO `sms_users` VALUES(`45`, `info@world-sms.ru`, `4a454dda213ec25eba3628d2a30b3150`, `53a3be42612a4df6f8f4f06cbdeb7cd3`, `1340851643`, `1340765220`, `91.203.67.20`, `1340765243`, ``, `0`, `0.00`, `3`, `Пименов`, `Сергей`, `79209632904`, `R123456789012`, ``, ``, ``, `0`);
INSERT INTO `sms_users` VALUES(`46`, `makshlykov@yandex.ru`, `4f8e303bbcf1ec3ff7442e84860245be`, `509683154e75f92c8b7a1b7e3aac55f4`, `1341646790`, `1341560372`, `95.83.137.225`, `1341560390`, ``, `0`, `0.00`, `3`, `Шлыков`, `Максим`, ``, `R911495704945`, ``, ``, ``, `0`);
INSERT INTO `sms_users` VALUES(`47`, `isl4718@yandex.ru`, `630497cb8c4b7fbc75d3ed3adf8e5a9d`, ``, `1341852444`, `1341766011`, `93.185.192.69`, `1341766044`, ``, `0`, `0.00`, `3`, `М`, `И`, ``, ``, ``, ``, ``, `0`);
INSERT INTO `sms_users` VALUES(`48`, `nitass@mail.ru`, `899c9d04054e72600b553142c418e365`, `86aaa07f052df38db34d46088f4edb5f`, `1342668710`, `1342580891`, `95.188.120.177`, `1342580909`, ``, `0`, `0.00`, `3`, `Лашков`, `Сергей`, ``, `R201943283870`, ``, ``, ``, `0`);
INSERT INTO `sms_users` VALUES(`49`, `bigdadddy@yandex.ru`, `00471459d7630140165457315254de07`, `42dcc3e869f44cd33211239f20c35086`, `1342769057`, `1342682611`, `46.211.121.79`, `1342682657`, ``, `0`, `0.00`, `3`, ``, ``, ``, ``, ``, ``, ``, `0`);
INSERT INTO `sms_users` VALUES(`50`, `fedotova66@mail.ru`, `a997d1dcc2a6f6ecbeaeb917712b184c`, ``, `0`, `1342780422`, `85.115.243.104`, `0`, ``, `0`, `0.00`, `3`, ``, ``, ``, ``, ``, ``, ``, `0`);
INSERT INTO `sms_users` VALUES(`51`, `vip_romik@mail.ru`, `8d95190b316d2888f414ba55a5db8703`, ``, `0`, `1343035216`, `95.106.92.224`, `0`, ``, `0`, `0.00`, `3`, ``, ``, ``, ``, ``, ``, ``, `0`);
INSERT INTO `sms_users` VALUES(`52`, `spleyla@mail.ru`, `815b044664fea48e4d7ef1b1b53ae7c0`, `a595768e715729e4d3d5a2f428731baa`, `1344510105`, `1344423652`, `83.149.45.15`, `1344423705`, ``, `0`, `0.00`, `3`, ``, ``, ``, ``, ``, ``, ``, `0`);
INSERT INTO `sms_users` VALUES(`53`, `aqvaman@yandex.ru`, `344a069db2c65ea34e6bbc7cdb624e21`, `b4b7fd7ff7664482ac0de31d651587cc`, `1344773255`, `1344686840`, `93.120.215.56`, `1344686855`, ``, `0`, `0.00`, `3`, ``, ``, ``, ``, ``, ``, ``, `0`);
INSERT INTO `sms_users` VALUES(`54`, `moy-mail@ukr.net`, `ec98b1c192f1b818dcddaf117b7a5404`, `d03ebde8ff19ace0e0715561538e165f`, `1345460642`, `1345374180`, `93.180.211.37`, `1345374242`, ``, `0`, `0.00`, `3`, ``, ``, ``, ``, ``, ``, ``, `0`);
INSERT INTO `sms_users` VALUES(`55`, `bucenin.dima2012@mail.ru`, `5a5e58694ac37c8c6c0fb6ca3796c06e`, `f0799283db3f77d01a04939c9a9a485c`, `1346081467`, `1345844429`, `193.232.36.250`, `1345995067`, ``, `0`, `0.00`, `3`, `Буцени`, `Дима`, ``, ``, ``, `diablo676767`, ``, `0`);
INSERT INTO `sms_users` VALUES(`56`, `axiom7@rambler.ru`, `f70aef5e55aad3012568ee6852c996d2`, `792f8895be6e7a49f52c4f1a7640cb77`, `1347646245`, `1347559816`, `91.203.67.162`, `1347559845`, ``, `0`, `0.00`, `3`, `Март`, `Рина`, `79066482635`, `R752672186227`, `445626248`, ``, ``, `0`);
INSERT INTO `sms_users` VALUES(`57`, `suicide-vll@yandex.ru`, `f69b7a25659bf25bf0fd92a8ddd3ea8a`, `14dbfc8b1b3c4e5e9f1e0b597186925d`, `1348654846`, `1348568249`, `217.118.79.34`, `1348568446`, ``, `0`, `0.00`, `3`, `Вечеслав`, `Вишес`, `79659066411`, ``, ``, ``, ``, `0`);
INSERT INTO `sms_users` VALUES(`58`, `chebatova@rambler.ru`, `1d7ace74a721a0a77705238769f9f95e`, `293e5c053efc3d17f0681ad4ac759d4e`, `1348685132`, `1348598706`, `46.229.140.52`, `1348598732`, ``, `0`, `0.00`, `3`, ``, ``, ``, ``, ``, ``, ``, `0`);
INSERT INTO `sms_users` VALUES(`59`, `shvecova_natalja@rambler.ru`, `442176d3326eba54c0dab90ee07d2d08`, `a3598571954ea2c3b646f84506d135f7`, `1350019168`, `1349932746`, `46.159.72.160`, `1349932768`, ``, `0`, `0.00`, `2`, `Шуриков`, `Игнат`, ``, ``, ``, ``, ``, `0`);
INSERT INTO `sms_users` VALUES(`60`, `gmatvejj@rambler.ru`, `235a5ed13ef32efa1ff4f4e4acdd0d1d`, `a455a3021412d041c08d85875e6621bb`, `1350030096`, `1349943674`, `46.159.72.160`, `1349943696`, ``, `0`, `0.00`, `3`, ``, ``, ``, ``, ``, ``, ``, `0`);
INSERT INTO `sms_users` VALUES(`61`, `rmanskjn@rambler.ru`, `67ae684d91f2805bec54a643f587b84c`, `bd9ba39753eea81542fd164f30e0f04c`, `1350476607`, `1350390188`, `213.88.122.46`, `1350390207`, ``, `0`, `0.00`, `3`, ``, ``, ``, ``, ``, ``, ``, `0`);
INSERT INTO `sms_users` VALUES(`62`, `mcatalog@mail.ru`, `91ca2eeb2cffee506aa883d29126577b`, `afe0b9f24845f87290a3532ee571693f`, `1351338229`, `1351251821`, `109.172.40.22`, `1351251829`, ``, `0`, `0.00`, `2`, `test`, `test`, `79092220066`, ``, ``, ``, ``, `0`);
INSERT INTO `sms_users` VALUES(`63`, `littlex@list.ru`, `c2a4f2ba1f79a4fc2d7629057367b7cd`, `7d7da0d03dfa4df0f2aaeece29a311c9`, `1351372008`, `1351285455`, `178.163.9.38`, `1351285608`, ``, `0`, `0.00`, `3`, ``, ``, ``, ``, ``, ``, ``, `0`);
INSERT INTO `sms_users` VALUES(`64`, `alexei.vozmiloff@yandex.ru`, `df95031a3bf0b3e523e9ab3d8e2409c2`, `d05ac9a61890f2a50102c0dd7c587133`, `1351744881`, `1351658457`, `213.87.240.47`, `1351658481`, ``, `0`, `0.00`, `21`, `Возмилов`, `Алексей`, `79195770733`, `R976551460702`, ``, ``, ``, `0`);
INSERT INTO `sms_users` VALUES(`65`, `lisa.alisa.lisa@gmail.com`, `d576655e90665a147be724e2abca5e71`, `7e2ff6f4053dc09277eaa77f55140138`, `1353089659`, `1353003234`, `95.221.28.73`, `1353003259`, ``, `0`, `0.00`, `3`, ``, ``, ``, ``, ``, ``, ``, `0`);
INSERT INTO `sms_users` VALUES(`66`, `djrog62@ya.ru`, `2db1204f973af4306e7fb1f392819c01`, `861e1e0d5ae6c00ace3d0f1bffc6747b`, `1353669870`, `1353351087`, `176.96.224.62`, `1353583470`, ``, `0`, `0.00`, `3`, ``, ``, ``, ``, ``, ``, ``, `0`);
INSERT INTO `sms_users` VALUES(`70`, `sf.dudinka@bk.ru`, `5d6eb72a00e8abfa3dc2715cc8a85975`, `83cf3bb44113d1854948abd89f67b034`, `1359345403`, `1354161226`, `217.118.79.19`, `1354161403`, ``, `0`, `0.00`, `0`, ``, ``, ``, ``, ``, ``, `5bc3e37`, `1354163368`);
INSERT INTO `sms_users` VALUES(`71`, `baza-dann-vse@yandex.ru`, `4bf537496b6fd25b35ae6f181cdcfab8`, `fa90dd34bbaa9736b7b644029a79f5d6`, `1360027378`, `1354843107`, `128.71.166.143`, `1354843378`, ``, `0`, `0.00`, `3`, ``, ``, ``, ``, ``, ``, `750792e`, `1354843517`);
