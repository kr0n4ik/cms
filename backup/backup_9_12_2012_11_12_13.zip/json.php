<?php
#info:json.php world-sms v1.0 29.04.2012
ini_set( "error_reporting", E_ERROR );
@session_start();

#Константы
define( "SMS_JSON", true );
define( "DIR_ROOT", dirname ( __FILE__ ) );

require_once DIR_ROOT . "/config/global.cfg.php";
require_once DIR_ROOT . "/config/mysql.cfg.php";
require_once DIR_ROOT . "/kernel/classes/mysql.class.php";
require_once DIR_ROOT . "/kernel/includes/function.inc.php";

$global = array();
$global['time'] = time () + ( $config['tz'] * 60 );
$global['out'] = array( 
	'version' => "1.0", 
	'time' => microtime() 
);

$db = new db( $sql['server'], $sql['user'], $sql['password'], $sql['database'] );

#Проверка сессии
$session = ( preg_match("/^[a-z0-9]{32}$/i", $_SESSION['session'] ) ) ? $_SESSION['session'] : false;

$result = $db->query( "SELECT id, email, balance, sms, icq, skype, nameone, nametwo, phone, purse FROM " . $sql['prefix'] . "_users WHERE session = '" . $session . "' AND session<>'' AND sestime >= " . $global['time'] . ";" );
if ( $db->numrows( $result ) == 1 && !empty( $session ) ) {
	$global['user'] = $db->fetchrow( $result );
	$global['user']['loged'] = true;
}

$mod = preg_match( "/^[a-z]+$/i", $_REQUEST['mod'] ) ? $_REQUEST['mod'] : "info";
if ( file_exists( DIR_ROOT . "/kernel/modules/" . $mod . "/json.php" ) ) { include_once( DIR_ROOT . "/kernel/modules/" . $mod . "/json.php" ); }

$global['out']['time'] = microtime() - $global['out']['time'];
echo $_GET['callback'] . "(" . json_encode( $global['out'] ) . ")";
unset( $global );
?>