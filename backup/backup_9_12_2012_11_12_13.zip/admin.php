<?php
#info:admin.php world-sms v2.0 25.09.2012
@session_start();
@ob_start();
@ob_implicit_flush(0);

//ini_set( "error_reporting", E_ERROR );

define( "SMS_ADMIN", true );
define( "DIR_ROOT", dirname ( __FILE__ ) );

require_once DIR_ROOT . "/config/global.cfg.php";

$global = array( "microtime" => microtime(), 'ip' => $_SERVER['REMOTE_ADDR'], 'loged' => false );
$global['time'] = time() + ( $config['tz'] * 60 );
$PHP_SELF = $config['url_home'] . "admin.php";

require_once DIR_ROOT . "/admin/template/default.skin.php";
require_once DIR_ROOT . "/admin/init.php";

#Проверка авторизации
if ( $global['loged'] == false) {
	echologin();
	exit;
} else {
	$mod = preg_match( "/^[a-z_]+$/i", $_GET['mod'] ) ? $_GET['mod'] : "main";
	if ( file_exists( DIR_ROOT . "/admin/modules/" . $mod . ".mod.php" ) ){
		include_once ( DIR_ROOT . "/admin/modules/" . $mod . ".mod.php" );
	}
}
?>