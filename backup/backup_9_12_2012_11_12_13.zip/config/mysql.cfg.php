<?php
$sql = array(
	'user' => "root",
	
	'password' => "Er23ty4FDGer",
	
	'server' => "localhost",
	
	'database' => "zbill",
	
	'prefix' => "sms"
);
?>