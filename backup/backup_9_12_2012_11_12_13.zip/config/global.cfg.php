<?php 

$config = array (

'theme' => "default",

'url_home' => "http://world-sms.ru/",

'debug' => "yes",

'debug_code' => "0",

'tz' => "0",

'salt' => "er3e45fwsrt",

'time_session' => "1440",

'cache' => "yes",

'time_cache' => "6",

'table_rows' => "10",

'geteway_email' => "info@world-sms.ru",

'geteway_password' => "2128506",

'news_rows' => "6",

'transfer_purse' => "R394901164756",

'title' => "WORLD-SMS – смс рассылка, смс шлюз",

'description' => "WORLD-SMS сервис массовых смс рассылок, смс шлюз",

'keywords' => "SMS, СМС, cmc, смс сервис, сервис отправки смс, отправить смс, смс онлайн, смс бесплатно, сервис смс рассылок, рассылка смс, sms услуги, смс услуги, смски, world-sms, мир смс, рассылка через смс, отправка смс, смс рассылка",

'geteway_ip' => "",

'delive_stats_time' => "",

'reg_count_sms' => "3",

'pr_prtner_one' => "20",

'pr_prtner_two' => "10",

'cron_run_time' => "181",

'counter' => "",

'transfer_key' => "sjyksj5tj5l464eghdfju4gh69l",

);

?>