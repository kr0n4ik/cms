<?php
$login = array(
	'root' => array ( 'password' => "a2ce924fc95d195faf1d13c752baffd2", 'group' => "0", 'name' => "Сергей" ),
	'vladimir' => array ( 'password' => "541adfb1f4ba081a377fbd5ad4aeb99d", 'group' => "0", 'name' => "Владимир" )
)
?>