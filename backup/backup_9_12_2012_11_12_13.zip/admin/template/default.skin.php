<?PHP
$skin_header = <<<HTML
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>World-SMS панель управления</title>
<meta content="text/html; charset=utf-8" http-equiv="content-type" />
<link rel="stylesheet" type="text/css" href="{$config['url_home']}admin/template/css/default.css" />
<link rel="stylesheet" type="text/css" href="{$config['url_home']}admin/template/css/style.css" />
<link rel="stylesheet" href="{$config['url_home']}admin/template/css/uniform.default.css" type="text/css" media="screen" />
<script src="{$config['url_home']}admin/template/js/jquery.js" type="text/javascript" charset="utf-8"></script>
<script src="{$config['url_home']}admin/template/js/jquery.uniform.js" type="text/javascript" charset="utf-8"></script>
    <script type="text/javascript" charset="utf-8">
      $(function(){
        $("input, textarea, button").uniform();
      });
    </script>
</head>
</head>
<body>
<div id="adminka">

<div class="header"><div style="padding:18px 25px 5px 5px;">

<div style="float:left; padding:3px 0 0 15px">
<img src="admin/template/images/skin/str.png" align="absmiddle" /> {name} ({group})
</div>

<div style="float:right;">
<div class="navheadl" onclick="location.href = '{$PHP_SELF}?mod=main'">На главную</div>
<div class="navhead" onclick="location.href = '{$PHP_SELF}?mod=options'">Настройки</div>
<div class="navhead" onclick="location.href = '{$config['url_home']}','_blank'">Сайт</div>
<div class="navheadr" onclick="location.href = '{$PHP_SELF}?action=logout'">Выход</div>
</div>

</div></div>

<div id="wrapper">

HTML;

$skin_footer = <<<HTML
<div class="clear"> </div>
</div>
<div id="rasporka"></div>
</div>
<div class="footer">
	<div id="wrapper" style="padding-top:10px;>
		<div style="float:left">
			<div style="float:left">
			DataLife Engine
			<br />Copyright 2004-2011 © SoftNews Media Group. All rights reserved.
			<div class="clear"> </div>
			</div>
			<div style="float:right">
			Дизайн от Adamantis
			<br /><a href="http://hatynka.pp.ua">Hatynka.pp.ua</a>
			<div class="clear"> </div>
			</div>
			<div class="clear"> </div>
		</div>
	</div>
</div>
HTML;

$skin_login = <<<HTML
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>World-SMS - Вход в панель администратора</title>
<meta content="text/html; charset=utf-8" http-equiv="content-type" />
<link rel="stylesheet" type="text/css" href="admin/template/css/style.css" />
<script src="admin/template/js/jquery.js" type="text/javascript" charset="utf-8"></script>
    <script type="text/javascript" charset="utf-8">
		$(function(){
			var winH = $(window).height();
			var winW = $(window).width();
			$('#login').css('top',  winH/2-$('#login').height()/2);
			$('#login').css('left', winW/2-$('#login').width()/2);
		});
	</script>
</head>
<body>
<form id="login" style="width:400px; position:absolute;" method="post">
<input type="hidden" name="action" value="login">
<div class="blockt">Авторизация на сайте</div>
<div class="blockc">
<table width="100%">
	<tr>
		<td colspan="3" align="center">{$result}</td>
	</tr>
    <tr>
        <td width="55" style="padding:5px;" rowspan="3"><img src="admin/template/images/key.png" border="0"></td>
        <td width="140" style="padding:5px;">Имя:</td>
        <td><input class="edit bk" type="text" name="login" value='' size="20"></td>
    </tr>
    <tr>
        <td style="padding:5px;">Пароль:</td>
        <td colspan="2"><input class="edit bk" type="password" name="password" size="20"></td>
    </tr>
	<tr>
        <td colspan="3" align="center"><input type="submit" class="edit" value="Войти"></td>
    </tr>
</table>
</div>
</form>
</body>
</html>
HTML;
?>