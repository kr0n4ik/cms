<?php
#info:init.php world-sms v2.0 25.09.2012
if ( !defined( "SMS_ADMIN" ) ) { die( "Hacking..." ); exit(); }

require_once DIR_ROOT . "/config/admin.cfg.php";
require_once DIR_ROOT . "/config/mysql.cfg.php";
require_once DIR_ROOT . "/admin/function.inc.php";
require_once DIR_ROOT . "/kernel/classes/mysql.class.php";
require_once DIR_ROOT . "/kernel/classes/sms.class.php";
require_once DIR_ROOT . "/kernel/classes/mail.class.php";

$a_group = array( '0'=> "Полный доступ", '1'=> "Ограниченый доступ", '2'=> "Модератор" );

#Проверка логина и пароля
if ( $_POST['action'] == "login" ) {
	if ( isset( $login[$_REQUEST['login']]['name'] ) && $login[$_REQUEST['login']]['password'] == md5( $_REQUEST['password'] . $_REQUEST['login'] . md5( $_REQUEST['password'] ) ) ) {
		$_SESSION['admin']['name'] = $login[$_REQUEST['login']]['name']; 
		$_SESSION['admin']['group'] = $login[$_REQUEST['login']]['group'];
		$_SESSION['admin']['hash'] = md5( $_SERVER['HTTP_HOST'] . sha1( $_SESSION['admin']['name'] ) . date( "Ymd" ) . $_SESSION['admin']['group'] );
		write_log( "admin", "Вход|" . $login[$_REQUEST['login']]['name'] . "|" . $global['ip'] );
	} else {
		write_log( "admin", "Неверный пароль|" . $_REQUEST['login'] . "|" . $_REQUEST['password']  . "|" . $global['ip'] );
		$result = "<font color=\"red\">Неверный логин</font>";
	}
}
if ( $_GET['action'] == "logout" ) {
	write_log( "admin", "Выход|" . $login[$_REQUEST['login']]['name'] . "|" . $global['ip'] );
	$global['loged'] = false;
	$global['hash'] = "";
	unset( $_SESSION['admin'] );
	hedaer("Location: admin.php");
}
if ( isset( $_SESSION['admin'] ) ) {
	if ( $_SESSION['admin']['hash'] == md5( $_SERVER['HTTP_HOST'] . sha1( $_SESSION['admin']['name'] ) . date( "Ymd" ) . $_SESSION['admin']['group'] ) ) {
		$global['loged'] = true;
		$global['hash'] = md5( $_SERVER['HTTP_HOST'] . sha1( $_SESSION['admin']['name'] ) . date( "Ymd") . $_SESSION['admin']['group'] );
		$global['name'] = $_SESSION['admin']['name'];
		$global['group'] = $_SESSION['admin']['group'];
		$db = new db( $sql['server'], $sql['user'], $sql['password'], $sql['database'] );
		$sms = new sms( $config );
		$mail = new xmail( $config );
	}
}
$admin['rows'] = 10;
?>