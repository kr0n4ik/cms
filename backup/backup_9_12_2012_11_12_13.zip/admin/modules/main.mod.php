<?php
#info:admin.php world-sms v2.0 25.09.2012
if ( !defined( "SMS_ADMIN" ) ) { die( "Hacking..." ); exit(); }

$main = array();
$main[] = array( 'mod' => "users", 'image' => "friends.png", 'title' => "Редактирование пользователей", 'desc' => "Управление зарегистрированными на сайте пользователями, редактирование их профилей и блокировка аккаунта", 'group' => 0 );
$main[] = array( 'mod' => "delive", 'image' => "sms.png", 'title' => "Сервис sms рассылок", 'desc' => "Статистика, отправка и настройки sms рассылок", 'group' => 0 );
$main[] = array( 'mod' => "money", 'image' => "money.png", 'title' => "Денежные трансакции", 'desc' => "Статистика, перевод денежных потоков", 'group' => 0 );
$main[] = array( 'mod' => "static", 'image' => "tmpl.png", 'title' => "Статические страницы", 'desc' => "Создание и редактирование страниц, которые как правило редко изменяются и имеют постоянный адрес", 'group' => 0 );
$main[] = array( 'mod' => "options", 'image' => "tmpl.png", 'title' => "Настройки", 'desc' => "Статические страницы", 'group' => 3 );
$main[] = array( 'mod' => "logs", 'image' => "repa_info.png", 'title' => "Логи системы", 'desc' => "Логи работы системы для отладки", 'group' => 3 );
$main[] = array( 'mod' => "news", 'image' => "ads.png", 'title' => "Новости", 'desc' => "Добавление новости в базу данных", 'group' => 0 );
$main[] = array( 'mod' => "msend", 'image' => "repa_m_opts.png", 'title' => "Рассылка", 'desc' => "Массовая рассылка по e-mail и sms", 'group' => 0 );
$main[] = array( 'mod' => "backup", 'image' => "dbset.png", 'title' => "Дамп сайта", 'desc' => "Создание резервной копии сайта и базы данных", 'group' => 0 );

echoheader();
echo <<<HTML
<div class="blockt">Быстрый доступ к разделам сайта</div>
<div class="blockc">
<table width="100%"><tr>
HTML;

$i = 0;
foreach ( $main as $option ) {	
	if ( $global['group'] <= $option['group'] ) {
		if( $i > 1 ) {
			echo "</tr><tr>";
			$i = 0;
		}
		$i ++;
	
echo <<<HTML
<td width="50%">
<table width="100%">
    <tr>
        <td width="70" height="70" valign="middle" align="center" style="padding-top:5px;padding-bottom:5px;"><img src="admin/template/images/{$option['image']}" border="0"></td>
        <td valign="middle"><div class="quick"><a href="$PHP_SELF?mod={$option['mod']}"><h3>{$option['title']}</h3>{$option['desc']}</a></div></td>
    </tr>
</table>
</td>
HTML;

	}
}

echo <<<HTML
</tr></table>

</div>
<div class="blockt">Информация о работе сайта</div>
<div class="blockc">
<table width="50%">
HTML;

$info = array();

include DIR_ROOT . "/cache/cron/timer.php";
$info[] = ( $timer['lasttime'] < $global['time'] - 5*$config['cron_run_time'] ) ? "<tr style=\"padding:2px; color: red;\"><td colspan=\"2\">Скрипт cron простаивает более " . 5 * $config['cron_run_time'] . " секунд!</td></tr>" : "";

$count = $db->numrows( $db->query( "SELECT * FROM " . $sql['prefix'] . "_users WHERE uptime>" . ( $global['time'] + 300 ) . ";" ) );
$info[] = "<tr style=\"padding:2px;\"><td>Количество пользователей на сайте: </td><td>{$count}</td></tr>";

$count = $db->numrows( $db->query( "SELECT * FROM " . $sql['prefix'] . "_users;" ) );
$info[] = "<tr style=\"padding:2px;\"><td>Количество пользователей: </td><td>{$count}</td></tr>";

$count = $db->numrows( $db->query( "SELECT * FROM " . $sql['prefix'] . "_users WHERE regtime>" . strtotime( date( "d-m-Y", $global['time'] ) ) . " AND regtime<" . strtotime( date( "d-m-Y 23:59:59", $global['time'] ) ) . ";" ) );
$info[] = "<tr style=\"padding:2px;\"><td>Зарегестрированных за сегодня: </td><td>{$count}</td></tr>";

$info[] = "<tr style=\"padding:2px;\"><td>Количество смс: </td><td>" . $sms->get_balance() . "</td></tr>";

$info[] = "<tr style=\"padding:2px;\"><td>Свободное место на диске: </td><td>" . formatsize( @disk_free_space( "." ) ) . "</td></tr>";

foreach ( $info as $val ) {
	echo $val;
}

echo <<<HTML
</table>
</div>
HTML;
echofooter();
?>