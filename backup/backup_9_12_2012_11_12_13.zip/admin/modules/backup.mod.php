<?php
#info:admin.php world-sms v2.0 25.09.2012
if ( !defined( "SMS_ADMIN" ) ) { die( "Hacking..." ); exit(); }

if ( $_REQUEST['action'] == "list" or $_REQUEST['action'] == "" ) {
	echoheader();
echo <<<HTML
<div class="blockt">
	Сохранение резервной копии
</div>
<div class="blockc">
	<table width="100%">
		<tr>
			<td style="padding:2px;">
				<input type="button" class="btn btn-success btn-mini" onclick="location.href='admin.php?mod=backup&action=create'" value="Создать резервную копию"/>
			</td>
		</tr>
</table>
</div>
HTML;
	echofooter();
} elseif ( $_REQUEST['action'] == "create" ) {

	function add_zip( $dir){
		global $zip;
		$hd = opendir( $dir );
		$zip -> addEmptyDir( $dir );
		while ( false !== ( $file = readdir( $hd ) ) ) { 
			if ( $file != "." && $file != ".."  ) {
				if ( is_file( $dir . $file ) ) {
					$zip->addFile( $dir . $file, $dir . $file);
				} elseif ( is_dir( $dir . $file ) ) { 
					 add_zip( $dir . $file."/" );
				}
			}
		}
	}
	
	$query = $row = array();
	$query[0] = $db->query( "SHOW TABLES;" );
	$hf = fopen( DIR_ROOT . "/backup/backup.sql", "w" );
	while ( $row[0] = $db->fetchrow( $query[0] ) ) {
		if( substr( $row[0][0], 0, strlen( $sql['prefix'] ) ) == $sql['prefix'] ) { 	
			$query[1] =$db->query( "SELECT * FROM {$row[0][0]}" );
			$count = $db->numfields( $query[1] );
			$row[1] = $db->fetchrow( $db->query( "SHOW CREATE TABLE {$row[0][0]}" ) );
			fwrite( $hf, $row[1][1] . "\n\n" );
			for ($i = 0; $i < $count; $i++) {
				while( $row[2] = $db->fetchrow( $query[1] ) ) {
					fwrite( $hf, "INSERT INTO `{$row[0][0]}` VALUES(" );
					for($j=0; $j < $count; $j++) {
						$row[2][$j] = addslashes($row[2][$j]);
						$row[2][$j] = ereg_replace("\n", "\\n", $row[2][$j]);
						if ( isset( $row[2][$j] ) ) { 
							fwrite( $hf, "`{$row[2][$j]}`" );
						} else { 
							fwrite( $hf, "``" ); 
						}
						if ($j < ( $count-1 ) ) { 
							fwrite( $hf, ", " ); 
						}
					}
					fwrite( $hf, ");\n" ); 
				}
			}
		}
	}
	fclose( $hf );
	
	#Архивация сайта
	$zip = new ZipArchive();
	
	$ZipName = DIR_ROOT . "/backup/backup_" . date( "j_m_Y_h_m_s", $global['time'] ) . ".zip";
	if ( $zip->open( $ZipName, ZIPARCHIVE::CREATE ) !== true ) { 
		echo "Ошибка создания архива";
		exit;
	}
	
	$folders = array( 'admin', 'config', 'kernel', 'templates' );
	foreach ( $folders as $src_dir ) {
		add_zip(  $src_dir . "/" );
	}
	
	$hd = opendir( DIR_ROOT . "/" );
	while ( false !== ( $file = readdir( $hd ) ) ) {
		if ( $file != "." && $file != "cron.php" && $file != ".." && is_file( DIR_ROOT . "/" . $file )  ) {
			echo "$file<br/>";
			$zip->addFile( "/var/www/html/" . $file, $file );
		}
	}
//	$zip->addFile("rss.php", "rss.php");
	$zip->addFile( "backup/backup.sql", "backup.sql" );
	$zip->close();
	
	MessageBox( "Успешно", "Резервная копия сайта создана", "?mod=backup");
}
?>