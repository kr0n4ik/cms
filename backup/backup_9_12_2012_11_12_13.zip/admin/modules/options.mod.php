<?php
if( !defined( "SMS_ADMIN" ) OR !$global['loged'] ) { die( "Hack Script" ); }

if ( $_SESSION['admin']['group'] > 1 ) {
	MessageBox( "Ошибка", "У Вас нет прав для просмотра", "?mod=main" );
}
if( $_REQUEST['action'] == "save" ) {
	if( $_REQUEST['hash'] == "" or $_REQUEST['hash'] != $global['hash'] ) {
		die( "Hacking..." );
	}
	$find[] = "'\r'";
	$replace[] = "";
	$find[] = "'\n'";
	$replace[] = "";
	foreach ( $_REQUEST['save'] as $name => $value ) {
		$value = trim( strip_tags( stripslashes( $value ) ) );
		$value = htmlspecialchars( $value, ENT_QUOTES);
		$value = preg_replace( $find, $replace, $value );
		$name = trim( strip_tags( stripslashes( $name ) ) );
		$name = htmlspecialchars( $name, ENT_QUOTES );
		$name = preg_replace( $find, $replace, $name );
		$value = str_replace( "$", "&#036;", $value );
		$value = str_replace( "{", "&#123;", $value );
		$value = str_replace( "}", "&#125;", $value );
		$name = str_replace( "$", "&#036;", $name );
		$name = str_replace( "{", "&#123;", $name );
		$name = str_replace( "}", "&#125;", $name );
		$config[$name] = $value;
	}
	$handler = fopen( DIR_ROOT . "/config/global.cfg.php", "w" );
	fwrite( $handler, "<?php \n\n\$config = array (\n\n" );
	foreach ( $config as $name => $value ) {
		fwrite( $handler, "'" . $name . "' => \"" . $value . "\",\n\n" );
	}
	fwrite( $handler, ");\n\n?>" );
	fclose( $handler );
	MessageBox( "Успешно", "Настройки сохраенны", $PHP_SELF . "?mod=options" );
	exit;
}

function tpl_input_text( $name, $title, $description ) {
		global $config;
		echo "<tr>\n";
		echo "	<td style=\"padding:4px\" class=\"option\">\n";
		echo "		<b>" . $title . ":</b>\n";
		echo "		<br />\n";
		echo "		<span class=\"small\">" . $description . "</span>\n";
		echo "	</td>\n";
		echo "	<td width=\"394\" align=\"middle\" >\n";
		echo "		<input class=\"edit bk\" type=\"text\" style=\"text-align: center;\" name=\"save[" . $name . "]\" value=\"" . $config[$name] . "\" size=\"40\" />\n";
		echo "	</td>\n";
		echo "</tr>\n";
		echo "<tr><td background=\"admin/template/images/mline.gif\" height=1 colspan=2></td></tr>\n";
}

function tpl_input_radio( $name, $title, $description ) {
		global $config;
		
		if ( $config[$name] == 'yes' ) { $check[0] = 'checked="checked"'; } else { $check[1] = 'checked="checked"'; }
	
		echo "<tr>\n";
		echo "	<td style=\"padding:4px\" class=\"option\">\n";
		echo "		<b>" . $title . ":</b>\n";
		echo "		<br />\n";
		echo "		<span class=\"small\">" . $description . "</span>\n";
		echo "	</td>\n";
		echo "	<td width=\"394\" align=\"middle\" >\n";
		echo "		<input type=\"radio\" name=\"save[" . $name . "]\" " . $check[0] . " value=\"yes\"/>Да<input type=\"radio\" name=\"save[" . $name . "]\" " . $check[1] . " value=\"no\" />Нет\n";
		echo "	</td>\n";
		echo "</tr>\n";
		echo "<tr><td background=\"admin/template/images/mline.gif\" height=1 colspan=2></td></tr>\n";
}

function tpl_input_password( $name, $title, $description ) {
		global $config;
		echo "<tr>\n";
		echo "	<td style=\"padding:4px\" class=\"option\">\n";
		echo "		<b>" . $title . ":</b>\n";
		echo "		<br />\n";
		echo "		<span class=\"small\">" . $description . "</span>\n";
		echo "	</td>\n";
		echo "	<td width=\"394\" align=\"middle\" >\n";
		echo "		<input class=\"edit bk\" type=\"password\" style=\"text-align: center;\" name=\"save[" . $name . "]\" value=\"" . $config[$name] . "\" size=\"40\" />\n";
		echo "	</td>\n";
		echo "</tr>\n";
		echo "<tr><td background=\"admin/template/images/mline.gif\" height=1 colspan=2></td></tr>\n";
}

function tpl_input_textarea( $name, $title, $description ) {
		global $config;
		echo "<tr>\n";
		echo "	<td style=\"padding:4px\" class=\"option\">\n";
		echo "		<b>" . $title . ":</b>\n";
		echo "		<br />\n";
		echo "		<span class=\"small\">" . $description . "</span>\n";
		echo "	</td>\n";
		echo "	<td width=\"394\" align=\"middle\" >\n";
		echo "		<textarea class=\"edit bk\" style=\"width:290px;height:80px;\" name=\"save[" . $name . "]\">" . $config[$name] . "</textarea>\n";
		echo "	</td>\n";
		echo "</tr>\n";
		echo "<tr><td background=\"admin/template/images/mline.gif\" height=1 colspan=2></td></tr>\n";
}

echoheader();
echo <<<HTML
<script language='JavaScript' type="text/javascript">
        function ChangeOption(selectedOption) {

                document.getElementById('general').style.display = "none";
                document.getElementById('delive').style.display = "none";
				document.getElementById('security').style.display = "none";
				document.getElementById('cron').style.display = "none";
				document.getElementById('html').style.display = "none";
				document.getElementById('money').style.display = "none";

                document.getElementById(selectedOption).style.display = "";
       }
</script>
<div class="blockt">Категория настроек</div>
<div class="blockc">
<table width="100%">
    <tr>
        <td style="padding:2px;">
<table style="text-align:center;" width="100%" height="35px">
<tr style="vertical-align:middle;" >
 <td class=tableborder><a href="javascript:ChangeOption('general');"><img title="Главная" src="admin/template/images/general.png" border="0"></a>
 <td class=tableborder><a href="javascript:ChangeOption('security');"><img title="Безопасность" src="admin/template/images/sred.png" border="0"></a>
 <td class=tableborder><a href="javascript:ChangeOption('html');"><img title="Настройки статического контента" src="admin/template/images/comments.png" border="0"></a>
 <td class=tableborder><a href="javascript:ChangeOption('money');"><img title="Настройки выплат" src="admin/template/images/money.png" border="0"></a>
 <td class=tableborder><a href="javascript:ChangeOption('delive');"><img title="Настройки смс рассылкы" src="admin/template/images/sms.png" border="0"></a>
 <td class=tableborder><a href="javascript:ChangeOption('cron');"><img title="Настройки автоматического скрипта" src="admin/template/images/clock.png" border="0"></a>

 </tr>
</table>
</td>
    </tr>
</table>
</div>
<form action="" method="post">
	<table width="100%">
		<tr style='' id="general">
			<td>
				<div class="blockt">
					Главная
				</div>
				<div class="blockc">
					<table width="100%">
HTML;
	tpl_input_text( "title", "Название сайта", "например: \"Моя домашняя страница\"." );
	tpl_input_text( "url_home", "Домашняя страница сайта", "Укажите имя основного домена на котором располагается ваш сайт. Например: http://yoursite.com/ Внимание, наличие слеша на конце в имени домена обязательно." );
	tpl_input_text( "description", "Описание (Description) сайта", "Краткое описание, не более 200 символов." );
	tpl_input_textarea( "keywords", "Описание (Keywords) сайта", "Ключевые слова для поисковиков." );
	tpl_input_text( "tz", "Коррекция временных зон", "в минутах; т.е.: 180=+3 часа; -120=-2 часа. Текущее время сервера с учетом коррекции: " . date('d.m.Y, H:i', time() + $config['tz'] * 60 ) );
	tpl_input_text( "theme", "Шаблон сайта по умолчанию", "Выберите шаблон, который будет использоваться на сайте." );
	tpl_input_textarea( "counter", "Щетчик для сайт.", "Ссылка помещаемая в footer" );
	tpl_input_radio( "debug", "Режим отладки", "Ведет статистика по логам." );
echo <<<HTML
					</table>
				</div>
			</td>
		</tr>
		<tr style='display:none' id="security">
			<td>
				<div class="blockt">
					Настройки безопасности
				</div>
				<div class="blockc">
					<table width="100%">
HTML;
	tpl_input_text( "time_session", "Время жизни сессии", "количесто времени в часх в течение которго пользователь может не вводить пароль." );
	tpl_input_password( "salt", "Код защиты пароля", "\"соль\" для защиты от кражи паролей из бд." );
	tpl_input_password( "transfer_key", "Код защиты кошелька", "Секретный клюя для кошелька wmr." );
echo <<<HTML
					</table>
				</div>
			</td>
		</tr>
		<tr style='display:none' id="html">
			<td>
				<div class="blockt">
					Настройки статического контента
				</div>
				<div class="blockc">
					<table width="100%">
HTML;
	tpl_input_radio( "cache", "Кешировать страницы", "Позволят увеличить скорость загрузки страниц." );
	tpl_input_text( "time_cache", "Время кеширование", "Время в часах, в течение которого страница не обновляется." );
	tpl_input_text( "table_rows", "Количество строк в таблице", "Количество строк заполняемых в таблице." );
	tpl_input_text( "news_rows", "Количество новостей", "Количество ноостных лент, выводимых на экран." );
echo <<<HTML
					</table>
				</div>
			</td>
		</tr>
		<tr style='display:none' id="delive">
			<td>
				<div class="blockt">
					Настройки sms рассылок
				</div>
				<div class="blockc">
					<table width="100%">
HTML;
	tpl_input_text( "geteway_ip", "IP шлюза", "Укажите IP шлюза" );
	tpl_input_text( "geteway_email", "Логин шлюза", "имя пользователя для авторизации на шлюзе." );
	tpl_input_password( "geteway_password", "Пароль шлюза", "пароль пользователя для авторизации на шлюзе." );
	tpl_input_text( "delive_stats_time", "Время статистики", "Время в течении которого пользователю показывается статус sms в днях" );
	tpl_input_text( "reg_count_sms", "Количество смс при регистрации пользователя", "количество смс даваемых пользователю при регистрации." );
	tpl_input_text( "pr_prtner_one", "Процент отчислений первому партнеру", "в % отчисления первому партнеру." );
	tpl_input_text( "pr_prtner_two", "Процент отчислений второму партнеру", "в % отчисления второму партнеру." );
echo <<<HTML
					</table>
				</div>
			</td>
		</tr>
		<tr style='display:none' id="cron">
			<td>
				<div class="blockt">
					Настройки автоматического скрипта
				</div>
				<div class="blockc">
					<table width="100%">
HTML;
	tpl_input_text( "cron_run_time", "Интервал обновления", "Время в секундах через которое запускается скрипт" );
echo <<<HTML
					</table>
				</div>
			</td>
		</tr>
		<tr style='display:none' id="money">
			<td>
				<div class="blockt">
					Настройки выплат
				</div>
				<div class="blockc">
					<table width="100%">
HTML;
	tpl_input_text( "transfer_purse", "Основной кошелек", "кошелек для выплат и оплат." );
echo <<<HTML
					</table>
				</div>
			</td>
		</tr>
		<tr>
			<td style="padding-top:10px; padding-bottom:10px;padding-right:10px;">
				<input type="hidden" name="action" value="save">
				<input type="hidden" name="hash" value="{$global['hash']}" />
				<input type="submit" class="bbcodes" value="&nbsp;&nbsp;Сохранить&nbsp;&nbsp;">
				<input type="button" value="&nbsp;&nbsp;Отмена&nbsp;&nbsp;" class="bbcodes" onclick="document.location='{$PHP_SELF}?mod=main'">
			</td>
		</tr>
	</table>
</div>
</form>
HTML;

echofooter();
?>