<?php
#info:admin.php world-sms v2.0 25.09.2012
if ( !defined( "SMS_ADMIN" ) ) { die( "Hacking..." ); exit(); }

if ( $_SESSION['admin']['group'] > 2 ) {
	MessageBox( "Ошибка", "У Вас нет прав для просмотра", "?mod=main" );
}

if ( $_REQUEST['action'] == "json" ) {
	if ( $_REQUEST['json_mod'] == "stats" or $_REQUEST['json_mod'] == "" ) {
		
		$status = array(
			'-3' => "<p class=\"red\">Нету средств</p>",
			'-2' => "<p class=\"red\">Не доставлено</p>",
			'-1' => "<p class=\"red\">Не принято</p>",
			'0' => "<p class=\"gray\">В очерди</p>",
			'1' => "<p class=\"blue\">У шлюза</p>",
			'2' => "<p class=\"blue\">У оператора</p>",
			'3' => "<p class=\"green\">Доставлено</p>"
		);
	
		$page = intval( $_REQUEST['page'] );
		$sort = ( $_REQUEST['sort'] == "asc" ) ? "ASC" : "DESC";
		
		switch ( $_REQUEST['order'] ) {
			case 0: $order = "id"; break;
			case 1: $order = "createtime"; break;
			case 2: $order = "statustime"; break;
			case 3: $order = "sender"; break;
			case 3: $order = "phone"; break;
			case 3: $order = "status"; break;
			default: $order = "status"; break;
		}
		
		$query = "SELECT * FROM " . $sql['prefix'] . "_statistica_two";
		$count = $db->numrows( $db->query( $query . ";" ) );
		$result = $db->query( $query . " ORDER BY " . $order . " " . $sort . " LIMIT " . ( $admin['rows'] * $page ) . ", " . $admin['rows'] . ";" );
		
		$out = array();
		$out['count'] = $count;
		$i = 0;
		while ( $row = $db->fetchrow( $result ) ) {
			$color = ( $i%2 != 0 ) ? "#ffffff" : "#f8f8f8";
			$statustime = ( $row['statustime'] == 0 || $row['statustime'] == "" ) ? "Не получено" : date( "Y-m-d H:i:s", $row['statustime'] );
			$out['html'] .= "
			<tr style=\"background: " . $color . "\">
				<td>" . $row['id'] . "</td>
				<td>" . date( "d.m.Y H:i:s", $row['createtime'] ) . "</td>
				<td>" . $statustime . "</td>
				<td>" . $row['sender'] . "</td>
				<td>" . $row['phone'] . "</td>
				<td>" . $status[$row['status']] . "</td>
				<td align=\"right\">
					<a title=\"Информация о пользователе\" target=\"_blank\" href=\"" . $PHP_SELF . "?mod=users&hash=" . $global['hash'] . "&action=info&id=" . $row['userid'] . "\">
						<img src=\"admin/template/images/16/info.png\" />&nbsp;
					</a>
					<a title=\"Информация о sms\" target=\"_blank\" href=\"" . $PHP_SELF . "?mod=delive&hash=" . $global['hash'] . "&action=info&id=" . $row['id'] . "\">
						<img src=\"admin/template/images/16/info.png\" />&nbsp;
					</a>
				</td>
			<tr>
			";
			$i++;
		}
		if ( $admin['rows'] < $count ) {
			for ( $i = 0; $i <  Ceil( $count/$admin['rows'] ); $i++ ) {
				if ( $page == $i ) {
					$out['page'] .= "<span>" . ( $i+1 ) . "</span>";
				} else {
					$out['page'] .= "<a href=\"#\">" . ( $i+1 ) . "</a>";
				}
			}
		}
		
		$out['html'] = ( $out['html'] ) ? $out['html'] : "<tr><td colspan=\"10\" style=\"background: #ffffff; text-align: center;\">Нет записей</td></tr>\n";
		
		echo $_GET['callback'] . "(" . json_encode( $out ) . ")";
		exit;
	}
}
if ( $_REQUEST['action'] == "main" or $_REQUEST['action'] == "" ) {
	echoheader();
echo <<<HTML
<div class="blockt">Доступ к разделам рассылки</div>
<div class="blockc">
	<table width="100%">
		<tr>
			<td>
				<table width="100%">
					<tr>
						<td width="70" height="70" valign="middle" align="center" style="padding-top:5px;padding-bottom:5px;">
							<img src="admin/template/images/online_stat.png" border="0">
						</td>
						<td valign="middle">
							<div class="quick">
								<a href="?mod=delive&action=stats">
									<h3>Статистика отправки смс</h3>
									Статистика и состояние отправленных смс
								</a>
							</div>
						</td>
					</tr>
				</table>
			</td>
			<td>
				<table width="100%">
					<tr>
						<td width="70" height="70" valign="middle" align="center" style="padding-top:5px;padding-bottom:5px;">
							<img src="admin/template/images/money.png" border="0">
						</td>
						<td valign="middle">
							<div class="quick">
								<a href="?mod=delive&action=price">
									<h3>Цены на смс</h3>
									Тарифная сетка для покупки смс
								</a>
							</div>
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
</div>
HTML;

echo <<<HTML
</tr></table>

</div>
<div class="blockt">Общая информация о сервисе смс рассылок</div>
<div class="blockc">
<table width="50%">
HTML;

$info = array();

$info[] = "<tr style=\"padding:2px;\"><td>Количество смс: </td><td>" . $sms->get_balance() . "</td></tr>";

$count = $db->fetchrow( $db->query( "SELECT SUM(sms) as sum FROM " . $sql['prefix'] . "_users;" ) );
$info[] = "<tr style=\"padding:2px;\"><td>Количество смс у пользователей: </td><td>{$count['sum']}</td></tr>";

$count = $db->numrows( $db->query( "SELECT id FROM " . $sql['prefix'] . "_statistica_two WHERE status='3';" ) );
$info[] = "<tr style=\"padding:2px;\"><td>Количество отправленных: </td><td>{$count}</td></tr>";

$count = $db->fetchrow( $db->query( "SELECT SUM(balance) as sum FROM " . $sql['prefix'] . "_users;" ) );
$info[] = "<tr style=\"padding:2px;\"><td>Общая сумма выплат: </td><td>{$count['sum']}</td></tr>";

foreach ( $info as $val ) {
	echo $val;
}

echo <<<HTML
</table>
</div>
HTML;
	echofooter();
} elseif ( $_REQUEST['action'] == "stats" ) {
	echoheader();
echo <<<HTML
<div class="blockt">
	Список отправленных sms (<span id="count"></span>)
	<div style="float:right; font-size:11px;">
		<a style="color:#fff" href="javascript:history.go(-1);">Назад</a>
	</div>
</div>
<div class="blockc">
	<table id="json" width="100%">
		<thead>
			<tr>
				<td class="desc">id</td>
				<td>Дата создания</td>
				<td>Дата статуса</td>
				<td>Отправитель</td>
				<td>Получатель</td>
				<td>Статус</td>
				<td align="right">Функции</td>
			</tr>
		</thead>
		<tbody>
		</tbody>
	</table>
	<table width=100%>
		<tr class="tfoot">
			<td colspan="2"><div class="hr_line"></div></td>
		</tr>
		<tr>
			<td id="page">
				<div class="news_navigation" style="margin-bottom:5px; margin-top:5px;">
				</div>
			</td>
			<td align="right" valign="top">
				<div style="margin-bottom:5px; margin-top:5px;"></div>
			<td>
		</tr>
	</table>
</div>
<script type="text/javascript">
	var page, order, sort, find;
	function get() {
		$("table#json tbody").html('<tr><td colspan="40" style="background: #ffffff; text-align: center;"><img src="admin/template/images/loading-bar.gif" /></td></tr>');
		$.getJSON( "admin.php?mod=delive&action=json&callback=?", 
		{ 
		'page': page,
		'order': order,
		'sort': sort,
		'find': find
		},
		function(data) {
			$("table#json tbody").html(data.html);
			$("td#page div").html(data.page);
			$("#count").html(data.count);
		});
	}
	get();
	$("table#json thead td").live("click", function(){
		order = $(this).index();
		sort =  $(this).attr("class");
		if ( sort == "none" || !sort ) { sort = "asc"; }
		$("table#json thead td").attr("class", "none");
		if ( sort == "asc" ) { $(this).attr("class", "desc"); } else { $(this).attr("class", "asc"); }
		get();
	});
	$("#page a").live("click", function(){
		page = $(this).text() - 1;
		get();
	});
</script>
HTML;
	echofooter();
} elseif ( $_REQUEST['action'] == "info" && preg_match( "/^[0-9]+$/", $_REQUEST['id'] ) ) {
	if( $_REQUEST['hash'] == "" or $_REQUEST['hash'] != $global['hash'] ) {
		die( "Hacking..." );
	}
	$row = $db->fetchrow( $db->query( "SELECT * FROM " . $sql['prefix'] . "_statistica_two WHERE id=" . $_REQUEST['id'] . ";" ) );
	$createtime = date( "H:i d.m.Y", $row['createtime'] );
	$statustime = date( "H:i d.m.Y", $row['statustime'] );
	$sendtime = date( "H:i d.m.Y", $row['sendtime'] );
	$user = $db->fetchrow( $db->query( "SELECT * FROM " . $sql['prefix'] . "_users WHERE id=" . $row['userid'] . ";" ) );
echo <<<HTML
<html>
<head>
<meta content="text/html; charset=utf-8" http-equiv="content-type" />
<title>Информация - {$row['email']}</title>
<link rel="stylesheet" type="text/css" href="admin/template/css/style.css" />
<link rel="stylesheet" type="text/css" href="admin/template/css/default.css" />
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js" type="text/javascript" charset="utf-8"></script>
</head>
<body style="font-size:11px!important; padding:10px">
<div class="blockt">
	Информация об sms
</div>
<div class="blockc">
	<table width="100%">
		<tr>
			<td width="200" style="padding:5px;">Пользователь:</td>
			<td><a target="_blank" href="?mod=users&action=info&id={$row['userid']}">{$user['email']} ({$user['nametwo']}  {$user['nameone']})</a></td>
		</tr>
		<tr>
			<td width="200" style="padding:5px;">Отправитель:</td>
			<td>{$row['sender']}</td>
		</tr>
		<tr>
			<td width="200" style="padding:5px;">Получатель:</td>
			<td>{$row['phone']}</td>
		</tr>
		<tr>
			<td colspan="3"><div class="hr_line"></div></td>
		</tr>
		<tr>
			<td width="200" style="padding:5px;">Время создания:</td>
			<td>{$createtime}</td>
		</tr>
		<tr>
			<td width="200" style="padding:5px;">Время обновления статуса:</td>
			<td>{$statustime}</td>
		</tr>
		<tr>
			<td width="200" style="padding:5px;">Время отправки:</td>
			<td>{$sendtime}</td>
		</tr>
		<tr>
			<td colspan="3"><div class="hr_line"></div></td>
		</tr>
		<tr>
			<td width="200" style="padding:5px;">Сообщение:</td>
			<td>{$row['message']}</td>
		</tr>
		<tr>
			<td colspan="3"><div class="hr_line"></div></td>
		</tr>
		<tr>
			<td width="200" style="padding:5px;">ID sms:</td>
			<td>{$row['id']}</td>
		</tr>
		<tr>
			<td width="200" style="padding:5px;">ID пакета:</td>
			<td>{$row['packetid']}</td>
		</tr>
		<tr>
			<td width="200" style="padding:5px;">Количество честей:</td>
			<td>{$row['parts']}</td>
		</tr>
		<tr>
			<td colspan="3" style="padding-top:10px;padding-bottom:10px;">
			&nbsp;&nbsp;&nbsp;
			<input type="button" value="Закрыть" onClick="window.close();" class="bbcodes" style="width:100px;" />
			&nbsp;&nbsp;&nbsp;
		</tr>
	</table>
</div>
</body>
</html>
HTML;
} elseif ( $_REQUEST['action'] == "price" ) {
	echoheader();
echo <<<HTML
<div class="blockt">
	Цены на смс
	<div style="float:right; font-size:11px;">
		<a style="color:#fff" href="javascript:history.go(-1);">Назад</a>
	</div>
</div>
<div class="blockc">
	<table id="json" width="100%">
		<thead>
			<tr>
				<td>Количество</td>
				<td>Цена за смс</td>
				<td align="right">Функции</td>
			</tr>
		</thead>
		<tbody>
HTML;
$old = $i = 1;
$result = $db->query( "SELECT * FROM " . $sql['prefix'] . "_tariffs_two;" );
while ( $row = $db->fetchrow( $result ) ) {
	$color = ( $i%2 == 0 ) ? "#ffffff" : "#f8f8f8";
echo "
			<tr style=\"background: " . $color . "\">
				<td>От " . $old . " до " . ( $row['count'] - 1 ) . "</td>
				<td>" . $row['cost'] . "</td>
				<td align=\"right\">
					<a title=\"Правка\" target=\"_blank\" href=\"" . $PHP_SELF . "?mod=delive&hash=" . $global['hash'] . "&action=edit&id=" . $row['id'] . "\">
						<img src=\"admin/template/images/16/edit.png\" />&nbsp;
					</a>
				</td>
			</tr>
";
	$i++;
	$old = $row['count'];
}
echo <<<HTML
		</tbody>
	</table>
</div>
HTML;
	echofooter();
} elseif ( $_REQUEST['action'] == "edit" && preg_match( "/^[0-9]+$/", $_REQUEST['id'] ) ) {
	
	if( $_REQUEST['hash'] == "" or $_REQUEST['hash'] != $global['hash'] ) {
		die( "Hacking..." );
	}
		
	$row = $db->fetchrow( $db->query("SELECT * FROM " . $sql['prefix'] . "_tariffs_two WHERE id={$_REQUEST['id']};") );
		
	echoheader();
echo <<<HTML
<div class="blockt">Редактирование цены</div>
<div class="blockc">
	<form method="POST">
		<table width="100%">
			<tr>
				<td width="150" style="padding:2px;">Количество:</td>
				<td style="padding:2px;">
					<input type="text" name="count" size="100" class="edit bk text" value="{$row['count']}"/>
				</td>
			</tr>
			<tr>
				<td width="150" style="padding:2px;">Цена за смс:</td>
				<td style="padding:2px;">
					<input type="text" name="cost" size="100" class="edit bk text" value="{$row['cost']}"/>
				</td>
			</tr>
			<tr>
				<td style="padding:2px;">&nbsp;</td>
				<td>
					<br />
					<input type="submit" value="&nbsp;&nbsp;Сохранить&nbsp;&nbsp;" class="bbcodes" style="width:100px;">
					&nbsp;&nbsp;&nbsp;&nbsp;
					<input type="button" value="&nbsp;&nbsp;Отмена&nbsp;&nbsp;" class="bbcodes" onclick="window.close();">
					<input type=hidden name="id" value="{$row['id']}">
					<input type=hidden name="action" value="save">
					<input type=hidden name="mod" value="delive">
					<input type="hidden" name="hash" value="{$global['hash']}" />
					<br />
				</td>
			</tr>
		</table>
	</form>
</div>
HTML;
	echofooter();
} elseif ( $_REQUEST['action'] == "save" && preg_match( "/^[0-9]+$/", $_REQUEST['id'] ) ) { 
	
	$cost = floatval( $_REQUEST['cost'] );
	$count = intval( $_REQUEST['count'] );
	if ( $cost && $count ) {
		$db->query( "UPDATE " . $sql['prefix'] . "_tariffs_two SET count=" . $count . ", cost='" . $cost . "' WHERE id={$_REQUEST['id']};" );
		MessageBox( 'Успешно', 'Цена изменена', "?mod=delive&action=price");
	} else {
		MessageBox( 'Внимание', 'Поля не занолнены', "window.close();");
	}

}
?>