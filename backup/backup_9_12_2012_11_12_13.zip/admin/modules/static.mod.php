<?php
#info:static.mod.php world-sms v2.0 25.09.2012
if ( !defined( "SMS_ADMIN" ) ) { die( "Hacking..." ); exit(); }

if ( $_SESSION['admin']['group'] > 1 ) {
	MessageBox( "Ошибка", "У Вас нет прав для просмотра", "?mod=main" );
}

if ( $_REQUEST['action'] == "json" ) {
	if ( $_REQUEST['json_mod'] == "list" or $_REQUEST['json_mod'] == "" ) {
	
		$page = intval( $_REQUEST['page'] );
		$sort = ( $_REQUEST['sort'] == "asc" ) ? "ASC" : "DESC";
		switch ( $_REQUEST['order'] ) {
			case 0: $order = "name"; break;
			case 1: $order = "url"; break;
			case 2: $order = "description"; break;
			case 3: $order = "views"; break;
			default: $order = "name"; break;
		}
		
		$query = "SELECT * FROM " . $sql['prefix'] . "_statics";
		$count = $db->numrows( $db->query( $query . ";" ) );
		$result = $db->query( $query . " ORDER BY " . $order . " " . $sort . " LIMIT " . ( $admin['rows'] * $page ) . ", " . $admin['rows'] . ";" );
		
		$out = array();
		$out['count'] = $count;
		$i = 0;
		while ( $row = $db->fetchrow( $result ) ) {
			$color = ( $i%2 == 0 ) ? "#ffffff" : "#f8f8f8";
			$out['html'] .= "
			<tr style=\"background: " . $color . "\">
				<td>" . $row['name'] . "</td>
				<td>" . $row['url'] . ".html</td>
				<td>" . $row['description'] . "</td>
				<td>" . $row['views'] . "</td>
				<td>
					<a title=\"Перейти\" target=\"_blank\" href=\"" . $config['url_home'] . $row['url'] . ".html\">
						<img src=\"admin/template/images/16/go.png\" />&nbsp;
					</a>
					<a title=\"Правка\" href=\"" . $PHP_SELF . "?mod=static&hash=" . $global['hash'] . "&action=edit&id=" . $row[id] . "\">
						<img src=\"admin/template/images/16/edit.png\" />&nbsp;
					</a>
					<a title=\"Обнулить\" href=\"" . $PHP_SELF . "?mod=static&hash=" . $global['hash'] . "&action=reset&id=" . $row[id] . "\">
						<img src=\"admin/template/images/16/zero.png\" />&nbsp;
					</a>
					<a title=\"Удалить\" href=\"" . $PHP_SELF . "?mod=static&hash=" . $global['hash'] . "&action=del&id=" . $row[id] . "\">
						<img src=\"admin/template/images/16/delete.png\" />&nbsp;
					</a>
				</td>
			<tr>
			";
			$i++;
		}
		if ( $admin['rows'] < $count ) {
			for ( $i = 0; $i <  Ceil( $count/$admin['rows'] ); $i++ ) {
				if ( $page == $i ) {
					$out['page'] .= "<span>" . ( $i+1 ) . "</span>";
				} else {
					$out['page'] .= "<a href=\"#\">" . ( $i+1 ) . "</a>";
				}
			}
		}
		echo $_GET['callback'] . "(" . json_encode( $out ) . ")";
		exit;
	}
}
#лист
if ( $_REQUEST['action'] == "list" or $_REQUEST['action'] == "" ) {
	echoheader();
echo <<<HTML
<div class="blockt">
Список статических страниц (<span id="count"></span>)
</div>
<div class="blockc">
	<table id="json" width="100%">
		<thead>
			<tr>
				<td class="desc">Название</td>
				<td>Ссылка</td>
				<td>Описание</td>
				<td>Количество просмотров</td>
				<td>Функции</td>
			</tr>
		</thead>
		<tbody>
		</tbody>
	</table>
	<table width=100%>
		<tr class="tfoot">
			<td colspan="2"><div class="hr_line"></div></td>
		</tr>
		<tr>
			<td id="page">
				<div class="news_navigation" style="margin-bottom:5px; margin-top:5px;">
				</div>
			</td>
			<td align="right" valign="top">
				<div style="margin-bottom:5px; margin-top:5px;"></div>
			<td>
		</tr>
		<tr>
			<td colspan="2">
				&nbsp;&nbsp;&nbsp;<input type="button" value="&nbsp;&nbsp;Создать новую страницу&nbsp;&nbsp;" class="bbcodes" onclick="document.location='$PHP_SELF?mod=static&action=new'">
			</td>
		</tr>
	</table>
</div>
<script type="text/javascript">
	var page = 0;
	var order = 0;
	var sort = 'asc';
	var find = '';
	function get() {
		$("table#json tbody").html('<tr><td colspan="40" style="background: #ffffff; text-align: center;"><img src="admin/template/images/loading-bar.gif" /></td></tr>');
		$.getJSON( "admin.php?mod=static&action=json&callback=?", 
		{ 
		'page': page,
		'order': order,
		'sort': sort,
		'find': find
		},
		function(data) {
			$("table#json tbody").html(data.html);
			$("td#page div").html(data.page);
			$("#count").html(data.count);
		});
	}
	get();
	$("table#json thead td").live("click", function(){
		order = $(this).index();
		sort =  $(this).attr("class");
		if ( sort == "none" || !sort ) { sort = "asc"; }
		$("table#json thead td").attr("class", "none");
		if ( sort == "asc" ) { $(this).attr("class", "desc"); } else { $(this).attr("class", "asc"); }
		get();
	});
	$("#page a").live("click", function(){
		page = $(this).text() - 1;
		get();
	});
</script>
HTML;
	echofooter();
} elseif ( $_REQUEST['action'] == "new" ) {
	echoheader();
echo <<<HTML
<SCRIPT LANGUAGE="JavaScript">
    function preview(){
		dd=window.open('','prv','height=400,width=750,resizable=1,scrollbars=1')
        document.static.action.value='preview';
		document.static.target='prv'
        document.static.submit(); 
		dd.focus()
        setTimeout("document.static.action.value='save';document.static.target='_self'",500)
    }
</script>
<div class="blockt">
	Создание новой статической страницы
	<div style="float:right; font-size:11px;">
		<a style="color:#fff" href="{$PHP_SELF}?mod=static">Назад</a>
	</div>
</div>
<form method="post" name="static" action="">
<div class="blockc">
	<table width="100%">
		<tr>
			<td width="150" style="padding:2px;">Название:</td>
			<td style="padding:2px;">
				<input type="text" name="name" size="25"  class="edit bk">
			</td>
		</tr>
		<tr>
			<td width="150" style="padding:2px;">Ссылка:</td>
			<td style="padding:2px;">
				<input type="text" name="url" size="25"  class="edit bk">
			</td>
		</tr>
		<tr>
			<td width="150" style="padding:2px;">Заголовок:</td>
			<td style="padding:2px;">
				<input type="text" name="title" size="55"  class="edit bk">
			</td>
		</tr>
		<tr>
			<td width="150" style="padding:2px;">Описание:</td>
			<td style="padding:2px;">
				<input type="text" name="description" size="55"  class="edit bk">
			</td>
		</tr>
		<tr>
			<td style="padding:2px;">Текст</td>
			<td style="padding-left:2px;">
				<script type="text/javascript" src="admin/modules/redactor/ckeditor.js"></script>
				<textarea class="bk" style="width:98%; height:300px;" name="template" id="template"></textarea>
				<script type="text/javascript"> 
					var CKEDITOR_BASEPATH = "admin/modules/redactor";
					CKEDITOR.replace('template',{
						toolbar : 'world'
					});
				</script>
			</td>
		</tr>
		<tr><td colspan="2"><div class="hr_line"></div></td></tr>
		<tr>
			<td height="29" style="padding-left:5px;">Метатеги</td>
			<td><input type="text" name="meta_title" style="width:388px;" class="edit bk"></td>
		</tr>
		<tr>
			<td height="29" style="padding-left:5px;">Описание для статьи</td>
			<td><input type="text" name="meta_descr" style="width:388px;" class="edit bk"> (Не более 200 символов)</td>
		</tr>
		<tr>
			<td height="29" style="padding-left:5px;">Ключевые слова</td>
			<td>
				<textarea name="meta_keys" style="width:388px;height:70px;" class="bk"></textarea>
			</td>
		</tr>
		<tr>
			<td style="padding:2px;"> </td>
			<td>
				<br>
				<br>
				<input type="submit" value="Сохранить" class="btn btn-success" style="width:100px;">
				<input onclick="preview()" type="button" class="btn btn-info" value="Просмотр" style="width:100px;">
				<input type="hidden" name="action" value="save">
				<input type="hidden" name="mod" value="static">
				<input type="hidden" name="save_mode" value="new">
				<input type="hidden" name="hash" value="{$global['hash']}">
				<br>
				<br>
			</td>
		</tr>
	</table>
</div>
</form>
HTML;
} elseif ( $_REQUEST['action'] == "edit" && preg_match( "/^[0-9]+$/", $_REQUEST['id'] ) ) {
	$row = $db->fetchrow( $db->query( "SELECT * FROM " . $sql['prefix'] . "_statics WHERE id=" . $_REQUEST['id'] . ";" ) );
	echoheader();
echo <<<HTML
<SCRIPT LANGUAGE="JavaScript">
    function preview(){
		dd=window.open('','prv','height=400,width=750,resizable=1,scrollbars=1')
        document.static.action.value='preview';
		document.static.target='prv'
        document.static.submit(); 
		dd.focus()
        setTimeout("document.static.action.value='save';document.static.target='_self'",500)
    }
</script>
<div class="blockt">
	Редактирование страницы
	<div style="float:right; font-size:11px;">
		<a style="color:#fff" href="{$PHP_SELF}?mod=static">Назад</a>
	</div>
</div>
<form method="post" name="static" action="">
<div class="blockc">
	<table width="100%">
		<tr>
			<td width="150" style="padding:2px;">Название:</td>
			<td style="padding:2px;">
				<input type="text" name="name" size="25"  class="edit bk" value="{$row['name']}"/>
			</td>
		</tr>
		<tr>
			<td width="150" style="padding:2px;">Заголовок:</td>
			<td style="padding:2px;">
				<input type="text" name="title" size="55"  class="edit bk" value="{$row['title']}"/>
			</td>
		</tr>
		<tr>
			<td width="150" style="padding:2px;">Описание:</td>
			<td style="padding:2px;">
				<input type="text" name="description" size="55"  class="edit bk" value="{$row['description']}"/>
			</td>
		</tr>
		<tr>
			<td style="padding:2px;">Текст</td>
			<td style="padding-left:2px;">
				<script type="text/javascript" src="admin/modules/redactor/ckeditor.js"></script>
				<textarea class="bk" style="width:98%; height:300px;" name="template" id="template">{$row['template']}</textarea>
				<script type="text/javascript"> 
					var CKEDITOR_BASEPATH = "admin/modules/redactor";
					CKEDITOR.replace('template',{
						toolbar : 'world'
					});
				</script>
			</td>
		</tr>
		<tr><td colspan="2"><div class="hr_line"></div></td></tr>
		<tr>
			<td height="29" style="padding-left:5px;">Метатеги</td>
			<td><input type="text" name="meta_title" style="width:388px;" class="edit bk" value="{$row['metatitle']}"/></td>
		</tr>
		<tr>
			<td height="29" style="padding-left:5px;">Описание для статьи</td>
			<td><input type="text" name="meta_descr" style="width:388px;" class="edit bk" value="{$row['metadescr']}"/> (Не более 200 символов)</td>
		</tr>
		<tr>
			<td height="29" style="padding-left:5px;">Ключевые слова</td>
			<td>
				<textarea name="meta_keys" style="width:388px;height:70px;" class="bk">{$row['metakeys']}</textarea>
			</td>
		</tr>
		<tr>
			<td style="padding:2px;"> </td>
			<td>
				<br>
				<br>
				<input type="submit" value="Сохранить" class="btn btn-success" style="width:100px;">
				<input onclick="preview()" type="button" class="btn btn-info" value="Просмотр" style="width:100px;">
				<input type="hidden" name="url" value="{$row['url']}">
				<input type="hidden" name="action" value="save">
				<input type="hidden" name="mod" value="static">
				<input type="hidden" name="save_mode" value="edit">
				<input type="hidden" name="id" value="{$row['id']}">
				<input type="hidden" name="hash" value="{$global['hash']}">
				<br>
				<br>
			</td>
		</tr>
	</table>
</div>
</form>
HTML;
} elseif ( $_REQUEST['action'] == "save" && $_REQUEST['save_mode'] == "edit" ) {
	if( $_REQUEST['hash'] == "" or $_REQUEST['hash'] != $global['hash'] ) {
		die( "Hacking..." );
	}
	
	if( function_exists( "get_magic_quotes_gpc" ) && get_magic_quotes_gpc() ) { 
		$_POST['template'] = stripslashes( $_POST['template'] ); 
	} 
	
	$template = trim( addslashes( $_POST['template'] ) );
	
	$name = htmlspecialchars( strip_tags( trim( $_POST['name'] ) ) );
	$title = htmlspecialchars( strip_tags( trim( $_POST['title'] ) ) );
	$description = htmlspecialchars( strip_tags( trim( $_POST['description'] ) ) );
	$url = htmlspecialchars( strip_tags( trim( $_POST['url'] ) ) );
	
	$meta_title = htmlspecialchars( strip_tags( trim( $_POST['meta_title'] ) ) );
	$meta_descr = htmlspecialchars( strip_tags( trim( $_POST['meta_descr'] ) ) );
	$meta_keys = htmlspecialchars( strip_tags( trim( $_POST['meta_keys'] ) ) );
	
	if( $name == "" or $template == "" ) {
		MessageBox( "Ошибка", "Заполните необходимые поля", "javascript:history.go(-1)" );
	}
	
	$db->query( "UPDATE " . $sql['prefix'] . "_statics SET name='{$name}', title='{$title}',  description='{$description}', template='{$template}', metadescr='{$meta_descr}', metatitle='{$meta_title}', metakeys='{$meta_keys}', author='{$global['name']}', time='{$global['time']}' WHERE id={$_REQUEST['id']};" );
	
	#Генерация saitemap.xml
	$hf = fopen( DIR_ROOT . "/sitemap.xml", "w" );
	fwrite( $hf, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd\">\n" );
	$result = $db->query( "SELECT * FROM " . $sql['prefix'] . "_statics;" );
	while ( $row = $db->fetchrow( $result ) ) {
		fwrite( $hf, "<url><loc>" . $config['url_home'] . $row['url'] . ".html</loc></url>\n" );
	}
	fwrite( $hf, "</urlset>" );
	fclose( $hf );
	
	if ( file_exists( DIR_ROOT . "/cache/sql/" . md5( "SELECT * FROM " . $sql['prefix'] . "_statics WHERE url='" . $url . "';" ) . ".txt" ) ) {
		unlink( DIR_ROOT . "/cache/sql/" . md5( "SELECT * FROM " . $sql['prefix'] . "_statics WHERE url='" . $url . "';" ) . ".txt" );
	}
	
	MessageBox( "Успешно", "Статическая страница успешно изменена и сгенерирована карта сайта", "?mod=static" );
	
	
} elseif ( $_REQUEST['action'] == "save" && $_REQUEST['save_mode'] == "new" ) {
	if( $_REQUEST['hash'] == "" or $_REQUEST['hash'] != $global['hash'] ) {
		die( "Hacking..." );
	}
	
	if( function_exists( "get_magic_quotes_gpc" ) && get_magic_quotes_gpc() ) { 
		$_POST['template'] = stripslashes( $_POST['template'] ); 
	} 
	
	$template = trim( addslashes( $_POST['template'] ) );
	
	$name = htmlspecialchars( strip_tags( trim( $_POST['name'] ) ) );
	$url = htmlspecialchars( strip_tags( trim( $_POST['url'] ) ) );
	$title = htmlspecialchars( strip_tags( trim( $_POST['title'] ) ) );
	$description = htmlspecialchars( strip_tags( trim( $_POST['description'] ) ) );
	
	$meta_title = htmlspecialchars( strip_tags( trim( $_POST['meta_title'] ) ) );
	$meta_descr = htmlspecialchars( strip_tags( trim( $_POST['meta_descr'] ) ) );
	$meta_keys = htmlspecialchars( strip_tags( trim( $_POST['meta_keys'] ) ) );
	
	if( $name == "" or !preg_match( "/^[a-z0-9_]+$/", $url ) or $template == "" ) {
		MessageBox( "Ошибка", "Заполните необходимые поля", "javascript:history.go(-1)" );
	}
	
	$db->query( "INSERT INTO " . $sql['prefix'] . "_statics SET url='{$url}', name='{$name}', title='{$title}',  description='{$description}', template='{$template}', metadescr='{$meta_descr}', metatitle='{$meta_title}', metakeys='{$meta_keys}', author='{$global['name']}', time='{$global['time']}';" );
	
	#Генерация saitemap.xml
	$hf = fopen( DIR_ROOT . "/sitemap.xml", "w" );
	fwrite( $hf, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd\">\n" );
	$result = $db->query( "SELECT * FROM " . $sql['prefix'] . "_statics;" );
	while ( $row = $db->fetchrow( $result ) ) {
		fwrite( $hf, "<url><loc>" . $config['url_home'] . $row['url'] . ".html</loc></url>\n" );
	}
	fwrite( $hf, "</urlset>" );
	fclose( $hf );
	
	MessageBox( "Успешно", "Статическая страница успешно создана и сгенерирована карта сайта", "?mod=static" );
	
	
} elseif ( $_REQUEST['action'] == "preview" ) {
	if( $_REQUEST['hash'] == "" or $_REQUEST['hash'] != $global['hash'] ) {
		die( "Hacking..." );
	}
	
echo <<<HTML
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<link href="{$config['url_home']}templates/default/css/sms.css" rel="stylesheet" type="text/css"/>
	<link href="{$config['url_home']}templates/default/css/skin.css" rel="stylesheet" type="text/css"/>
	<script type="text/javascript" src="="{$config['url_home']}templates/default/js/jquery.js"></script>
</head>
<style>
body {
	background: #FFFFFF;
}
</style>
<body>
	<fieldset style="border-style:solid; border-width:1; border-color:black;">
		<legend>
			<span style="font-size: 10px; font-family: Verdana">Просмотр статической страницы:</span>
		</legend>
			<div class="static">
HTML;
	$title = htmlspecialchars( strip_tags( trim( $_POST['title'] ) ) );
	if ( !empty( $title ) ) { echo "<h2 class=\"head\">" . $title . "</h2>";  }
	echo trim( $_POST['template'] );
echo <<<HTML
			</div>
	</fieldset>
</body>
</html>
HTML;
} elseif ( $_REQUEST['action'] == "reset" && preg_match("/^[0-9]+$/", $_REQUEST['id'] ) ) {
	if( $_REQUEST['hash'] == "" or $_REQUEST['hash'] != $global['hash'] ) {
		die( "Hacking..." );
	}
	
	$db->query( "UPDATE " . $sql['prefix'] . "_statics SET views=0 WHERE id=" . $_REQUEST['id'] . ";" );
	
	MessageBox( "Успешно", "Счетчик страница обнулен", "?mod=static");
} elseif ( $_REQUEST['action'] == "del" && preg_match("/^[0-9]+$/", $_REQUEST['id'] ) ) {
	if( $_REQUEST['hash'] == "" or $_REQUEST['hash'] != $global['hash'] ) {
		die( "Hacking..." );
	}

	$db->query( "DELETE FROM " . $sql['prefix'] . "_statics WHERE id=" . $_REQUEST['id'] . ";" );
	
	#Генерация saitemap.xml
	$hf = fopen( DIR_ROOT . "/sitemap.xml", "w" );
	fwrite( $hf, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd\">\n" );
	$result = $db->query( "SELECT * FROM " . $sql['prefix'] . "_statics;" );
	while ( $row = $db->fetchrow( $result ) ) {
		fwrite( $hf, "<url><loc>" . $config['url_home'] . $row['url'] . ".html</loc></url>\n" );
	}
	fwrite( $hf, "</urlset>" );
	fclose( $hf );
	
	MessageBox( "Успешно", "Страница удалена", "?mod=static");
}
?>