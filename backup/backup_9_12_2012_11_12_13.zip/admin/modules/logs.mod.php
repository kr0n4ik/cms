<?php
#info:admin.php world-sms v2.0 25.09.2012
if ( !defined( "SMS_ADMIN" ) ) { die( "Hacking..." ); exit(); }

if ( $global['group'] > 0 ) {
	MessageBox( "Ошибка", "У Вас нету прав для просмотра", "javascript:history.go(-1)" );
}

if ( $_REQUEST['action'] == "list" or $_REQUEST['action'] == "" ) {
	echoheader();
echo <<<HTML
<div class="blockt">
Список лог файлов
</div>
<div class="blockc">
	<table id="json" width="100%">
		<thead>
			<tr>
				<td class="desc">Имя</td>
				<td>Дата обновления</td>
				<td>Размер</td>
				<td align="right">Функции</td>
			</tr>
		</thead>
		<tbody>
HTML;
		$result = glob( DIR_ROOT . "/logs/*.log.php");
	
		$out = array();
		$i = 0;
		foreach( $result as $name ) {
			$color = ( $i%2 == 0 ) ? "#ffffff" : "#f8f8f8";
			$file = explode( ".", basename( $name ) );
			echo "
			<tr style=\"background: " . $color . "\">
				<td>" . $file[0] . "." . $file[1] . "</td>
				<td>" . date( "H:i d.m.Y", filemtime( $name ) ) . "</td>
				<td>" . formatsize( filesize( $name ) ) . "</td>
				<td align=\"right\">
					<a title=\"Просмотреть\"  href=\"" . $PHP_SELF . "?mod=logs&action=info&file=" . $file[0] . "\">
						<img src=\"admin/template/images/16/info.png\" />&nbsp;
					</a>
					<a title=\"Очистить\"  href=\"" . $PHP_SELF . "?mod=logs&action=clear&file=" . $file[0] . "\">
						<img src=\"admin/template/images/16/clear.png\" />&nbsp;
					</a>
				</td>
			<tr>
			";
			$i++;
		}
echo <<<HTML
		</tbody>
	</table>
	<table width=100%>
		<tr class="tfoot">
			<td colspan="2"><div class="hr_line"></div></td>
		</tr>
		<tr>
			<td id="page">
				<div class="news_navigation" style="margin-bottom:5px; margin-top:5px;">
				</div>
			</td>
			<td align="right" valign="top">
				<div style="margin-bottom:5px; margin-top:5px;"></div>
			<td>
		</tr>
	</table>
</div>
HTML;
	echofooter();
}elseif ( $_REQUEST['action'] == "info" && preg_match( "/^[a-z]+$/", $_REQUEST['file'] ) ) {
	echoheader();
	$content = file_get_contents( DIR_ROOT . "/logs/" . $_REQUEST['file'] . ".log.php" );
	$text = wordwrap( str_replace( "\n", "<br/>", $content ), 300, "<br />", 1 );
echo <<<HTML
<div class="blockt">
	Просмотр - {$_REQUEST['file']}.log
	<div style="float:right; font-size:11px;">
		<a style="color:#fff" href="javascript:history.go(-1);">Назад</a>
	</div>
</div>
<div class="blockc">
	{$text}
</div>
HTML;
	echofooter();
} elseif ( $_REQUEST['action'] == "clear" && preg_match( "/^[a-z]+$/", $_REQUEST['file'] ) ) {
	$hf = fopen( DIR_ROOT . "/logs/" . $_REQUEST['file'] . ".log.php", "a" ); 
	flock ( $hf , LOCK_EX ); 
	ftruncate( $hf, 0 );
	flock ( $hf , LOCK_UN );
	fclose( $hf );
	MessageBox( "Успешно", "Файл " . $_REQUEST['file'] . ".log успешно очишен", "?mod=logs");
}
?>