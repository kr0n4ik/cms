<?php
if ( !defined( "SMS_ADMIN" ) ) { die( "Hacking..." ); exit(); }

if ( $_REQUEST['action'] == "json" ) {
	if ( $_REQUEST['json_mod'] == "email" ) {
	
		$page = intval( $_REQUEST['page'] );
		$sort = ( $_REQUEST['sort'] == "asc" ) ? "ASC" : "DESC";
		switch ( $_REQUEST['order'] ) {
			case 0: $order = "time"; break;
			case 1: $order = "title"; break;
			case 2: $order = "author"; break;
			default: $order = "time"; break;
		}
		
		$query = "SELECT * FROM " . $sql['prefix'] . "_msend_one";
		$count = $db->numrows( $db->query( $query . ";" ) );
		$result = $db->query( $query . " ORDER BY " . $order . " " . $sort . " LIMIT " . ( $admin['rows'] * $page ) . ", " . $admin['rows'] . ";" );
		
		$out = array();
		$out['count'] = $count;
		$i = 0;
		while ( $row = $db->fetchrow( $result ) ) {
			$color = ( $i%2 == 0 ) ? "#ffffff" : "#f8f8f8";
			$out['html'] .= "
			<tr style=\"background: " . $color . "\">
				<td>" . date( "Y-m-d H:i", $row['time'] ) . "</td>
				<td>" . $row['title'] . "</td>
				<td>" . $row['author'] . "</td>
				<td>" . $row['status'] . "</td>
				<td>
					<a title=\"Удалить\" href=\"" . $PHP_SELF . "?mod=msend&hash=" . $global['hash'] . "&action=del&id=" . $row[id] . "\">
						<img src=\"admin/template/images/16/delete.png\" />&nbsp;
					</a>
				</td>
			<tr>
			";
			$i++;
		}
		if ( $admin['rows'] < $count ) {
			for ( $i = 0; $i <  Ceil( $count/$admin['rows'] ); $i++ ) {
				if ( $page == $i ) {
					$out['page'] .= "<span>" . ( $i+1 ) . "</span>";
				} else {
					$out['page'] .= "<a href=\"#\">" . ( $i+1 ) . "</a>";
				}
			}
		}
		if ( $out['html'] == "" ) { $out['html'] = "<tr><td colspan=\"40\" style=\"background: #ffffff; text-align: center;\">Нет записей</td></tr>\n"; }
		echo $_GET['callback'] . "(" . json_encode( $out ) . ")";
		exit;
	}
}

if ( $_REQUEST['action'] == "del" && preg_match("/^[0-9]+$/", $_REQUEST['id'] ) ) {
 	if( $_REQUEST['hash'] == "" or $_REQUEST['hash'] != $global['hash'] ) {
		die( "Hacking..." );
	}

	$db->query( "DELETE FROM " . $sql['prefix'] . "_msend_one WHERE id=" . $_REQUEST['id'] . ";" );
	
	MessageBox( "Успешно", "Рассылка успешно удалена", "?mod=msend");
}

if ( $_REQUEST['service'] == "email" or $_REQUEST['service'] == "" ) {
	#Рассылка по почтовым ящикам
	if ( $_REQUEST['step'] == "" && $_REQUEST['action'] == "" ) {
		echoheader();
echo <<<HTML
<div class="blockt">
Список запланированных рассылок (<span id="count"></span>)
</div>
<div class="blockc">
	<table id="json" width="100%">
		<thead>
			<tr>
				<td class="desc">Дата</td>
				<td>Заголовок</td>
				<td>Автор</td>
				<td>Статус</td>
				<th>Функции</th>
			</tr>
		</thead>
		<tbody>
		</tbody>
	</table>
	<table width=100%>
		<tr class="tfoot">
			<td colspan="2"><div class="hr_line"></div></td>
		</tr>
		<tr>
			<td id="page">
				<div class="news_navigation" style="margin-bottom:5px; margin-top:5px;">
				</div>
			</td>
			<td align="right" valign="top">
				<div style="margin-bottom:5px; margin-top:5px;"></div>
			<td>
		</tr>
		<tr>
			<td colspan="2">
				&nbsp;&nbsp;&nbsp;<input type="button" value="&nbsp;&nbsp;Добавить рассылку&nbsp;&nbsp;" class="bbcodes" onclick="document.location='$PHP_SELF?mod=msend&service=email&step=1'">
			</td>
		</tr>
	</table>
</div>
<script type="text/javascript">
	var page = 0;
	var order = 0;
	var sort = 'asc';
	var find = '';
	function get() {
		$("table#json tbody").html('<tr><td colspan="40" style="background: #ffffff; text-align: center;"><img src="admin/template/images/loading-bar.gif" /></td></tr>');
		$.getJSON( "admin.php?mod=msend&action=json&json_mod=email&callback=?", 
		{ 
		'page': page,
		'order': order,
		'sort': sort,
		'find': find
		},
		function(data) {
			$("table#json tbody").html(data.html);
			$("td#page div").html(data.page);
			$("#count").html(data.count);
		});
	}
	get();
	$("table#json thead td").live("click", function(){
		order = $(this).index();
		sort =  $(this).attr("class");
		if ( sort == "none" || !sort ) { sort = "asc"; }
		$("table#json thead td").attr("class", "none");
		if ( sort == "asc" ) { $(this).attr("class", "desc"); } else { $(this).attr("class", "asc"); }
		get();
	});
	$("#page a").live("click", function(){
		page = $(this).text() - 1;
		get();
	});
</script>
HTML;
		echofooter();
	} elseif ( $_REQUEST['step'] == "1" ) {
		echoheader();
echo <<<HTML
<div class="blockt">Выберите метод отправки</div>
<div class="blockc">
	<form method="POST">
		<input type="hidden" name="step" value="2"/>
		<table width="100%">
			<tr>
				<td width="150" style="padding:2px;">Тип рассылки:</td>
				<td style="padding:2px;">
					<select name="distr">
						<option value="0">Рассылка по пользователям</option>
						<option value="2">Рассылка по новым e-mail</option>
						<option value="1">Рассылка по базе e-mail</option>
					</select>
				</td>
			</tr>
		</table>
		<button type="submit" class="bbcodes">Далеее</button>
	</form>
</div>
HTML;
		echofooter();
	}
	
	if ( $_REQUEST['distr'] == "0" ) {
		if ( $_REQUEST['step'] == "2" ) {
			echoheader();
			$date = date( "Y-m-d H:i ", $global['time'] );
echo <<<HTML
<script type="text/javascript" src="admin/template/js/calendar.js"></script>
<link rel="stylesheet" type="text/css" media="all" href="admin/template/css/calendar-blue.css" />
<div class="blockt">Шаг 2 - Список почтовых ящиков</div>
<div class="blockc">
	<form method="POST">
		<input type="hidden" name="step" value="send"/>
		<input type="hidden" name="distr" value="0"/>
		<table width="100%">
			<tr>
				<td style="padding:2px;">
					<table width="100%">
						<tr>
							<td width="150" style="padding:2px;">Время отправки:</td>
							<td style="padding:2px;">
								<input type="text" name="date" id="date" size="25" class="edit bk text" value="{$date}"/>
								<img src="admin/template/images/img.gif" align="absmiddle" id="trigger_date" style="cursor: pointer; border: 0" title="Выбор даты с помощью календаря"/>
								<input type="checkbox" name="allow_date" value="yes" checked=""/>текущая дата и время
								<script type="text/javascript">
									Calendar.setup({
									  inputField     :    "date",
									  ifFormat       :    "%Y-%m-%d %H:%M ",
									  button         :    "trigger_date",
									  align          :    "Br",
										  timeFormat     :    "24",
										  showsTime      :    true,
									  singleClick    :    true
									});
								</script>
							</td>
						</tr>
						<tr>
							<td width="150" style="padding:2px;">Отправитель:</td>
							<td style="padding:2px;">
								<input type="text" name="sender" size="40" class="edit bk text" value="support@world-sms.ru"/>
							</td>
						</tr>
						<tr>
							<td width="150" style="padding:2px;">Заголовок:</td>
							<td style="padding:2px;">
								<input type="text" name="title" size="40" class="edit bk text"/>
							</td>
						</tr>
						<tr>
							<td width="150" style="padding:2px;">Текст:</td>
							<td style="padding:2px;">
								<textarea class="bk uniform" style="width:99%; height:200px;" name="template"></textarea>
							</td>
						</tr>
					</table>
				</td>
				<td style="padding:2px">
					Получатели:
					<div style="overflow-x: scroll; height: 280px">
						<table width="99%">
HTML;
		$result = $db->query( "SELECT email, nameone, nametwo FROM " . $sql['prefix'] . "_users;" );
		while ( $row = $db->fetchrow( $result ) ) {
			echo "							<tr><td><input name=\"selected[]\" value=\"" . $row['email'] . "\" type=\"checkbox\" checked=\"checked\"></td><td>" . $row['email'] . "</td><td>" . $row['nametwo'] . " " . $row['nameone'] . "</td></tr>";
		}
echo <<<HTML
						</table>
					</div>
				</td>
			</tr>
		</table>	
		<button type="submit" class="bbcodes">Далеее</button>
	</form>
</div>
HTML;
			echofooter();
		} elseif ( $_REQUEST['step'] == "send" ) {
			if( function_exists( "get_magic_quotes_gpc" ) && get_magic_quotes_gpc() ) { 
				$_POST['template'] = stripslashes( $_POST['template'] ); 
			} 
		
			$template = trim( addslashes( $_POST['template'] ) );
			$sender = htmlspecialchars( strip_tags( trim( $_POST['sender'] ) ) );
			$title = htmlspecialchars( strip_tags( trim( $_POST['title'] ) ) );
			$time = DateToTime( $_POST['date'] );
			
			if( $sender == "" || $template == "" || $title == "" ) {
				MessageBox( "Ошибка", "Заполните необходимые поля", "javascript:history.go(-1)" );
			}
			
			if( sizeof( $_REQUEST['selected'] ) == 0 ) {
				MessageBox( "Ошибка", "Нету получателей", "javascript:history.go(-1)" );
			}
			
			if ( $_REQUEST['allow_date'] == "yes" ) {
				$cnt[0] = $cnt[1] = 0;
				foreach ( $_REQUEST['selected'] as $key => $email ) {
					$email = strtolower( $email );
					if ( preg_match( "/^[-a-z0-9\.\-_]+@([-a-z0-9\-]+\.)+[a-z]{2,6}/i", $email ) ) {
						if ( $mail->send( $email, $title, $template, $sender ) ) {
							$status .= "<tr><td style=\"padding:2px;\">" . $email . ":</td><td><font color=\"green\">Отправлен</font></td></tr>";
							$cnt[0]++;
						} else {
							$cnt[1]++;
							$status .= "<tr><td style=\"padding:2px;\">" . $email . ":</td><td><font color=\"red\">Ошибка</font></td></tr>";
						}
					} else {
						$cnt[1]++;
						$status .= "<tr><td style=\"padding:2px;\">" . $email . ":</td><td><font color=\"red\">Ошибка формата e-mail</font></td></tr>";
					}
				}
				echoheader();
echo <<<HTML
<div class="blockt">Статус рассылки</div>
<div class="blockc">
	<div class="katbtop">
			Статус: Отправленных номеров - {$cnt[0]}. Ошибок отправки - {$cnt[1]}.
		</div>
		<table width="80%">
			{$status}
		</table>
		<button type="buuton" onClick="location.href='?mod=msend'" class="bbcodes">Ок</button>
</div>
HTML;
				echofooter();
			} else {
				$db->query( "INSERT INTO " . $sql['prefix'] . "_msend_one SET title='{$title}', template='{$template}', time='{$time}', emails='" . implode( ",", $_REQUEST['selected'] ) . "', sender='{$sender}', author='{$global['name']}', distr='0';" );

				MessageBox( "Успешно", "Рассылка добавлена", "?mod=msend&service=email");
			}	
		}
	} if ( $_REQUEST['distr'] == "2" ) {
		if ( $_REQUEST['step'] == "2" ) {
			echoheader();
echo <<<HTML
<div class="blockt">Шаг 2 - Текст с почтовыми ящиками</div>
<div class="blockc">
	<form method="POST">
		<input type="hidden" name="step" value="3"/>
		<input type="hidden" name="distr" value="2"/>
		<table width="100%">
			<tr>
				<td style="padding:2px;">
				<textarea class="uniform" name="mails" style="width: 100%" rows="15">
				</textarea>	
				</td>
			</tr>
		</table>	
		<button type="submit" class="bbcodes">Далеее</button>
	</form>
</div>
HTML;
			echofooter();
		} elseif ( $_REQUEST['step'] == "3" ) {
			echoheader();
			$date = date( "Y-m-d H:i ", $global['time'] );
echo <<<HTML
<script type="text/javascript" src="admin/template/js/calendar.js"></script>
<link rel="stylesheet" type="text/css" media="all" href="admin/template/css/calendar-blue.css" />
<div class="blockt">Шаг 3 - Список почтовых ящиков</div>
<div class="blockc">
	<form method="POST">
		<input type="hidden" name="step" value="send"/>
		<input type="hidden" name="distr" value="2"/>
		<table width="100%">
			<tr>
				<td style="padding:2px;">
					<table width="100%">
						<tr>
							<td width="150" style="padding:2px;">Время отправки:</td>
							<td style="padding:2px;">
								<input type="text" name="date" id="date" size="25" class="edit bk text" value="{$date}"/>
								<img src="admin/template/images/img.gif" align="absmiddle" id="trigger_date" style="cursor: pointer; border: 0" title="Выбор даты с помощью календаря"/>
								<input type="checkbox" name="allow_date" value="yes" checked=""/>текущая дата и время
								<script type="text/javascript">
									Calendar.setup({
									  inputField     :    "date",
									  ifFormat       :    "%Y-%m-%d %H:%M ",
									  button         :    "trigger_date",
									  align          :    "Br",
										  timeFormat     :    "24",
										  showsTime      :    true,
									  singleClick    :    true
									});
								</script>
							</td>
						</tr>
						<tr>
							<td width="150" style="padding:2px;">Отправитель:</td>
							<td style="padding:2px;">
								<input type="text" name="sender" size="40" class="edit bk text" value="support@world-sms.ru"/>
							</td>
						</tr>
						<tr>
							<td width="150" style="padding:2px;">Заголовок:</td>
							<td style="padding:2px;">
								<input type="text" name="title" size="40" class="edit bk text"/>
							</td>
						</tr>
						<tr>
							<td width="150" style="padding:2px;">Текст:</td>
							<td style="padding:2px;">
								<textarea class="bk uniform" style="width:99%; height:200px;" name="template"></textarea>
							</td>
						</tr>
					</table>
				</td>
				<td style="padding:2px">
					Получатели:
					<div style="overflow-x: scroll; height: 280px">
						<table width="99%">
HTML;
			preg_match_all( "/[-a-z0-9\-_]+@([-a-z0-9\-]+\.)+[a-z]{2,6}/i", $_REQUEST['mails'], $mails );
			foreach ( $mails[0] as $key => $email ) { 
				echo "							<tr><td><input name=\"selected[]\" value=\"" . $email . "\" type=\"checkbox\" checked=\"checked\"></td><td>" . $email . "</td><td>Неизвестно</td></tr>";
			}
echo <<<HTML
						</table>
					</div>
				</td>
			</tr>
		</table>	
		<button type="submit" class="bbcodes">Далеее</button>
	</form>
</div>
HTML;
			echofooter();
		} elseif ( $_REQUEST['step'] == "send" ) {
			if( function_exists( "get_magic_quotes_gpc" ) && get_magic_quotes_gpc() ) { 
				$_POST['template'] = stripslashes( $_POST['template'] ); 
			} 
		
			$template = trim( addslashes( $_POST['template'] ) );
			$sender = htmlspecialchars( strip_tags( trim( $_POST['sender'] ) ) );
			$title = htmlspecialchars( strip_tags( trim( $_POST['title'] ) ) );
			$time = DateToTime( $_POST['date'] );
			
			if( $sender == "" || $template == "" || $title == "" ) {
				MessageBox( "Ошибка", "Заполните необходимые поля", "javascript:history.go(-1)" );
			}
			
			if( sizeof( $_REQUEST['selected'] ) == 0 ) {
				MessageBox( "Ошибка", "Нету получателей", "javascript:history.go(-1)" );
			}
			
			if ( $_REQUEST['allow_date'] == "yes" ) {
				$cnt[0] = $cnt[2] = $cnt[1] = 0;
				foreach ( $_REQUEST['selected'] as $key => $email ) {
					$email = strtolower( $email );
					if ( preg_match( "/^[-a-z0-9\.\-_]+@([-a-z0-9\-]+\.)+[a-z]{2,6}/i", $email ) ) {
						$count = $db->numrows( $db->query( "SELECT * FROM " . $sql['prefix'] . "_memail WHERE taker='" . $email . "';" ) );
						if ( $count == 0 ) {
						if ( $mail->send( $email, $title, $template, $sender ) ) {
								$db->query( "INSERT INTO " . $sql['prefix'] . "_memail SET taker='" . $email . "', time=" . $global['time'] . ", member='" . $_SESSION['admin']['name'] . "';" );
								$status .= "<tr><td style=\"padding:2px;\">" . $email . ":</td><td><font color=\"blue\">Добавлен в базу рассылки</font></td></tr>";
								$status .= "<tr><td style=\"padding:2px;\">" . $email . ":</td><td><font color=\"green\">Отправлен</font></td></tr>";
								$cnt[0]++;
							} else {
								$cnt[1]++;
								$status .= "<tr><td style=\"padding:2px;\">" . $email . ":</td><td><font color=\"red\">Ошибка</font></td></tr>";
							}
						} else {
							$cnt[2]++;
							$status .= "<tr><td style=\"padding:2px;\">" . $email . ":</td><td><font color=\"red\">Номер есть в базе(на него производилась рассылка)</font></td></tr>";
						}
					} else {
						$cnt[1]++;
						$status .= "<tr><td style=\"padding:2px;\">" . $email . ":</td><td><font color=\"red\">Ошибка формата e-mail</font></td></tr>";
					}
				}
				echoheader();
echo <<<HTML
<div class="blockt">Статус рассылки</div>
<div class="blockc">
	<div class="katbtop">
			Статус: Отправленных номеров - {$cnt[0]}. Повторяющихся номеров - {$cnt[2]}. Ошибок отправки - {$cnt[1]}.
		</div>
		<table width="80%">
			{$status}
		</table>
		<button type="buuton" onClick="location.href='?mod=msend'" class="bbcodes">Ок</button>
</div>
HTML;
				echofooter();
			} else {
				$db->query( "INSERT INTO " . $sql['prefix'] . "_msend_one SET title='{$title}', template='{$template}', time='{$time}', emails='" . implode( ",", $_REQUEST['selected'] ) . "', sender='{$sender}', author='{$global['name']}', distr='2';" );

				MessageBox( "Успешно", "Рассылка добавлена", "?mod=msend&service=email");
			}	
		}
	}
}
?>