<?php
#info:admin.php world-sms v2.0 25.09.2012
if ( !defined( "SMS_ADMIN" ) ) { die( "Hacking..." ); exit(); }

if ( $_SESSION['admin']['group'] > 0 ) {
	MessageBox( "Ошибка", "У Вас нет прав для просмотра", "?mod=main" );
}

if ( $_REQUEST['action'] == "json" ) {
	if ( $_REQUEST['json_mod'] == "list" or $_REQUEST['json_mod'] == "" ) {
	
		$page = intval( $_REQUEST['page'] );
		$sort = ( $_REQUEST['sort'] == "asc" ) ? "ASC" : "DESC";
		switch ( $_REQUEST['order'] ) {
			case 0: $order = "email"; break;
			case 1: $order = "regtime"; break;
			case 2: $order = "phone"; break;
			case 3: $order = "purse"; break;
			case 3: $order = "sms"; break;
			case 3: $order = "balance"; break;
			default: $order = "regtime"; break;
		}
		
		$query = "SELECT * FROM " . $sql['prefix'] . "_users";
		$count = $db->numrows( $db->query( $query . ";" ) );
		$result = $db->query( $query . " ORDER BY " . $order . " " . $sort . " LIMIT " . ( $admin['rows'] * $page ) . ", " . $admin['rows'] . ";" );
		
		$out = array();
		$out['count'] = $count;
		$i = 0;
		while ( $row = $db->fetchrow( $result ) ) {
			$color = ( $i%2 != 0 ) ? "#ffffff" : "#f8f8f8";
			$out['html'] .= "
			<tr style=\"background: " . $color . "\">
				<td>" . $row['email'] . "</td>
				<td>" . date( "d.m.Y H:i", $row['regtime'] ) . "</td>
				<td>" . $row['phone'] . "</td>
				<td>" . $row['purse'] . "</td>
				<td>" . $row['sms'] . "</td>
				<td>" . $row['balance'] . "</td>
				<td>
					<a title=\"Информация\" target=\"_blank\" href=\"{$PHP_SELF}?mod=users&hash=" . $global['hash'] . "&action=info&id=" . $row[id] . "\">
						<img src=\"admin/template/images/16/info.png\" />&nbsp;
					</a>
					<a title=\"Отправка e-mail\" target=\"_blank\" href=\"{$PHP_SELF}?mod=users&hash=" . $global['hash'] . "&action=info&id=" . $row[id] . "\">
						<img src=\"admin/template/images/16/send_email.png\" />&nbsp;
					</a>
					<a title=\"Отправка sms\" target=\"_blank\" href=\"{$PHP_SELF}?mod=users&hash=" . $global['hash'] . "&action=info&id=" . $row[id] . "\">
						<img src=\"admin/template/images/16/send_sms.png\" />&nbsp;
					</a>
					<a title=\"Правка\" target=\"_blank\" href=\"{$PHP_SELF}?mod=users&hash=" . $global['hash'] . "&action=edit&id=" . $row[id] . "\">
						<img src=\"admin/template/images/16/edit.png\" />&nbsp;
					</a>
					<a title=\"Операции с переводами\" target=\"_blank\" href=\"{$PHP_SELF}?mod=users&user_hash=" . $global['hash'] . "&action=info&id=" . $row[id] . "\">
						<img src=\"admin/template/images/16/send_email.png\" />&nbsp;
					</a>
					<a title=\"Удалить\" href=\"#\" onClick=\"confirmDelete('{$PHP_SELF}?mod=users&hash=" . $global['hash'] . "&action=del&id=" . $row[id] . "');\">
						<img src=\"admin/template/images/16/delete.png\" />&nbsp;
					</a>
				</td>
			<tr>
			";
			$i++;
		}
		if ( $admin['rows'] < $count ) {
			for ( $i = 0; $i <  Ceil( $count/$admin['rows'] ); $i++ ) {
				if ( $page == $i ) {
					$out['page'] .= "<span>" . ( $i+1 ) . "</span>";
				} else {
					$out['page'] .= "<a href=\"#\">" . ( $i+1 ) . "</a>";
				}
			}
		}
		echo $_GET['callback'] . "(" . json_encode( $out ) . ")";
		exit;
	}
}

if ( $_REQUEST['action'] == "list" or $_REQUEST['action'] == "" ) {
	echoheader();
echo <<<HTML
<script>
function confirmDelete( url ) {
	if (confirm("Вы точно хотите удалить?")) {
		location.href = url;
	}
}
</script>
<div class="blockt">
	Список пользователей (<span id="count"></span>)
</div>
<div class="blockc">
	<table id="json" width="100%">
		<thead>
			<tr>
				<td width="300px">E-mail(Логин)</td>
				<td class="desc" width="130px">Дата регистрации</td>
				<td width="105px">Номер телефона</td>
				<td width="130px">Кошелек</td>
				<td width="80px">Кол. sms</td>
				<td width="60px">Баланс</td>
				<td>Функции</td>
			</tr>
		</thead>
		<tbody>
		</tbody>
	</table>
	<table width=100%>
		<tr class="tfoot">
			<td colspan="2"><div class="hr_line"></div></td>
		</tr>
		<tr>
			<td id="page">
				<div class="news_navigation" style="margin-bottom:5px; margin-top:5px;">
				</div>
			</td>
			<td align="right" valign="top">
				<div style="margin-bottom:5px; margin-top:5px;"></div>
			<td>
		</tr>
	</table>
</div>
<script type="text/javascript">
	var page, order=1, sort, find;
	function get() {
		$("table#json tbody").html('<tr><td colspan="40" style="background: #ffffff; text-align: center;"><img src="admin/template/images/loading-bar.gif" /></td></tr>');
		$.getJSON( "admin.php?mod=users&action=json&callback=?", 
		{ 
		'page': page,
		'order': order,
		'sort': sort,
		'find': find
		},
		function(data) {
			$("table#json tbody").html(data.html);
			$("td#page div").html(data.page);
			$("#count").html(data.count);
		});
	}
	get();
	$("table#json thead td").live("click", function(){
		order = $(this).index();
		sort =  $(this).attr("class");
		if ( sort == "none" || !sort ) { sort = "asc"; }
		$("table#json thead td").attr("class", "none");
		if ( sort == "asc" ) { $(this).attr("class", "desc"); } else { $(this).attr("class", "asc"); }
		get();
	});
	$("#page a").live("click", function(){
		page = $(this).text() - 1;
		get();
	});
</script>
HTML;
	echofooter();
} elseif ( $_REQUEST['action'] == "info" && preg_match("/^[0-9]+$/", $_REQUEST['id'] ) ) {

	if( $_REQUEST['hash'] == "" or $_REQUEST['hash'] != $global['hash'] ) {
		die( "Hacking..." );
	}
	
	$row[0] = $db->fetchrow( $db->query( "SELECT * FROM " . $sql['prefix'] . "_users WHERE id=" . $_REQUEST['id'] . ";" ) );
	$row[0]['countpartone'] = $db->numrows( $db->query( "SELECT * FROM " . $sql['prefix'] . "_partners_two WHERE partone=" . $row[0]['id'] . " AND userid!=0;" ) );
	$row[0]['countparttwo'] = $db->numrows( $db->query( "SELECT * FROM " . $sql['prefix'] . "_partners_two WHERE parttwo=" . $row[0]['id'] . " AND userid!=0;" ) );
	$regtime = date( "H:i d.m.Y", $row[0]['regtime'] );
	$lasttime = date( "H:i d.m.Y", $row[0]['lasttime'] );
	
	echo <<<HTML
<html>
<head>
<meta content="text/html; charset=utf-8" http-equiv="content-type" />
<title>Информация - {$row[0]['email']}</title>
<link rel="stylesheet" type="text/css" href="admin/template/css/style.css" />
<link rel="stylesheet" type="text/css" href="admin/template/css/default.css" />
<script src="admin/template/js/jquery.js" type="text/javascript" charset="utf-8"></script>
	<SCRIPT LANGUAGE="JavaScript">
		function popwindow(url, title){
			dd=window.open(url, title,'height=400, width=750, resizable=1, scrollbars=1 ')
			dd.focus();
		}
	</script>
</head>
<body style="font-size:11px!important; padding:10px">
<div class="blockt">
{$row[0]['email']}
</div>
<div class="blockc">
	<table width="100%">
		<tr>
			<td width="150px" style="padding:5px;">ID:</td>
			<td>{$row[0]['id']}</td>
		</tr>
		<tr>
			<td width="150px" style="padding:5px;">Персональный код:</td>
			<td>{$row[0]['code']}</td>
		</tr>
		<tr>
			<td style="padding:5px;">IP:</td>
			<td><a href="#" onclick="window.opener.document.location='?mod=iptools&ip={$row[0]['regip']}'; return false;">{$row[0]['regip']}</a></td>
		</tr>
		<tr>
			<td style="padding:5px;">Дата регистрации:</td>
			<td>{$regtime}</td>
		</tr>
		<tr>
			<td style="padding:5px;">Дата последнего посещения:</td>
			<td>{$lasttime}</td>
		</tr>
		<tr>
			<td colspan="3"><div class="hr_line"></div></td>
		</tr>
		<tr>
			<td style="padding:5px;">E-mail(Логин):</td>
			<td>{$row[0]['email']}</td>
		</tr>
		<tr>
			<td style="padding:5px;">Телефон:</td>
			<td>{$row[0]['phone']}</td>
		</tr>
		<tr>
			<td style="padding:5px;">Кошелек:</td>
			<td>{$row[0]['purse']}</td>
		</tr>
		<tr>
			<td style="padding:5px;">ICQ:</td>
			<td>{$row[0]['icq']}</td>
		</tr>
		<tr>
			<td style="padding:5px;">Skype:</td>
			<td>{$row[0]['skype']}</td>
		</tr>
		<tr>
			<td colspan="3"><div class="hr_line"></div></td>
		</tr>
		<tr>
			<td style="padding:5px;">Фамилия:</td>
			<td>{$row[0]['nameone']}</td>
		</tr>
		<tr>
			<td style="padding:5px;">Имя:</td>
			<td>{$row[0]['nametwo']}</td>
		</tr>
		<tr>
			<td colspan="3"><div class="hr_line"></div></td>
		</tr>
		<tr>
			<td style="padding:5px;">Количество партенров(первого/второго):</td>
			<td><a href="#" onclick="popwindow('?mod=users&action=partners&hash={$global['hash']}&id={$row[0]['id']}', 'Партнеры');" >{$row[0]['countpartone']}/{$row[0]['countparttwo']}</a></td>
		</tr>
		<tr>
			<td style="padding:5px;">Количество SMS:</td>
			<td>{$row[0]['sms']}</td>
		</tr>
		<tr>
			<td style="padding:5px;">Баланс:</td>
			<td>{$row[0]['balance']}</td>
		</tr>
		<tr>
			<td colspan="3" style="padding-top:10px;padding-bottom:10px;">
			&nbsp;&nbsp;&nbsp;
			<input type="button" value="Закрыть" onClick="window.close();" class="bbcodes" style="width:100px;" />
			&nbsp;&nbsp;&nbsp;
		</tr>
	</table>
</div>
</body>
</html>
HTML;


}elseif ( $_REQUEST['action'] == "partners" && preg_match( "/^[0-9]+$/", $_REQUEST['id'] ) ) {

	if( $_REQUEST['hash'] == "" or $_REQUEST['hash'] != $global['hash'] ) {
		die( "Hacking..." );
	}
	
	function print_partners($id) {
		global $db, $sql;
		$result = $db->query( "SELECT * FROM " . $sql['prefix'] . "_partners_two WHERE partone='{$id}';" );
		$count = $db->numrows( $result );
		$i = 0;
		
		while ( $row[0] = $db->fetchrow( $result ) ) {
			$row[1] = $db->fetchrow( $db->query( "SELECT * FROM " . $sql['prefix'] . "_users WHERE id={$row[0]['userid']};" ) );
			if ( $row[1]['email'] ) {
				$row[1]['print'] = ( $row[1]['nameone'] && $row[1]['nametwo'] ) ? $row[1]['nameone'] . " " . $row[1]['nametwo'] : $row[1]['email'];
				if ( $i == 0 ) echo "<ul>";
				echo "<li><span>" . $row[1]['print'] . "</span></li>";
				print_partners($row[0]['userid']);
				if ( $i == $count )  echo "</ul>";
				$i++;
			} 
		}
		
	}
	
echo <<<HTML
<html>
<head>
<meta content="text/html; charset=utf-8" http-equiv="content-type" />
<title>Дерево партнеров</title>
<link rel="stylesheet" type="text/css" href="admin/template/css/style.css" />
<link rel="stylesheet" type="text/css" href="admin/template/css/default.css" />
<script src="admin/template/js/jquery.js" type="text/javascript" charset="utf-8"></script>
</head>
<body style="font-size:11px!important; padding:10px">
<div class="blockt">
	Партнеры пользователя
</div>
<div class="blockc">
HTML;

$row = array();

$row[0] = $db->fetchrow( $db->query( "SELECT * FROM " . $sql['prefix'] . "_users WHERE id='{$_REQUEST['id']}';" ) );
$row[0]['print'] = ( $row[0]['nameone'] && $row[0]['nametwo'] ) ? $row[0]['nameone'] . " " . $row[0]['nametwo'] : $row[0]['email'];
//$row[0] = $db->fetchrow( $db->query( "SELECT * FROM " . $sql['prefix'] . "_partners_two WHERE userid='{$_REQUEST['id']}';" ) );
//$row[1] = $db->fetchrow( $db->query( "SELECT * FROM " . $sql['prefix'] . "_users WHERE id='{$row[0]['partone']}';" ) );
//$row[2] = $db->fetchrow( $db->query( "SELECT * FROM " . $sql['prefix'] . "_users WHERE id='{$row[0]['parttwo']}';" ) );
//if ( $row[2]['email'] ) echo "<li><span>{$row[2]['email']}</span></li>";
//if ( $row[1]['email'] ) echo "<li><span>{$row[1]['email']}</span></li>";
echo "<li><span class=\"green\">{$row[0]['print']}</span></li>";
print_partners( $row[0]['id'] );
	
echo <<<HTML
			</ul>
		</div>
	</div>
</body>
</html>
HTML;
	
} elseif ( $_REQUEST['action'] == "edit" && preg_match( "/^[0-9]+$/", $_REQUEST['id'] ) ) {

	if( $_REQUEST['hash'] == "" or $_REQUEST['hash'] != $global['hash'] ) {
		die( "Hacking..." );
	}
	
	$row = $db->fetchrow( $db->query( "SELECT * FROM " . $sql['prefix'] . "_users WHERE id=" . $_REQUEST['id'] . ";" ) );
echo <<<HTML
<html>
<head>
<meta content="text/html; charset=utf-8" http-equiv="content-type" />
<title>Правка - {$row['email']}</title>
<link rel="stylesheet" type="text/css" href="admin/template/css/style.css" />
<link rel="stylesheet" type="text/css" href="admin/template/css/default.css" />
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js" type="text/javascript" charset="utf-8"></script>
</head>
<body style="font-size:11px!important; padding:10px">
<form action="" method="post">
<div class="blockt">
{$row['email']}
</div>
<div class="blockc">
	<table width="100%">
		<tr>
			<td style="padding:5px;">E-mail(Логин):</td>
			<td><input size="40" name="edit[email]" value="{$row['email']}" /></td>
		</tr>
		<tr>
			<td style="padding:5px;">Пароль:</td>
			<td><input size="40" name="edit[password]" value="" /></td>
		</tr>
		<tr>
			<td style="padding:5px;">Телефон:</td>
			<td><input size="40" name="edit[phone]" value="{$row['phone']}" /></td>
		</tr>
		<tr>
			<td style="padding:5px;">Кошелек:</td>
			<td><input size="40" name="edit[purse]" value="{$row['purse']}" /></td>
		</tr>
		<tr>
			<td style="padding:5px;">ICQ:</td>
			<td><input size="40" name="edit[icq]" value="{$row['icq']}" /></td>
		</tr>
		<tr>
			<td style="padding:5px;">Skype:</td>
			<td><input size="40" name="edit[skype]" value="{$row['skype']}" /></td>
		</tr>
		<tr>
			<td colspan="3"><div class="hr_line"></div></td>
		</tr>
		<tr>
			<td style="padding:5px;">Фамилия:</td>
			<td><input size="40" name="edit[nameone]" value="{$row['nameone']}" /></td>
		</tr>
		<tr>
			<td style="padding:5px;">Имя:</td>
			<td><input size="40" name="edit[nametwo]" value="{$row['nametwo']}" /></td>
		</tr>
		<tr>
			<td style="padding:5px;">Код регистрации:</td>
			<td><input size="40" name="edit[code]" value="{$row['code']}" /></td>
		</tr>
		<tr>
			<td colspan="3"><div class="hr_line"></div></td>
		</tr>
		<tr>
			<td style="padding:5px;">Количество SMS:</td>
			<td><input size="40" name="edit[sms]" value="{$row['sms']}" /></td>
		</tr>
		<tr>
			<td style="padding:5px;">Баланс:</td>
			<td>{$row['balance']}</td>
		</tr>
		<tr>
			<td colspan="3"><div class="hr_line"></div></td>
		</tr>
		<tr>
			<td style="padding:5px;">Описание:</td>
			<td colspan="2">
			<textarea style="width:100%; height:60px;" name="edit[about]" >{$row['about']}</textarea>
			</td>
		</tr>
		<tr>
			<td colspan="3" style="padding-top:10px;padding-bottom:10px;">
			<input type="submit" value="Сохранить" class="bbcodes" style="width:100px;" />
			&nbsp;&nbsp;&nbsp;
			<input type="button" value="Отмена" onClick="window.close();" class="bbcodes" style="width:100px;" />
			&nbsp;&nbsp;&nbsp;
			<input type="hidden" name="id" value="{$row['id']}">
			<input type="hidden" name="mod" value="users">
			<input type="hidden" name="hash" value="{$global['hash']}">
			<input type="hidden" name="action" value="save">
		</tr>
	</table>
</div>
</form>
</body>
</html>
HTML;
} elseif ( $_REQUEST['action'] == "save" && preg_match( "/^[0-9]+$/", $_REQUEST['id'] ) ) {
	if( $_REQUEST['hash'] == "" or $_REQUEST['hash'] != $global['hash'] ) {
		die( "Hacking..." );
	}
	foreach ( $_REQUEST['edit'] as $key => $value ) {
		$$key = $db->escape( trim( strip_tags( stripslashes( $value ) ) ) );
	}
	
	$db->query( "UPDATE ". $sql['prefix'] . "_users SET email='" . $email . "',  phone='" . $phone . "', nameone='" . $nameone . "', nametwo='" . $nametwo . "', purse='" . $purse . "', icq='" . $icq . "', skype='" . $skype . "', code='" . $code . "', sms='{$sms}' WHERE id={$_REQUEST['id']};" );
	
	if ( $password ) {
		$password = md5( $password . md5( $password ).$config['salt'] . "\n" );
		$db->query( "UPDATE ". $sql['prefix'] . "_users SET password='" . $password . "' WHERE id={$_REQUEST['id']};" );
	}
	
	header( "Location: " . $_SERVER['REQUEST_URI'] );
} elseif ( $_REQUEST['action'] == "del" && preg_match("/^[0-9]+$/", $_REQUEST['id'] ) ) {
	if( $_REQUEST['hash'] == "" or $_REQUEST['hash'] != $global['hash'] ) {
		die( "Hacking..." );
	}
	$db->query( "DELETE FROM " . $sql['prefix'] . "_users WHERE id=" . $_REQUEST['id'] . ";" );
	MessageBox( "Успешно", "Пользователь удален", "?mod=users");
}
?>