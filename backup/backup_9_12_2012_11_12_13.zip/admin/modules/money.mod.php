<?php
#info:admin.php world-sms v2.0 25.09.2012
if ( !defined( "SMS_ADMIN" ) ) { die( "Hacking..." ); exit(); }

if ( $_SESSION['admin']['group'] > 0 ) {
	MessageBox( "Ошибка", "У Вас нет прав для просмотра", "?mod=main" );
}

if ( $_REQUEST['action'] == "json" ) {
	if ( $_REQUEST['json_mod'] == "amount" ) {
	
		$page = intval( $_REQUEST['page'] );
		$sort = ( $_REQUEST['sort'] == "asc" ) ? "ASC" : "DESC";
		switch ( $_REQUEST['order'] ) {
			case 0: $order = "email"; break;
			case 1: $order = "regtime"; break;
			case 2: $order = "phone"; break;
			case 3: $order = "purse"; break;
			case 3: $order = "sms"; break;
			case 3: $order = "balance"; break;
			default: $order = "email"; break;
		}
		
		$query = "SELECT * FROM " . $sql['prefix'] . "_users WHERE balance>0";
		$count = $db->numrows( $db->query( $query . ";" ) );
		$result = $db->query( $query . " ORDER BY " . $order . " " . $sort . ";" );
		
		$out = array();
		$out['count'] = $count;
		$out['html'] = "";
		$out['page'] = "";
		$out['count'] = $count;
		$i = 0;
		while ( $row = $db->fetchrow( $result ) ) {
			$color = ( $i%2 != 0 ) ? "#ffffff" : "#f8f8f8";
			$row['email'] = ( $row['nameone'] && $row['nametwo'] ) ? $row['nametwo'] . " " . $row['nameone'] : $row['email'];
			$out['html'] .= "
			<tr style=\"background: " . $color . "\">
				<td><input name=\"selected[]\" value=\"{$row[id]}\" type=\"checkbox\"></td>
				<td>" . $row['email'] . "</td>
				<td>" . date( "d.m.Y H:i", $row['regtime'] ) . "</td>
				<td>" . $row['phone'] . "</td>
				<td>" . $row['purse'] . "</td>
				<td>" . $row['balance'] . "</td>
				<td>
					<a title=\"Информация о пользователе\" target=\"_blank\" href=\"{$PHP_SELF}?mod=users&hash=" . $global['hash'] . "&action=info&id=" . $row[id] . "\">
						<img src=\"admin/template/images/16/info.png\" />&nbsp;
					</a>
				</td>
			<tr>
			";
			$i++;
		}
		if ( $admin['rows'] < $count ) {
			for ( $i = 0; $i <  Ceil( $count/$admin['rows'] ); $i++ ) {
				if ( $page == $i ) {
					$out['page'] .= "<span>" . ( $i+1 ) . "</span>";
				} else {
					$out['page'] .= "<a href=\"#\">" . ( $i+1 ) . "</a>";
				}
			}
		}
		
		$out['html'] = ( $out['html'] ) ? $out['html'] : "<tr><td colspan=\"10\" style=\"background: #ffffff; text-align: center;\">Нет записей</td></tr>\n";
		
		echo $_GET['callback'] . "(" . json_encode( $out ) . ")";
		exit;
	} elseif ( $_REQUEST['json_mod'] == "transactions" ) {
	
		$page = intval( $_REQUEST['page'] );
		$sort = ( $_REQUEST['sort'] == "asc" ) ? "ASC" : "DESC";
		$find = ( preg_match( "/^[a-z0-9]+$/i", $_REQUEST['find'] ) ) ? "WHERE direct='" . $_REQUEST['find'] . "'" : ""; 
		switch ( $_REQUEST['order'] ) {
			case 0: $order = "time"; break;
			case 1: $order = "amount"; break;
			case 2: $order = "reason"; break;
			default: $order = "time"; break;
		}
		
		$query = "SELECT * FROM " . $sql['prefix'] . "_transactions " . $find;
		$count = $db->numrows( $db->query( $query . ";" ) );
		$result = $db->query( $query . " ORDER BY " . $order . " " . $sort . " LIMIT " . ( $admin['rows'] * $page ) . ", " . $admin['rows'] . ";" );
		
		$out = array();
		$out['html'] = "";
		$out['page'] = "";
		$out['count'] = $count;
		$i = 0;
		while ( $row = $db->fetchrow( $result ) ) {
			$info = $db->fetchrow( $db->query( "SELECT * FROM " . $sql['prefix'] . "_users WHERE id=" . $row['userid'] . ";" ) );
			$email = ( $info['nameone'] && $info['nametwo'] ) ? $info['nametwo'] . " " . $info['nameone'] : $info['email'];
			$color = ( $i%2 != 0 ) ? "#ffffff" : "#f8f8f8";
			switch ( $row['direct'] ) {
				case "buy":
				$color = "#C8C8FA";
				break;
				case "pay":
				$color = "#FAC8C8";
				break;
			}
			$out['html'] .= "
			<tr style=\"background: " . $color . "\">
				<td>" . date( "d.m.Y H:i:s", $row['time'] ) . "</td>
				<td>" . $row['amount'] . "</td>
				<td>" . $row['reason'] . "</td>
				<td>" . $email . "</td>
				<td>
					<a title=\"Информация о пользователе\" target=\"_blank\" href=\"{$PHP_SELF}?mod=users&hash=" . $global['hash'] . "&action=info&id=" . $row['userid'] . "\">
						<img src=\"admin/template/images/16/info.png\" />&nbsp;
					</a>
				</td>
			<tr>
			";
			$i++;
		}
		
		
		if ( $admin['rows'] < $count ) {
			for ( $i = 0; $i <  Ceil( $count/$admin['rows'] ); $i++ ) {
				if ( $page == $i ) {
					$out['page'] .= "<span>" . ( $i+1 ) . "</span>";
				} else {
					$out['page'] .= "<a href=\"#\">" . ( $i+1 ) . "</a>";
				}
			}
		}
		
		$out['html'] = ( $out['html'] ) ? $out['html'] : "<tr><td colspan=\"10\" style=\"background: #ffffff; text-align: center;\">Нет записей</td></tr>\n";
		
		echo $_GET['callback'] . "(" . json_encode( $out ) . ")";
		exit;
	}
}

if ( $_REQUEST['action'] == "main" or $_REQUEST['action'] == "" ) {
	echoheader();
echo <<<HTML
<div class="blockt">Доступ к разделам управлением денежными средствами</div>
<div class="blockc">
	<table width="100%">
		<tr>
			<td>
				<table width="100%">
					<tr>
						<td width="70" height="70" valign="middle" align="center" style="padding-top:5px;padding-bottom:5px;">
							<img src="admin/template/images/awards_auto.png" border="0">
						</td>
						<td valign="middle">
							<div class="quick">
								<a href="?mod=money&action=amount">
									<h3>Выплаты</h3>
									Расчет выплат по партнерской программе
								</a>
							</div>
						</td>
					</tr>
				</table>
			</td>
			<td>
				<table width="100%">
					<tr>
						<td width="70" height="70" valign="middle" align="center" style="padding-top:5px;padding-bottom:5px;">
							<img src="admin/template/images/table.png" border="0">
						</td>
						<td valign="middle">
							<div class="quick">
								<a href="?mod=money&action=transactions">
									<h3>Денежные переводы</h3>
									Денежные переводы, покупка и выплаты для всех пользователей
								</a>
							</div>
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
</div>
HTML;
	echofooter();
} elseif ( $_REQUEST['action'] == "amount" ) {
	echoheader();
echo <<<HTML
<div class="blockt">
	Список пользователей (<span id="count"></span>)
	<div style="float:right; font-size:11px;">
		<a style="color:#fff" href="javascript:history.go(-1);">Назад</a>
	</div>
</div>
<div class="blockc">
<form method="POST">
	<input type="hidden" name="action" value="pay"/>
	<input type="hidden" name="hash" value="{$global['hash']}"/>
	<table id="json" width="100%">
		<thead>
			<tr>
				<th width="10">
					
				</th>
				<th width="300px">Пользователь</th>
				<td width="130px">Дата регистрации</td>
				<td width="105px">Номер телефона</td>
				<td width="130px">Кошелек</td>
				<td class="desc" width="60px">Баланс</td>
				<th width="80">Функции</th>
			</tr>
		</thead>
		<tbody>
		</tbody>
	</table>
	<table width=100%>
		<tr class="tfoot">
			<td colspan="2"><div class="hr_line"></div></td>
		</tr>
		<tr>
			<td id="page">
				<div class="news_navigation" style="margin-bottom:5px; margin-top:5px;">
				</div>
			</td>
			<td align="right" valign="top">
				<div style="margin-bottom:5px; margin-top:5px;"></div>
			<td>
			<tr>
				<td colspan="2">
					&nbsp;&nbsp;&nbsp;<input type="submit" value="&nbsp;&nbsp;Выплатить&nbsp;&nbsp;" class="bbcodes"/>
				</td>
			</tr>
		</tr>
	</table>
</form>
</div>
<script type="text/javascript">
	var page, order, sort, find;
	function get() {
		$("table#json tbody").html('<tr><td colspan="40" style="background: #ffffff; text-align: center;"><img src="admin/template/images/loading-bar.gif" /></td></tr>');
		$.getJSON( "admin.php?mod=money&action=json&json_mod=amount&callback=?", 
		{ 
		'page': page,
		'order': order,
		'sort': sort,
		'find': find
		},
		function(data) {
			$("table#json tbody").html(data.html);
			$("td#page div").html(data.page);
			$("#count").html(data.count);
		});
	}
	get();
	$("table#json thead td").live("click", function(){
		order = $(this).index();
		sort =  $(this).attr("class");
		if ( sort == "none" || !sort ) { sort = "asc"; }
		$("table#json thead td").attr("class", "none");
		if ( sort == "asc" ) { $(this).attr("class", "desc"); } else { $(this).attr("class", "asc"); }
		get();
	});
	$("#page a").live("click", function(){
		page = $(this).text() - 1;
		get();
	});
</script>
HTML;

echo <<<HTML
</tr></table>

</div>
<div class="blockt">Информация о состоянии счета</div>
<div class="blockc">
<table width="50%">
HTML;

$info = array();

$count = $db->fetchrow( $db->query( "SELECT SUM(balance) as sum FROM " . $sql['prefix'] . "_users;" ) );
$info[] = "<tr style=\"padding:2px;\"><td>Общая сумма выплат: </td><td>{$count['sum']}</td></tr>";

foreach ( $info as $val ) {
	echo $val;
}

echo <<<HTML
</table>
</div>
HTML;
	echofooter();	
}elseif ( $_REQUEST['action'] == "transactions" ) {
	echoheader();
echo <<<HTML
<div class="blockt">
	Список переводов (<span id="count"></span>)
	<div style="float:right; font-size:11px;">
		<a style="color:#fff" href="javascript:history.go(-1);">Назад</a>
	</div>
</div>
<div class="blockc">
	<table id="json" width="100%">
		<thead>
			<tr>
				<td class="desc" width="300px">Дата</td>
				<td width="150px">Сумма</td>
				<td>Причина</td>
				<th width="150px">Пользователь</th>
				<th width="80">Функции</th>
			</tr>
		</thead>
		<tbody>
		</tbody>
	</table>
	<table width=100%>
		<tr class="tfoot">
			<td colspan="2"><div class="hr_line"></div></td>
		</tr>
		<tr>
			<td id="page">
				<div class="news_navigation" style="margin-bottom:5px; margin-top:5px;">
				</div>
			</td>
			<td align="right" valign="top">
				<div style="margin-bottom:5px; margin-top:5px;"></div>
			<td>
			<tr>
				<td colspan="2">
					&nbsp;&nbsp;&nbsp;<button onclick="sorted('');" class="bbcodes">&nbsp;&nbsp;Все&nbsp;&nbsp;</button>
					&nbsp;&nbsp;&nbsp;<button onclick="sorted('buy');" class="bbcodes">Покупки</button>
					&nbsp;&nbsp;&nbsp;<button onclick="sorted('pay');" class="bbcodes">Выплаты&nbsp</button>
				</td>
			</tr>
		</tr>
	</table>
</div>
<script type="text/javascript">
	var page, order, sort, find;
	function get() {
		$("table#json tbody").html('<tr><td colspan="40" style="background: #ffffff; text-align: center;"><img src="admin/template/images/loading-bar.gif" /></td></tr>');
		$.getJSON( "admin.php?mod=money&action=json&json_mod=transactions&callback=?", 
		{ 
		'page': page,
		'order': order,
		'sort': sort,
		'find': find
		},
		function(data) {
			$("table#json tbody").html(data.html);
			$("td#page div").html(data.page);
			$("#count").html(data.count);
		});
	}
	get();
	$("table#json thead td").live("click", function(){
		order = $(this).index();
		sort =  $(this).attr("class");
		if ( sort == "none" || !sort ) { sort = "asc"; }
		$("table#json thead td").attr("class", "none");
		if ( sort == "asc" ) { $(this).attr("class", "desc"); } else { $(this).attr("class", "asc"); }
		get();
	});
	$("#page a").live("click", function(){
		page = $(this).text() - 1;
		get();
	});
	function sorted(v) {
		find = v;
		get();
	}
</script>
HTML;
	echofooter();	
} elseif ( $_REQUEST['action'] == "pay" ) {

	if( $_REQUEST['hash'] == "" or $_REQUEST['hash'] != $global['hash'] ) {
		die( "Hacking..." );
	}
	
	foreach ( $_REQUEST['selected'] as $id ) {
		$row = $db->fetchrow( $db->query( "SELECT * FROM " . $sql['prefix'] . "_users WHERE id=" . intval( $id ) . ";" ) );
		if ( $row['balance'] > 0 ) {
			$db->query( "INSERT INTO " . $sql['prefix'] . "_transactions SET userid={$row['id']}, amount='{$row['balance']}', direct='pay', time={$global['time']}, reason='Выплата';" );
			$db->query( "UPDATE " . $sql['prefix'] . "_users SET balance=0 WHERE id=" . intval( $id ) . ";" );
		}
	}
	
	MessageBox( "Успешно", "Счетчики выплат обнулились", "?mod=money");
}
?>