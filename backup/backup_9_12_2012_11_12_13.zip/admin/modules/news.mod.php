<?php
#info:admin.php world-sms v2.0 25.09.2012
if ( !defined( "SMS_ADMIN" ) ) { die( "Hacking..." ); exit(); }

if ( $_SESSION['admin']['group'] > 1 ) {
	MessageBox( "Ошибка", "У Вас нет прав для просмотра", "?mod=main" );
}

if ( $_REQUEST['action'] == "json" ) {
	if ( $_REQUEST['json_mod'] == "list" or $_REQUEST['json_mod'] == "" ) {
	
		$page = intval( $_REQUEST['page'] );
		$sort = ( $_REQUEST['sort'] == "asc" ) ? "ASC" : "DESC";
		switch ( $_REQUEST['order'] ) {
			case 0: $order = "title"; break;
			case 1: $order = "time"; break;
			case 2: $order = "author"; break;
			default: $order = "title"; break;
		}
		
		$query = "SELECT * FROM " . $sql['prefix'] . "_news";
		$count = $db->numrows( $db->query( $query . ";" ) );
		$result = $db->query( $query . " ORDER BY " . $order . " " . $sort . " LIMIT " . ( $admin['rows'] * $page ) . ", " . $admin['rows'] . ";" );
		
		$out = array();
		$out['count'] = $count;
		$i = 0;
		while ( $row = $db->fetchrow( $result ) ) {
			$color = ( $i%2 == 0 ) ? "#ffffff" : "#f8f8f8";
			$out['html'] .= "
			<tr style=\"background: " . $color . "\">
				<td>" . $row['title'] . "</td>
				<td>" . date( "Y-m-d H:i", $row['time'] ) . "</td>
				<td>" . $row['author'] . "</td>
				<td>
					<a title=\"Удалить\" href=\"#\" onClick=\"confirmDelete('" . $PHP_SELF . "?mod=news&hash=" . $global['hash'] . "&action=del&id=" . $row[id] . "');\">
						<img src=\"admin/template/images/16/delete.png\" />&nbsp;
					</a>
				</td>
			<tr>
			";
			$i++;
		}
		if ( $admin['rows'] < $count ) {
			for ( $i = 0; $i <  Ceil( $count/$admin['rows'] ); $i++ ) {
				if ( $page == $i ) {
					$out['page'] .= "<span>" . ( $i+1 ) . "</span>";
				} else {
					$out['page'] .= "<a href=\"#\">" . ( $i+1 ) . "</a>";
				}
			}
		}
		if ( $out['html'] == "" ) { $out['html'] = "<tr><td colspan=\"40\" style=\"background: #ffffff; text-align: center;\">Нет записей</td></tr>\n"; }
		echo $_GET['callback'] . "(" . json_encode( $out ) . ")";
		exit;
	}
}
if ( $_REQUEST['action'] == "list" or $_REQUEST['action'] == "" ) {
	echoheader();
echo <<<HTML
<script>
function confirmDelete( url ) {
	if (confirm("Вы точно хотите удалить?")) {
		location.href = url;
	}
}
</script>
<div class="blockt">
Список новостей (<span id="count"></span>)
</div>
<div class="blockc">
	<table id="json" width="100%">
		<thead>
			<tr>
				<td class="desc">Заголовок</td>
				<td width="200px">Дата</td>
				<td width="100px">Автор</td>
				<th width="100px">Функции</th>
			</tr>
		</thead>
		<tbody>
		</tbody>
	</table>
	<table width=100%>
		<tr class="tfoot">
			<td colspan="2"><div class="hr_line"></div></td>
		</tr>
		<tr>
			<td id="page">
				<div class="news_navigation" style="margin-bottom:5px; margin-top:5px;">
				</div>
			</td>
			<td align="right" valign="top">
				<div style="margin-bottom:5px; margin-top:5px;"></div>
			<td>
		</tr>
		<tr>
			<td colspan="2">
				&nbsp;&nbsp;&nbsp;<input type="button" value="&nbsp;&nbsp;Добавить новость&nbsp;&nbsp;" class="bbcodes" onclick="document.location='$PHP_SELF?mod=news&action=new'">
			</td>
		</tr>
	</table>
</div>
<script type="text/javascript">
	var page = 0;
	var order = 0;
	var sort = 'asc';
	var find = '';
	function get() {
		$("table#json tbody").html('<tr><td colspan="40" style="background: #ffffff; text-align: center;"><img src="admin/template/images/loading-bar.gif" /></td></tr>');
		$.getJSON( "admin.php?mod=news&action=json&callback=?", 
		{ 
		'page': page,
		'order': order,
		'sort': sort,
		'find': find
		},
		function(data) {
			$("table#json tbody").html(data.html);
			$("td#page div").html(data.page);
			$("#count").html(data.count);
		});
	}
	get();
	$("table#json thead td").live("click", function(){
		order = $(this).index();
		sort =  $(this).attr("class");
		if ( sort == "none" || !sort ) { sort = "asc"; }
		$("table#json thead td").attr("class", "none");
		if ( sort == "asc" ) { $(this).attr("class", "desc"); } else { $(this).attr("class", "asc"); }
		get();
	});
	$("#page a").live("click", function(){
		page = $(this).text() - 1;
		get();
	});
</script>
HTML;
	echofooter();
} elseif ( $_REQUEST['action'] == "new" ) {
	echoheader();
	$time = date( "Y-m-d H:i", $global['time'] );
echo <<<HTML
<script type="text/javascript" src="admin/template/js/calendar.js"></script>
<link rel="stylesheet" type="text/css" media="all" href="admin/template/css/calendar-blue.css" />
<div class="blockt">
	Создание новой статической страницы
	<div style="float:right; font-size:11px;">
		<a style="color:#fff" href="javascript:history.go(-1);">Назад</a>
	</div>
</div>
<form method="post" name="static" action="">
<div class="blockc">
	<table width="100%">
		<tr>
			<td width="150" style="padding:2px;">Дата публикации:</td>
			<td style="padding:2px;">
				<input type="text" name="date" id="date" size="18" maxlength="16" class="edit bk" value="{$time}" />
				<img src="admin/template/images/img.gif"  align="absmiddle" id="trigger_news" style="cursor: pointer; border: 0" title="Дата публекации"/>
				<script type="text/javascript">
					Calendar.setup({
					  inputField     :    "date",
					  ifFormat       :    "%d.%m.%Y",
					  button         :    "trigger_news",
					  align          :    "Br",
						  timeFormat     :    "24",
						  showsTime      :    false,
					  singleClick    :    true
					});
				</script>
			</td>
		</tr>
		<tr>
			<td width="150" style="padding:2px;">Заголовок:</td>
			<td style="padding:2px;">
				<input type="text" name="title" size="55"  class="edit bk">
			</td>
		</tr>
		<tr>
			<td style="padding:2px;">Текст</td>
			<td style="padding-left:2px;">
				<textarea class="bk" style="width:98%; height:300px;" name="template" ></textarea>
			</td>
		</tr>
		<tr>
			<td style="padding:2px;"></td>
			<td>
				<br>
				<br>
				<input type="submit" value="Сохранить" class="btn btn-success" style="width:100px;">
				<input type="hidden" name="action" value="save">
				<input type="hidden" name="mod" value="news">
				<input type="hidden" name="hash" value="{$global['hash']}">
				<br>
				<br>
			</td>
		</tr>
	</table>
</div>
</form>
HTML;
} elseif ( $_REQUEST['action'] == "save" ) {
	if( $_REQUEST['hash'] == "" || $_REQUEST['hash'] != $global['hash'] ) {
		die( "Hacking..." );
	}

	if( function_exists( "get_magic_quotes_gpc" ) && get_magic_quotes_gpc() ) { 
		$_POST['template'] = stripslashes( $_POST['template'] ); 
	} 
	$template = trim( addslashes( $_POST['template'] ) );
	$title = htmlspecialchars( strip_tags( trim( $_POST['title'] ) ) );
	$time = ( $_POST['date'] ) ? DateToTime( $_POST['date'] ) : $global['time'];
	
	if( $title == "" || $template == "" ) {
		MessageBox( "Ошибка", "Заполните необходимые поля", "javascript:history.go(-1)" );
	}
	
	$db->query( "INSERT INTO " . $sql['prefix'] . "_news SET title='{$title}', template='{$template}', time='{$time}', author='{$global['name']}';" );
	
	MessageBox( "Успешно", "Новость успешно добавлена", "?mod=news" );
} elseif ( $_REQUEST['action'] == "del" && preg_match("/^[0-9]+$/", $_REQUEST['id'] ) ) {
	if( $_REQUEST['hash'] == "" or $_REQUEST['hash'] != $global['hash'] ) {
		die( "Hacking..." );
	}

	$db->query( "DELETE FROM " . $sql['prefix'] . "_news WHERE id=" . $_REQUEST['id'] . ";" );

	MessageBox( "Успешно", "Новость удалена", "?mod=news");
}
?>