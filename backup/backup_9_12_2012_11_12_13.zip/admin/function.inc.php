<?php
#info:init.php world-sms v2.0 25.09.2012
if ( !defined( "SMS_ADMIN" ) ) { die( "Hacking..." ); exit(); }

function MessageBox( $title, $text, $back = FALSE) {

	if( $back ) {
		$back = "<br /><br> <a class=main href=\"{$back}\">Назад</a>";
	}
	
	echoheader();
echo <<<HTML
<div class="blockt">{$title}</div>
<div class="blockc">
<table width="100%">
    <tr>
        <td height="100" align="center">{$text} {$back}</td>
    </tr>
</table>
</div>
HTML;
	echofooter();
	exit;
}

function echoheader() {
	global $skin_header, $global, $a_group;
	
	$skin_header = str_replace("{name}", $global['name'], $skin_header);
	$skin_header = str_replace("{group}", $a_group[$global['group']], $skin_header);
	echo $skin_header;
}

function echofooter() {
	global $skin_footer;
	
	echo $skin_footer;

}

function echologin() {
	global $skin_login, $result;
	
	$skin_login = str_replace("{result}", $result, $skin_login);
	echo $skin_login;
}

function write_log( $log, $line ) {
	global $global;
	if( !file_exists( DIR_ROOT . "/logs/{$log}.log.php" ) ) {
		$hf = fopen( DIR_ROOT . "/logs/{$log}.log.php", "w" );
	} else {
		$hf = fopen( DIR_ROOT . "/logs/{$log}.log.php", "a+" );
	}
	$line = htmlspecialchars( trim( substr( $line, 0, 500 ) ), ENT_QUOTES );
	$url = htmlspecialchars( trim( getenv( "REQUEST_URI" ) ), ENT_QUOTES );
	$ip = $_SERVER['REMOTE_ADDR'];
	fwrite( $hf, date( "d.m.Y H:i:s", $global['time'] ) . "\n{$line}\n-------------------------------------------------------\nURL: {$url}\nIP: {$ip}\n====================================================================================================================\n" );
	fclose( $hf );
}

function DateToTime( $date ) {
	$aDateTime = explode( ' ', $date );
	$aDate = explode( '-', $aDateTime[0] );
	$aTime = explode( ':', $aDateTime[1] );
	return mktime( intval( $aTime[0] ), intval( $aTime[1] ), intval( $aTime[2] ), intval( $aDate[1] ), intval( $aDate[2] ), intval( $aDate[0] ) );
	
}

function formatsize($file_size) {
	if( $file_size >= 1073741824 ) {
		$file_size = round( $file_size / 1073741824 * 100 ) / 100 . " Gb";
	} elseif( $file_size >= 1048576 ) {
		$file_size = round( $file_size / 1048576 * 100 ) / 100 . " Mb";
	} elseif( $file_size >= 1024 ) {
		$file_size = round( $file_size / 1024 * 100 ) / 100 . " Kb";
	} else {
		$file_size = $file_size . " b";
	}
	return $file_size;
}
?>