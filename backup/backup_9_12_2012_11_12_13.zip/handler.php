<?php
ini_set( "error_reporting", E_ERROR );
define( "SMS_HANDLER", true );
define( "DIR_ROOT", dirname ( __FILE__ ) );

#Настройки и классы
require_once DIR_ROOT . "/config/mysql.cfg.php";
require_once DIR_ROOT . "/config/global.cfg.php";
require_once DIR_ROOT . "/kernel/classes/mysql.class.php";
require_once DIR_ROOT . "/kernel/includes/function.inc.php";

#Иницилизация
$db = new db( $sql['server'], $sql['user'], $sql['password'], $sql['database'] );
$global = array();
$global['time'] = time () + ( $config['tz'] * 60 );

$mod = preg_match( "/^[a-z]+$/i", $_REQUEST['mod'] ) ? $_REQUEST['mod'] : false;

#Подкулючаем
if ( $_REQUEST['mod'] && file_exists( DIR_ROOT . "/kernel/modules/" . $mod . "/handler.php" ) ) { 
	include_once( DIR_ROOT . "/kernel/modules/" . $mod . "/handler.php" ); 
}

if ( $config['debug'] == "yes" ) {
	write_log( "handler", "Отладка:" );
}
?>