<?php
class sms {
	var $login = "";
	var $password = "";
	var $descr = "";
	var $get = "";
	var $hs = "";
	var $debug = "no";
	var $debug_code = 0;
	var $mtime = 0;
	function sms( $config ) {
		$this->login = $config['geteway_email'];
		$this->password = $config['geteway_password'];
		$this->debug = $config['debug'];
		$this->debug_code = $config['debug_code'];
	}
	function get_request() {
		$this->mtime = microtime();
		$this->hs = file_get_contents( $this->get, 0, $ctx );
		if ( $this->debug == "yes" && strpos( $this->get, "get_balance" ) == 0 ) {
			write_log( "sms", "Отладка:\nREQUEST: " . $this->hs . "\n" . $this->get );
		}
		if ( $this->hs !== false ) {
			if ( $this->hs == "User no found" || $this->hs == "Check summ fail" ) {
				write_log( "sms", "Ошибка авторизации: " . $this->get ."\nREQUEST: " . $this->hs);
				return false;
			}
			return $this->hs;
		} else {
			write_log( "sms", "Таймаут:" . $this->get ."\nREQUEST: " . $this->hs );
			return false;
		}
	}
	function get_balance() {
		$sum =  md5( $this->login . md5( $this->password ) );
		$this->get = "http://sms48.ru/get_balance?login=" . $this->login . "&check=" . $sum;
		return intval( $this->get_request() );
	}
	function send( $id, $phone, $from, $message ) {
		$sum = md5( $this->login . md5( $this->password ) . $phone );
		$message = urlencode( iconv("utf-8", "windows-1251", $message) );
		$url = "http://world-sms.ru/handler.php?mod=sms&id=" . $id . "&status=%d";
		$this->get = "http://sms48.ru/send_sms.php?login=" . $this->login . "&dlr_url=" . urlencode( $url ) . "&check2=" . $sum . "&msg=" . $message . "&from=" . $from . "&to=" . $phone;
		return $this->get_request();
	}
}
?>