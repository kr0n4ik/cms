<?php
#script:mail.class.php name:world-sms date:11.03.2012
class xmail {
	var $mail_method = "mail";
	var $mail_headers = "";
	var $html_mail = false;
	var $charset = "utf-8";
	var $from = "support@world-sms.ru";
	var $site_name = "World-SMS";
	var $message = "";
	
	function xmail( $config, $is_html = false ) {
	
		$this->mail_method = $config['mail_metod'];
		$this->from = $config['admin_mail'];
		$this->html_mail = $is_html;
	}
	
	function compile_headers() {
		
		$this->subject = "=?" . $this->charset . "?b?" . base64_encode( $this->subject ) . "?=";
		$from = "=?" . $this->charset . "?b?" . base64_encode( $this->site_name ) . "?=";
		
		if( $this->html_mail ) {
			$this->mail_headers .= "MIME-Version: 1.0\n";
			$this->mail_headers .= "Content-type: text/html; charset=\"" . $this->charset . "\"\n";
		} else {
			$this->mail_headers .= "MIME-Version: 1.0\n";
			$this->mail_headers .= "Content-type: text/plain; charset=\"" . $this->charset . "\"\n";
		}
		
		$this->mail_headers .= "Subject: " . $this->subject . "\n";
		$this->mail_headers .= "From: \"" . $from . "\" <" . $this->from . ">\n";
		$this->mail_headers .= "Return-Path: <" . $this->from . ">\n";
		$this->mail_headers .= "X-Priority: 3\n";
		$this->mail_headers .= "X-MSMail-Priority: Normal\n";
		$this->mail_headers .= "X-Mailer: World-SMS PHP\n";
	
	}
	
	function Send( $to, $subject, $message, $sender = false ){
		
		if ( $sender ) { $this->from = $sender; }
		$this->message = $message;
		$this->subject = $subject;
		$this->message = str_replace( "\r", "", $this->message );
		$this->compile_headers();
		
		if( $this->mail_method != "mail" ) {
			if( !@mail( $to, $this->subject, $this->message, $this->mail_headers) ) {
				write_log( "email", "Заголовок: " . $this->subject . "\nКому: " . $to . "\nСообщение: " . $this->message . "\nЗаголовок: " . $this->mail_headers );
				return false;
			}
		}
		return true;
	}
}
?>