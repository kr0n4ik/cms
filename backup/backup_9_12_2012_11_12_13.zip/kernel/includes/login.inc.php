<?php
if ( !defined( "SMS_INDEX" ) ) { die( "Hacking..." ); exit(); }

#Выход
if ( $global['url'][0] == "logout" ) {
	$db->query("UPDATE " . $sql['prefix'] . "_users SET session='' WHERE session='" . $_SESSION['session'] . "';");
	unset( $_SESSION['session'] );
	setcookie( "session", "", "60");
	header("Location: " . $config['url_home'] . "");
}
if ( $_POST['login'] ) {
	$email = strtolower( trim( $_POST['login']['email'] ) );
	$email = ( preg_match( "/^([a-z0-9_\.-]+)@([a-z0-9_\.-]+)\.([a-z\.]{2,6})$/i", $email ) ) ? $email : false;
	
	$password = trim( $_POST['login']['password'] );
	$password = md5( $password . md5( $password ) . $config['salt'] . "\n" );
	
	$row = $db->fetchrow( $db->query( "SELECT password FROM " . $sql['prefix'] . "_users WHERE email='" . $email . "';" ) );
	if ( $row['password'] == $password ) { 
		$hash = md5( time() . $password . rand( 0, 999 ) . $global['ip'] );
		$time = $global['time'] + ( $config['time_session'] * 60 * 60 );
		$_SESSION['session'] = $hash;
		setcookie('session', $hash, $time );
		$db->query("UPDATE " . $sql['prefix'] . "_users SET session='" . $hash . "', sestime=" . $time . ", lasttime=" . ( $global['time'] ) . " WHERE email='" . $email . "';");
	} else {
		write_log( "hack", "Неверная пара логин-пароль\n{$_POST['login']['email']}-{$_POST['login']['password']}\n" );
	}
} 

#Проверка сессии
$_SESSION['session'] = ( $_COOKIE['session'] ) ? $_COOKIE['session'] : $_SESSION['session'];
$session = ( preg_match("/^[a-z0-9]{32}$/i", $_SESSION['session'] ) ) ? $_SESSION['session'] : false;

$result = $db->query( "SELECT id, email, balance, sms, icq, skype, nameone, nametwo, phone, purse, code FROM " . $sql['prefix'] . "_users WHERE session = '" . $session . "' AND session <> '' AND sestime >= " . $global['time'] . ";");
if ( $db->numrows( $result ) == 1 && !empty( $session ) ) {

	$global['user'] = $db->fetchrow( $result );
	$global['user']['loged'] = true;
	$global['user']['countpartone'] = $db->numrows( $db->query( "SELECT * FROM " . $sql['prefix'] . "_partners_two WHERE partone=" . $global['user']['id'] . " AND userid!=0;" ) );
	$global['user']['countparttwo'] = $db->numrows( $db->query( "SELECT * FROM " . $sql['prefix'] . "_partners_two WHERE parttwo=" . $global['user']['id'] . " AND userid!=0;" ) );

	$global['modules']['profile']['title'] = "Профиль";
	$global['modules']['profile']['url'] = DIR_ROOT . "/kernel/modules/profile/content.php";
	$global['modules']['sms']['title'] = "Отправка смс";
	$global['modules']['sms']['url'] = DIR_ROOT . "/kernel/modules/sms/content.php";
	$global['modules']['ticket']['title'] = "Тех. поддержка";
	$global['modules']['ticket']['url'] = DIR_ROOT . "/kernel/modules/ticket/content.php";
	$global['modules']['transactions']['title'] = "Переводы";
	$global['modules']['transactions']['url'] = DIR_ROOT . "/kernel/modules/transactions/content.php";
	$global['modules']['stats']['title'] = "Статус";
	$global['modules']['stats']['url'] = DIR_ROOT . "/kernel/modules/stats/content.php";
	$global['modules']['buy']['title'] = "Покупка";
	$global['modules']['buy']['url'] = DIR_ROOT . "/kernel/modules/buy/content.php";
	$global['modules']['partners']['title'] = "Партнеры";
	$global['modules']['partners']['url'] = DIR_ROOT . "/kernel/modules/partners/content.php";
	$global['modules']['news']['url'] = DIR_ROOT . "/kernel/modules/news/content.php";
	
	$news = $db->numrows( $db->query( "SELECT * FROM " . $sql['prefix'] . "_news WHERE time>" . intval( $_COOKIE['news_time'] ) . " AND time<=" . $global['time'] . ";" ) );
	$news = ( $news != 0 ) ? "<font color=\"red\"><sup>+{$news}</sup></font>": "";
	$tpl->load( "menu.tpl" );
	$tpl->set( "{email}", $global['user']['email'] );
	$tpl->set( "{balance}", $global['user']['balance'] );
	$tpl->set( "{sms}", $global['user']['sms'] );
	$tpl->set( "{count_partner_one}", $global['user']['countpartone'] );
	$tpl->set( "{count_partner_two}", $global['user']['countparttwo'] );
	$tpl->set( "{news}", $news );
	$tpl->compile( "menu" );
	
	#Uptime
	$db->query( "UPDATE " . $sql['prefix'] . "_users SET uptime={$global['time']} WHERE id={$global['user']['id']};");
	
} else {
	$global['modules']['register']['title'] = "Регистрация";
	$global['modules']['register']['url'] = DIR_ROOT . "/kernel/modules/register/content.php";

	$tpl->load( "login.tpl" );
	$tpl->compile( "menu" );
}

?>