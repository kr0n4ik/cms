<?php
function set_cookie($name, $value, $expires) {
	if( $expires ) {
		$expires = time() + ($expires * 86400);
	} else {
		$expires = FALSE;
	}
	if( PHP_VERSION < 5.2 ) {
		setcookie( $name, $value, $expires, "/", NULL . "; HttpOnly" );
	} else {
		setcookie( $name, $value, $expires, "/", NULL, NULL, TRUE );
	}
}
function write_log( $log, $line ) {
	global $global;
	if( !file_exists( DIR_ROOT . "/logs/{$log}.log.php" ) ) {
		$hf = fopen( DIR_ROOT . "/logs/{$log}.log.php", "w" );
	} else {
		$hf = fopen( DIR_ROOT . "/logs/{$log}.log.php", "a+" );
	}
	$line = htmlspecialchars( trim( substr( $line, 0, 500 ) ), ENT_QUOTES );
	$url = htmlspecialchars( trim( getenv( "REQUEST_URI" ) ), ENT_QUOTES );
	$ip = $_SERVER['REMOTE_ADDR'];
	fwrite( $hf, date( "d.m.Y H:i:s", $global['time'] ) . "\n{$line}\n-------------------------------------------------------\nURL: {$url}\nIP: {$ip}\n====================================================================================================================\n" );
	fclose( $hf );
}
function get_info() {
	$info = $_SERVER['HTTP_USER_AGENT'];
	if ( strpos( $info, "YandexBot" ) || strpos( $info, "bingbot" ) || strpos( $info, "Mail.RU_Bot" ) || strpos( $info, "DCPbot" ) || strpos( $info, "SolomonoBot" ) || strpos( $info, "Nigma.ru" ) || strpos( $info, "Googlebot" ) ) {
		$result['os'] = "bot";
	} elseif ( strpos( $info, "Windows NT 6.1" ) ) {
		$result['os'] = "Windows 7";
	} elseif ( strpos( $info, "Windows NT 6.0" ) ) {
		$result['os'] = "Windows Vista";
	} elseif ( strpos( $info, "Windows NT 5.2" ) ) {
		$result['os'] = "Windows Server 2003";
	} elseif ( strpos( $info, "Windows NT 5.1" ) ) {
		$result['os'] = "Windows XP";
	} elseif ( strpos( $info, "Windows NT 5.0" ) ) {
		$result['os'] = "Windows 2000";
	} elseif ( strpos( $info, "Android" ) ) {
		$result['os'] = "Android";
	}
	if ( !$_SESSION['x'] AND $result['os'] != "bot" ) {
		$_SESSION['x'] = true;
		write_log( "os", "Операционная система: {$result['os']}\nHTTP_USER_AGENT: {$info}\nREQUEST: " . http_build_query( $_REQUEST ) );
	}
	return $result;
}
function DateToTime( $date ) {
	$aDateTime = explode( ' ', $date );
	$aDate = explode( '-', $aDateTime[0] );
	$aTime = explode( ':', $aDateTime[1] );
	return mktime( intval( $aTime[0] ), intval( $aTime[1] ), intval( $aTime[2] ), intval( $aDate[1] ), intval( $aDate[2] ), intval( $aDate[0] ) );
	
}
?>