<?php
if ( !defined( "SMS_INDEX" ) ) { die( "Hacking..." ); exit(); }

require_once DIR_ROOT . "/config/global.cfg.php";

if ( $config['debug'] == "yes" && $config['debug_code'] == "1" ) {
	@ini_set( "error_reporting", E_ALL );
} else {
	@ini_set( "error_reporting", E_ERROR );
}

require_once DIR_ROOT . "/config/mysql.cfg.php";
require_once DIR_KERNEL . "/classes/template.class.php";
require_once DIR_KERNEL . "/classes/mysql.class.php";
require_once DIR_KERNEL . "/includes/function.inc.php";

$global['time'] = time () + ( $config['tz'] * 60 );
$info = get_info();

#Глобальные модули
$global['modules']['']['title'] = "Главная";
$global['modules']['']['url'] = DIR_ROOT . "/kernel/modules/static/content.php";
$global['modules']['static']['url'] = DIR_ROOT . "/kernel/modules/static/content.php";
$global['modules']['tarifs']['url'] = DIR_ROOT . "/kernel/modules/tarifs/content.php";

if ( $global['url'][0] != "" && $global['url'][1] != "index" ) {
	$global['mobile']['buttonone'] = "<a href=\"{$config['url_home']}\" data-icon=\"home\" class=\"ui-btn-left\">Домой</a>";
}

#Шаблон
$tpl = new template();
if ( $info['os'] == "Android" ) {
	//$tpl->theme = "smartphone";
}


#База данных MySQL
$db = new db( $sql['server'], $sql['user'], $sql['password'], $sql['database'] );

#Вход пользователей
require_once DIR_KERNEL . "/includes/login.inc.php";

if ( file_exists( $global['modules'][$global['url'][0]]['url'] ) ) {
	include_once ( $global['modules'][$global['url'][0]]['url'] );
} else {
	
}
?>