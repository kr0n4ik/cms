<?php
if ( !defined( 'SMS_INDEX' ) ) { die( "Hacking..." ); exit(); }
if ( !$global['user']['loged'] ) { header( "Location: index.php" ); exit();}

$result = $db->query( "SELECT * FROM " . $sql['prefix'] . "_tariffs_two ORDER BY count ASC;" );
while ( $row = $db->fetchrow( $result ) ) { 
$js_tariffs .= "if ( val < " . $row['count'] . " ) {
			$('input[name=\"LMI_PAYMENT_AMOUNT\"]').val( val * " . $row['cost'] . " );
			$('#buy').submit();
		} else ";
}

$tpl->load( "buy.tpl" );
$tpl->set( "{tariffs}", $js_tariffs );
$tpl->set( "{desc}", base64_encode( 'Оплата смс' ) );
$tpl->set( "{purse}", $config['transfer_purse'] );
$tpl->set( "{id}", $global['user']['id'] );
$tpl->compile( "content" );
?>