<?php
if ( !defined( "SMS_HANDLER" ) ) { die( "Hacking..." ); exit(); }

if ( $_REQUEST['LMI_PREREQUEST'] == 1 ) {
	$row = $db->fetchrow( $db->query( "SELECT cost FROM " . $sql['prefix'] . "_tariffs_two WHERE count>" . intval( $_REQUEST['SMS_COUNT'] ) . " LIMIT 0,1;" ) );
	if ( $_REQUEST['SMS_COUNT'] * $row['cost'] != $_REQUEST['LMI_PAYMENT_AMOUNT'] ) {
		echo "ERR: НЕВЕРНАЯ СУММА " . $_REQUEST['LMI_PAYMENT_AMOUNT'] ;
		exit;
	}
	echo "YES";
	exit;
} else {
	if ( $_REQUEST['action'] == "" ) {
		$id = intval( $_REQUEST['USER_ID'] );
		$count = intval( $_REQUEST['SMS_COUNT'] );
		$amount = floatval( $_REQUEST['LMI_PAYMENT_AMOUNT'] );
		$hash = strtoupper( md5( $_REQUEST['LMI_PAYEE_PURSE'].$_REQUEST['LMI_PAYMENT_AMOUNT'].$_REQUEST['LMI_PAYMENT_NO'].$_REQUEST['LMI_MODE'].$_REQUEST['LMI_SYS_INVS_NO'].$_REQUEST['LMI_SYS_TRANS_NO'].$_REQUEST['LMI_SYS_TRANS_DATE'].$config['transfer_key'].$_REQUEST['LMI_PAYER_PURSE'].$_REQUEST['LMI_PAYER_WM'] ) );
		if ( $hash != $_REQUEST['LMI_HASH'] && $_REQUEST['LMI_HASH'] ) { echo "Hacking..."; exit; }
		$db->query( "UPDATE " . $sql['prefix'] . "_users SET sms=sms+" . $count . " WHERE id=" . $id . ";" );
		$db->query( "INSERT INTO " . $sql['prefix'] . "_transactions SET userid=" . $id . ", amount='-" . $amount . "', time=" . $global['time'] . ", reason='Покупка " . $count . " смс', direct='buy';" );
		$row = $db->fetchrow( $db->query( "SELECT * FROM " . $sql['prefix'] . "_partners_two WHERE userid=" . $id . ";" ) );
		if ( $row['partone'] != 0 ) {
			$db->query( "INSERT INTO " . $sql['prefix'] . "_transactions SET amount='" .( $row['prpartone'] * $amount / 100 ) . "', time={$global['time']}, userid=" . $row['partone'] . ", reason='" . $row['prpartone'] . "%';" );
			$db->query( "UPDATE " . $sql['prefix'] . "_users SET balance=balance+" . ( $row['prpartone'] * $amount / 100 ) . " WHERE id=" . $row['partone'] . ";");
		}
		if ( $row['parttwo'] != 0 ) {
			$db->query( "INSERT INTO " . $sql['prefix'] . "_transactions SET amount='" .( $row['prparttwo'] * $amount / 100 ) . "', time={$global['time']}, userid=" . $row['parttwo'] . ", reason='" . $row['prparttwo'] . "%';" );
			$db->query( "UPDATE " . $sql['prefix'] . "_users SET balance=balance+" . ( $row['prparttwo'] * $amount / 100 ) . " WHERE id=" . $row['parttwo'] . ";");
		}
	}elseif ( $_REQUEST['action'] == "yes" ) {
		echo "Спасибо за покупку.";
	} elseif ( $_REQUEST['action'] == "no" ) {
		echo "Покупка не состоялась.";
	}
}
?>