<?php
if ( !defined( "SMS_INDEX" ) ) { die( "Hacking..." ); exit(); }
if ( !$global['user']['loged'] ) { header( "Location: index.php" ); exit();}

function edit_user(){
	global $global, $tpl, $sql, $db;
	
	$error = $up = array();
	if ( !$global['user']['nametwo'] ) {
		if ( !preg_match( "/^[a-zа-я]+$/iu", $_POST['edit']['nametwo'] ) && !empty( $_POST['edit']['nametwo'] )  ) {
			$error[] = "<p>Фамилия содержит недопустимые знаки</p>";
		} else {
			$up[] = "nametwo='" . $_POST['edit']['nametwo'] . "'";
		}
	}
	if ( !$global['user']['nameone'] ) {
		if ( !preg_match( "/^[a-zа-я]+$/iu", $_POST['edit']['nameone'] ) && !empty( $_POST['edit']['nameone'] ) ) {
			$error[] = "<p>Имя содержит недопустимые знаки</p>";
		} else {
			$up[] = "nameone='" . $_POST['edit']['nameone'] . "'";
		}
	}
	if ( !$global['user']['purse'] ) {
		if ( !preg_match( "/^R[0-9]{12}$/i", $_POST['edit']['purse'] ) && !empty( $_POST['edit']['purse'] ) ) {
			$error[] = "<p>Неверный формат кошелька WMR</p>";
		} else {
			$up[] = "purse='" . $_POST['edit']['purse'] . "'";
		}
	}
	if ( !$global['user']['phone'] ) {
		if ( !preg_match( "/^7[0-9]{9,12}$/i", $_POST['edit']['phone'] ) && !empty( $_POST['edit']['phone'] ) ) {
			$error[] = "<p>Неверный формат кошелька номера телефона</p>";
		} else {
			$up[] = "phone='" . $_POST['edit']['phone'] . "'";
		}
	}
	if ( !preg_match( "/^[0-9]{4,9}$/", $_POST['edit']['icq'] ) && !empty( $_POST['edit']['icq'] ) ) {
		$error[] = "<p>Неверный формат icq</p>";
	} else {
		$up[] = "icq='" . $_POST['edit']['icq'] . "'";
	}
	if ( !preg_match( "/^[0-9a-z]{1,63}$/i", $_POST['edit']['skype'] ) && !empty( $_POST['edit']['skype'] ) ) {
		$error[] = "<p>Неверный формат Skype</p>";
	} else {
		$up[] = "skype='" . $_POST['edit']['skype'] . "'";
	}
	if ( !empty( $_POST['edit']['password'] ) ) {
		if ( strlen( $_POST['edit']['password'] ) < 6 ) {
			$error[] = "<p>Пароль должен состоять не менее 6 символов</p>";
		} else {
			$up[] = "password='" . md5( $_POST['edit']['password'] . md5( $_POST['edit']['password'] ).$config['salt'] . "\n" ) . "'";
		}
	}
	
	
	if ( $error ) {
		$tpl->load( "info.tpl" );
		$tpl->set( "{content}", implode( $error, "" ) . "<input type=\"button\" onClick=\"history.go(-1);\" value=\"Вернуться\" />" );
		$tpl->compile( "info" );
		return false;
	}
	
	$db->query("UPDATE " . $sql['prefix'] . "_users SET " . implode($up, ", ") . " WHERE id=" . $global['user']['id'] . ";" );
	
	$tpl->load( "info.tpl" );
	$tpl->set( "{content}", "<p>Данные успешно сохранены</p><input type=\"button\" onClick=\"location.href='{$config['url_home']}profile';\" value=\"Ок\" />" );
	$tpl->compile( "info" );
	return true;
}

if ( isset( $_POST['go_save'] ) ) {
	edit_user();
}

#загружаем и выводим
$tpl->load( "profile.tpl" );

$tpl->set( "{v_email}", $global['user']['email'] );
$tpl->set( "{v_nametwo}", $global['user']['nametwo'] );
$tpl->set( "{v_nameone}", $global['user']['nameone'] );
$tpl->set( "{v_purse}", $global['user']['purse'] );
$tpl->set( "{v_phone}", $global['user']['phone'] );
$tpl->set( "{v_icq}", $global['user']['icq'] );
$tpl->set( "{v_skype}", $global['user']['skype'] );

if ( !empty( $global['user']['nameone'] ) ) { $tpl->set( "{d_nameone}", "disabled=\"disabled\"" );  } else { $tpl->set( "{d_nameone}", "" ); }
if ( !empty( $global['user']['nametwo'] ) ) { $tpl->set( "{d_nametwo}", "disabled=\"disabled\"" );  } else { $tpl->set( "{d_nametwo}", "" ); }
if ( !empty( $global['user']['purse'] ) ) { $tpl->set( "{d_purse}", "disabled=\"disabled\"" );  } else { $tpl->set( "{d_purse}", "" ); }
if ( !empty( $global['user']['phone'] ) ) { $tpl->set( "{d_phone}", "disabled=\"disabled\"" );  } else { $tpl->set( "{d_phone}", "" ); }

$tpl->compile( "content" );
?>