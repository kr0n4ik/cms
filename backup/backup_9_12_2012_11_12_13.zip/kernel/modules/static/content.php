<?php
if ( !defined( "SMS_INDEX" ) ) { die( "Hacking..." ); exit(); }

$url = preg_match( '/^[a-z0-9_]+$/i', $global['url'][1] ) ? $global['url'][1] : "index";

$result = $db->query("SELECT * FROM " . $sql['prefix'] . "_statics WHERE url='" . $url . "';", $config['time_cache'] * 60 * 60 );
$row = $db->fetchrow( $result, $config['cache'] );

if ( $row['template'] ) {
	$title = ( $row['title'] ) ? "<h2>" . $row['title'] . "</h2>" : "";
	$db->query( "UPDATE " . $sql['prefix'] . "_statics SET views=views+1 WHERE url='" . $url . "';");
} else {
	$title = "<h2>Ошибка 404</h2>";
	$row['template'] = "Страница не найдена или не существует!";
}


#загружаем и выводим
$tpl->load( "static.tpl" );
$tpl->set( "{title}", $title );
$tpl->set( "{template}", $row['template'] );
$tpl->compile( "content" );
?>