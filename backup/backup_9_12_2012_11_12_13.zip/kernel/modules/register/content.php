<?php
if ( !defined( 'SMS_INDEX' ) ) { die( "Hacking..." ); exit(); }
if ( $global['user']['loged'] ) { header( "Location: index.php" ); exit();}

function register(){
	global $tpl, $db, $sql, $config, $global;
	
	if ( empty( $_POST['email'] ) ) {
		$tpl->load( "info.tpl" );
		$tpl->set( "{content}", "<p>Логин ( E-mail ) должен быть заполнено</p>" );
		$tpl->compile( "info" );
		return false;
	}
	if ( !preg_match( "/^([a-z0-9_\.-]+)@([a-z0-9_\.-]+)\.([a-z\.]{2,6})$/", $_POST['email'] ) ) {
		$tpl->load( "info.tpl" );
		$tpl->set( "{content}", "<p>Неверный формат почтового ящика</p><input type=\"button\" onClick=\"history.go(-1);\" value=\"Вернуться\" />" );
		$tpl->compile( "info" );
		return false;
	}
	if ( $db->numrows( $db->query("SELECT * FROM " . $sql['prefix'] . "_users WHERE email='{$_POST['email']}';" ) ) != 0 ) {
		$tpl->load( "info.tpl" );
		$tpl->set( "{content}", "<p>Пользователь с логином {$_POST['email']} уже зарегистрирован</p><input type=\"button\" onClick=\"history.go(-1);\" value=\"Вернуться\" />" );
		$tpl->compile( "info" );
		return false;
	}
	if ( strlen( $_POST['passwordone'] ) < 6 ) {
		$tpl->load( "info.tpl" );
		$tpl->set( "{content}", "<p>Пароль должен быть не менее шести знаков</p><input type=\"button\" onClick=\"history.go(-1);\" value=\"Вернуться\" />" );
		$tpl->compile( "info" );
		return false;
	}
	if ( $_POST['passwordone'] != $_POST['passwordtwo'] ) {
		$tpl->load( "info.tpl" );
		$tpl->set( "{content}", "<p>Пароли должны совпадать</p><input type=\"button\" onClick=\"history.go(-1);\" value=\"Вернуться\" />" );
		$tpl->compile( "info" );
		return false;
	}
	if ( empty( $_POST['agry'] ) ) {
		$tpl->load( "info.tpl" );
		$tpl->set( "{content}", "<p>Вы должны согласиться с правилами</p><input type=\"button\" onClick=\"history.go(-1);\" value=\"Вернуться\" />" );
		$tpl->compile( "info" );
		return false;
	}
	
	$password = md5( $_POST['passwordone'] . md5( $_POST['passwordone'] ) . $config['salt'] . "\n" );
	$email = strtolower( $_POST['email'] );
	$code = substr( md5( $email . $password . rand( 0, 10 ) . rand( 0, 10 ) . rand( 0, 10 ) ), 0, 7 );
	$db->query( "INSERT INTO " . $sql['prefix'] . "_users SET password='" . $password . "', email='" . $email . "', regtime=" . $global['time'] . ", regip='" . $global['ip'] . "', sms=" . intval( $config['reg_count_sms'] ) . ", code='" . $code . "';" );
	$id = $db->insertid();
	$db->query( "INSERT INTO " . $sql['prefix'] . "_transactions SET amount=0, time=" . $global['time'] . ", userid=" . $id . ", reason='Подарочные " . $config['reg_count_sms'] . " смс', direct='buy';" );
	
	if ( preg_match( "/^[a-z0-9]+$/i", $_POST['partner'] ) ) {
		$row[0] = $db->fetchrow( $db->query( "SELECT * FROM " . $sql['prefix'] . "_users WHERE code='{$_POST['partner']}';" ) );
		$row[1] = $db->fetchrow( $db->query( "SELECT * FROM " . $sql['prefix'] . "_partners_two WHERE userid={$row[0]['id']};" ) );
		$db->query( "UPDATE " . $sql['prefix'] . "_partners_two SET parttwo='{$row[1]['partone']}', prpartone=" . intval( $config['pr_prtner_one'] ) . " , prparttwo=" . intval( $config['pr_prtner_two'] ) . ", userid={$id}, time={$global['time']} WHERE partone='{$row[0]['id']}' AND userid=0;" );
	}
	$tpl->load( "info.tpl" );
	$tpl->set( "{content}", "<p>Вы успешно зарегистрировались</p><input type=\"button\" onClick=\"location.href='{$config['url_home']}';\" value=\"На главную\" />" );
	$tpl->compile( "info" );
	return true;
}

if ( isset( $_POST['go_reg'] ) ) {
	register();
}

$tpl->load( "register.tpl" );
$tpl->set( "{partner}", "" );
if ( preg_match( "/^[0-9a-z]+$/", $global['url'][1] ) ) { 
	$row = $db->fetchrow( $db->query( "SELECT id FROM " . $sql['prefix'] . "_users WHERE code='{$global['url'][1]}';" ) );
	if ( $db->numrows( $db->query("SELECT * FROM " . $sql['prefix'] . "_partners_two WHERE ip='" . $global['ip'] . "' AND partone={$row['id']} AND userid=0;" ) ) == 0 ) {
		$db->query( "INSERT INTO " . $sql['prefix'] . "_partners_two SET ip='" . $global['ip'] . "', partone='{$row['id']}';" );
		$tpl->set( "{partner}", "<input type=\"hidden\" name=\"partner\" value=\"" . $global['url'][1] . "\">" ); 
	}
}
$tpl->compile( "content" );
?>