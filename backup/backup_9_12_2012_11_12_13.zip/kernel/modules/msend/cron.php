<?php
if ( !defined( "SMS_CRON" ) ) { die( "Hacking..." ); exit(); }

require_once DIR_ROOT . "/kernel/classes/mail.class.php";
$mail = new xmail( $config );

$result = $db->query( "SELECT * FROM " . $sql['prefix'] . "_msend_one WHERE time<" . $global['time'] . " AND status='';" );
while ( $row = $db->fetchrow( $result ) ) {
	$row['emails'] = explode( ",", $row['emails'] );
	if ( $row['distr'] == "2" ) {
		$cnt[0] = $cnt[2] = $cnt[1] = 0;
		foreach ( $row['emails'] as $key => $email ) {
			echo $email = strtolower( $email );
			if ( preg_match( "/^[-a-z0-9\.\-_]+@([-a-z0-9\-]+\.)+[a-z]{2,6}/i", $email ) ) {
				$count = $db->numrows( $db->query( "SELECT * FROM " . $sql['prefix'] . "_memail WHERE taker='" . $email . "';" ) );
				if ( $count == 0 ) {
					if ( $mail->send( $email, $row['title'], $row['template'], $row['sender'] ) ) {
						$db->query( "INSERT INTO " . $sql['prefix'] . "_memail SET taker='" . $email . "', time=" . $global['time'] . ", member='" . $_SESSION['admin']['name'] . "';" );
						$cnt[0]++;
					} else {
						$cnt[1]++;
					}
				} else {
					$cnt[2]++;
				}
			} else {
				$cnt[1]++;
			}
		}
		$db->query( "UPDATE " . $sql['prefix'] . "_msend_one SET status='Отправленных: {$cnt[0]} Ошибок: {$cnt[1]}, Повтор: {$cnt[2]}' WHERE id=" . $row['id'] . ";" );
	} elseif ( $row['distr'] == "0" ) {
		foreach ( $row['emails'] as $key => $email ) {
			$email = strtolower( $email );
			if ( preg_match( "/^[-a-z0-9\.\-_]+@([-a-z0-9\-]+\.)+[a-z]{2,6}/i", $email ) ) {
				if ( $mail->send( $email, $row['title'], $row['template'], $row['sender'] ) ) {
					$cnt[0]++;
				} else {
					$cnt[1]++;
				}
			} else {
					$cnt[1]++;
			}
		}
		$db->query( "UPDATE " . $sql['prefix'] . "_msend_one SET status='Отправленных: {$cnt[0]} Ошибок: {$cnt[1]}' WHERE id=" . $row['id'] . ";" );
	}
}

?>