<?php
if ( !defined( "SMS_JSON" ) || !$global['user']['loged'] ) { die( "Hacking..." ); exit(); }

require_once DIR_ROOT . "/kernel/classes/sms.class.php";
$sms = new sms( $config );

function send_sms() {
	global $global, $sql, $db, $sms;
	
	$a_phones = array();
	$length = mb_strlen( $_REQUEST['sms'], "UTF-8" );
	$packetid = rand( 0, 99999 );
	$send_time = ( $_REQUEST['send_now'] == "yes" ) ? $global['time'] : DateToTime( $_REQUEST['send_time'] );
	$title = ( $_REQUEST['send_title'] ) ? $db->escape( strip_tags( trim( $_REQUEST['send_title'] ) ) ) : "Рассылка-" . rand( 1, 999 );
	$sign = ( preg_match( "/^[a-z\-0-9\.]+$/i", $_REQUEST['send_name'] ) ) ? $_REQUEST['send_name'] : "world-sms";
	
	$phones = $_REQUEST['phones'];
	preg_match_all('|&lt;(.*)&gt;|Uis', $phones, $a_phones );
	$a_phones = $a_phones[1];
	foreach ( $a_phones as $key => $phone ) { 
		if ( preg_match( '/^\+7[0-9]{10,12}$/', $phone ) ) {
			$a_phones[$key] = substr( $phone, 1, 16 );
		} elseif ( preg_match( '/^8[0-9]{10,11}$/', $phone ) ) {
			$a_phones[$key] = "7" . substr( $phone, 1, 16 );
		} elseif ( preg_match( '/^7[0-9]{10,11}$/', $phone ) ) {
			$a_phones[$key] = $phone;
		} elseif ( preg_match( '/^[0-9]{10,11}$/', $phone ) ) {
			$a_phones[$key] = "7" . $phone;
		} else {
			unset( $a_phones[$key] );
		}
	}
	
	if ( preg_match( '/^[a-z]+$/iu', $_REQUEST['sms'] ) ) {
		$sms_count = ( $length <= 160 ) ? 1 : ceil( $length / 153 );
		$text = $db->escape( substr( $_REQUEST['sms'], 0, 1530 ) );
	} else {
		$sms_count = ( $length <= 70 ) ? 1 : ceil( $length / 67 );
		$text = $db->escape( substr( $_REQUEST['sms'], 0, 670 ) );
	}
	
	if ( sizeof( $a_phones ) == 0 ) {
		$global['out']['status'] = "error";
		$global['out']['text'] = "Нету получателей, введите получателей";
		return false;
	}
	
	if ( $length == 0 ) {
		$global['out']['status'] = "error";
		$global['out']['text'] = "Нету текста сообщения";
		return false;
	}
	
	if ( $global['user']['sms'] < ( $sms_count * sizeof( $a_phones ) ) || $global['user']['sms'] == 0 ) {
		$global['out']['status'] = "error";
		$global['out']['text'] = "У Вас недостаточно смс для отправки, пополните счет";
		return false;
	}
	
	foreach ( $a_phones as $phone ) {
		$db->query( "INSERT INTO " . $sql['prefix'] . "_statistica_two SET  packetid=" . $packetid . ", packettitle='" . $title . "', sender='" . $sign . "', phone='" . $phone . "', message='" . $text . "', sendtime=" . $send_time . ", createtime=" . $global['time'] . ", status='0', userid=" . $global['user']['id'] . ", parts=" . $sms_count . ";" );
		if ( $_REQUEST['send_now'] == "yes" ) {
			$id = $db->insertid();
			if ( $sms->send( $id, $phone, $sign, $text ) == 1 ) {
				$db->query( "UPDATE " . $sql['prefix'] . "_statistica_two SET status='1', statustime=" . $global['time'] . " WHERE id=" . $id . ";" );
				$db->query( "UPDATE " . $sql['prefix'] . "_users SET sms=sms-" . $sms_count . " WHERE id=" . $global['user']['id'] . ";" );
			}
		}
	}
	
	if ( $_REQUEST['send_now'] == "yes" ) {
		$global['out']['status'] = "ok";
		$global['out']['text'] = "Рассылка успешно выполнена";
	} else {
		$global['out']['status'] = "ok";
		$global['out']['text'] = "Рассылка начнется " . date( "Y-m-d H:i",  $send_time );
	}
	return true;
}

if ( $_REQUEST['action'] == "save" ) {

	$_SESSION['sms']['phones'] = trim( $_REQUEST['phones'] );
	$_SESSION['sms']['sms'] = $db->escape( $_REQUEST['sms'] );
	$_SESSION['sms']['send_time'] = $db->escape( $_REQUEST['send_name'] );
	$_SESSION['sms']['send_title'] = $db->escape( $_REQUEST['send_title'] );
	
} elseif ( $_REQUEST['action'] == "send" ) {
	send_sms();
}
?>