<?php
if ( !defined( "SMS_INDEX" ) ) { die( "Hacking..." ); exit(); }
if ( !$global['user']['loged'] ) { header( "Location: index.php" ); exit();}

require_once DIR_KERNEL . "/classes/excel.calss.php";

function upload_phone() {
	global $db, $sql, $tpl, $global;

	$phones = $_SESSION['sms']['phones'];
	if ( $_FILES['file']['type'] == "application/vnd.ms-excel" && $_REQUEST['type'] == "xls" ) {
		$name = md5( time() . $_FILES["file"]["name"] . $_FILES["file"]["tmp_name"] );
		move_uploaded_file($_FILES["file"]["tmp_name"], DIR_ROOT . "/cache/" . $name . ".md5" );
		$xls = new Spreadsheet_Excel_Reader( );
		$xls->setOutputEncoding('UTF-8');
		$xls->read( DIR_ROOT . "/cache/" . $name . ".md5" );
		$count = array( 0, 0 );
		for ($i = 1; $i <= $xls->sheets[2]['numRows']; $i++) {
			$count[0]++;
			$nameone = ( $xls->sheets[2]['cells'][$i][intval($_REQUEST['nameone'])] ) ? $xls->sheets[2]['cells'][$i][intval($_REQUEST['nameone'])] : "Неизвестный";
			$nametwo = ( $xls->sheets[2]['cells'][$i][intval($_REQUEST['nametwo'])] ) ? $xls->sheets[2]['cells'][$i][intval($_REQUEST['nametwo'])] : "";
			$phone = ( $xls->sheets[2]['cells'][$i][intval($_REQUEST['phone'])] ) ? $xls->sheets[2]['cells'][$i][intval($_REQUEST['phone'])] : false;
			if ( preg_match( '/^\+7[0-9]{10,12}$/', $phone ) ) {
				$phone = substr( $phone, 2, 16 );
			} elseif ( preg_match( '/^8[0-9]{10,11}$/', $phone ) ) {
				$phone = substr( $phone, 1, 16 );
			} elseif ( preg_match( '/^7[0-9]{10,11}$/', $phone ) ) {
				$phone = substr( $phone, 1, 16 );
			} elseif ( preg_match( '/^[0-9]{10,11}$/', $phone ) ) {
				$phone = $phone;
			} else {
				$phone = false;
			}
			if ( $phone && !strpos( $phones, "{$phone}" ) ) {
				$phones .="<li><span onClick=\"del_li(this);\"></span><div>{$nametwo} {$nameone} <{$phone}></div></li>"; 
				$count[1]++;
			}
		}
		$_SESSION['sms']['phones'] = $phones;
		$tpl->load( "info.tpl" );
		$tpl->set( "{content}", "<p>Успешно загруженно {$count['1']} из {$count['0']}</p><input type=\"button\" onClick=\"location.href='{$config['url_home']}/sms';\" value=\"Ок\" />" );
		$tpl->compile( "info" );
		return true;
	} else {
		$tpl->load( "info.tpl" );
		$tpl->set( "{content}", "<p>Формат файла не поддерживается</p><input type=\"button\" onClick=\"history.go(-1);\" value=\"Вернуться\" />" );
		$tpl->compile( "info" );
		return false;
	}
}

#загружаем и выводим
if ( $global['url'][1] == "" ) {
	
	$tpl->load( "sms.tpl" );
	$tpl->set( "{phones}", $_SESSION['sms']['phones'] );
	$tpl->set( "{sms}", $_SESSION['sms']['sms'] );
	if ( $_SESSION['sms']['send_time'] ) {
		$tpl->set( "{time}", date( "Y-m-d H:i" , $_SESSION['sms']['send_time'] ) );
	} else {
		$tpl->set( "{time}", date( "Y-m-d H:i" , $global['time'] ) );
	}
	$tpl->compile( "content" );
	
} elseif ( $global['url'][1] == "upload" ) {
	if ( $_REQUEST['action'] == "upload" ) {
		upload_phone();
	} else {
		$tpl->load( "upload.tpl" );
		$tpl->compile( "content" );
	}
}
?>