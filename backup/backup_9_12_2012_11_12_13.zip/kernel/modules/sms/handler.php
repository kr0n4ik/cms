<?php
if ( !defined( 'SMS_HANDLER' ) ) { die( "Hacking..." ); exit(); }
if ( $_SERVER['REMOTE_ADDR'] != $config['geteway_ip'] && $config['geteway_ip'] != "" ) { exit(); }

$id = intval( $_REQUEST['id'] );

switch ( $_REQUEST['status'] ) {
	case 8:
		$status = "2";
		break;
	case 2:
		$status = "-2";
		break;
	case 1:
		$status = "3";
		break;
	default:
		$status = intval( $_REQUEST['status'] );
}
$db->query( "UPDATE " . $sql['prefix'] . "_statistica_two SET status='" . $status . "', statustime=" . $global['time'] . " WHERE id=" . $id . ";" );
?>