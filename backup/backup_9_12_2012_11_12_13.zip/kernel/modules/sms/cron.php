<?php
if ( !defined( "SMS_CRON" ) ) { die( "Hacking..." ); exit(); }

$result = $row = array();

$result[0] = $db->query( "SELECT * FROM " . $sql['prefix'] . "_statistica_two WHERE status = '0' AND sendtime<=" . $global['time'] . " GROUP BY packetid;" );
while ( $row[0] = $db->fetchrow( $result[0] ) ) {
	$result[1] = $db->query( "SELECT * FROM " . $sql['prefix'] . "_statistica_two WHERE packetid={$row[0]['packetid']};" );
	while ( $row[1] = $db->fetchrow( $result[1] ) ) {
		$row[2] = $db->fetchrow( $db->query("SELECT sms FROM " . $sql['prefix'] . "_users WHERE id={$row[1]['userid']};" ) );
		if ( $row[2]['sms'] >= $row[1]['parts'] ) {
			if ( $sms->send( $row[1]['id'], $row[1]['phone'], $row[1]['sender'], $row[1]['message'] ) == 1 ) {
				$db->query( "UPDATE " . $sql['prefix'] . "_statistica_two SET status='2', statustime={$global['time']} WHERE id={$row[1]['id']};" );
				$db->query( "UPDATE " . $sql['prefix'] . "_users SET sms=sms-{$row[1]['parts']} WHERE id={$row[1]['userid']};" );
			} else {
				write_log( "cron", "Ошибка отправки, смотреть sms.log\n" );
			}
		} else {
			$db->query( "UPDATE " . $sql['prefix'] . "_statistica_two SET status='-3', statustime={$global['time']} WHERE id={$row[1]['id']};" );
		}
	}
}
unset( $result );
unset( $row );
?>