<?php
if ( !defined( "SMS_JSON" ) || !$global['user']['loged'] ) { die( "Hacking..." ); exit(); }

if ( $_REQUEST['action'] == "list" || $_REQUEST['action'] == "" ) {

	$page = intval( $_REQUEST['page'] );

	$query = "SELECT * FROM " . $sql['prefix'] . "_partners_two WHERE ( partone=" . $global['user']['id'] . " OR parttwo=" . $global['user']['id'] . " ) AND userid != 0";
	$count = $db->numrows( $db->query( $query . ";" ) );
	$result = $db->query( $query . " ORDER BY time LIMIT " . intval( $config['table_rows'] * $page ) . ", " . $config['table_rows'] . ";" );
	
	$i = 1;
	while ( $row = $db->fetchrow( $result ) ) {
		$color = ( $i%2 != 0 ) ? "#ffffff" : "#f8f8f8";
		$info = $db->fetchrow( $db->query( "SELECT * FROM " . $sql['prefix'] . "_users WHERE id=" . $row['userid'] . ";" ) );
		$pr = ( $row['parttwo'] ) ? $row['prparttwo'] : $row['prpartone'];
		$row['phone'] = ( $row['phone'] ) ? $row['phone'] : "Не заполнил";
		$global['out']['html'] .= "
		<tr style=\"background: " . $color . "\">
			<td>" . date( "Y-m-d H:i", $row['time'] ) . "</td>
			<td>" . $info['email'] . "</td>
			<td>" . $row['phone'] . "</td>
			<td>" . $pr . "%</td>
			<td>" . $info['code'] . "</td>
		</tr>
		";
		$i++;
	}
	if ( $config['table_rows'] < $count ) {
		for ( $i = 0; $i <  Ceil( $count/$config['table_rows'] ); $i++ ) {
			if ( $page == $i ) {
				$global['out']['page'] .= "<span class=\"page ui-disabled\">" . ( $i+1 ) . "</span>";
			} else {
				$global['out']['page'] .= "<span class=\"page\">" . ( $i+1 ) . "</span>";
			}
		}
	}
	$global['out']['count'] = $count;
	$global['out']['html'] = ( $global['out']['html'] != "" ) ? $global['out']['html'] : "<tr><td colspan=\"10\" style=\"background: #ffffff; text-align: center;\">Нет записей</td></tr>\n";
}
?>