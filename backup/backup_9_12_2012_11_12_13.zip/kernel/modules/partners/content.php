<?php
if ( !defined( 'SMS_INDEX' ) ) { die( "Hacking..." ); exit(); }
if ( !$global['user']['loged'] ) { header( "Location: index.php" ); exit();}

$info[0] = $db->numrows( $db->query("SELECT * FROM " . $sql['prefix'] . "_partners_two WHERE partone=" . $global['user']['id'] . ";" ) );
$info[1] = $db->numrows( $db->query("SELECT * FROM " . $sql['prefix'] . "_partners_two WHERE partone=" . $global['user']['id'] . " AND userid != 0;" ) );

$tpl->load( "partners.tpl" );
$tpl->set( "{info_one}", $info[0] );
$tpl->set( "{info_two}", $info[1] );
$tpl->set( "{code}", $global['user']['code'] );
$tpl->compile( "content" );
?>