<?php
if ( !defined( "SMS_JSON" ) || !$global['user']['loged'] ) { die( "Hacking..." ); exit(); }
$status = array(
	'-1' => "<p class=\"red\">Удалено</p>",
	'0' => "<p class=\"gray\">В очереди</p>",
	'1' => "<p class=\"blue\">В расмотрении</p>",
	'2' => "<p class=\"green\">Расмотренно</p>",
);
$subject = array(
	'0' => "Общие вопросы",
	'1' => "Предложения и пожелания",
	'2' => "Вопрос по SMS-рассылкам",
	'3' => "Вопрос по партнерской программе",
	'4' => "Вопрос по выплатам"
);

if ( $_REQUEST['action'] == "list" || $_REQUEST['action'] == "" ) {
	
	$page = intval( $_REQUEST['page'] );
	$sort = ( $_REQUEST['sort'] == "asc" ) ? "ASC" : "DESC";
	$find = ( $_REQUEST['status'] == "close" ) ? "status = '2' AND" : "( status = '1' OR status = '0' ) AND";
	switch ( $_REQUEST['order'] ) {
		case 0: $order = "subject"; break;
		case 1: $order = "title"; break;
		case 2: $order = "time"; break;
		case 3: $order = "status"; break;
		default: $order = "status";
	}

	
	$query = "SELECT * FROM " . $sql['prefix'] . "_ticket WHERE " . $find . " userid=" . $global['user']['id'];
	$count = $db->numrows( $db->query( $query . ";" ) );
	$result = $db->query( $query . " ORDER BY " . $order . " " . $sort . " LIMIT " . intval( $config['table_rows'] * $page ) . ", " . $config['table_rows'] . ";" );
	
	$i = 1;
	while ( $row = $db->fetchrow( $result ) ) {
		$color = ( $i%2 != 0 ) ? "#ffffff" : "#f8f8f8";
		$global['out']['html'] .= "
		<tr style=\"background: " . $color . "\">
			<td>" . $subject[$row['subject']] . "</td>
			<td>" . $row['title'] . "</td>
			<td>" . date( "d.m.Y H:s", $row['time'] ) . "</td>
			<td>" . $status[$row['status']] . "</td>
			<td>
			<a title=\"Просмотреть\" href=\"" . $config['url_home'] . "ticket/view/" . $row['id'] . "\">
				<img src=\"{$config['url_home']}templates/{$config['theme']}/images/24/view.png\" alt=\"@\" />
			</a>
		</td>
		</tr>
		";
		$i++;
	}
	if ( $config['table_rows'] < $count ) {
		for ( $i = 0; $i <  Ceil( $count/$config['table_rows'] ); $i++ ) {
			if ( $page == $i ) {
				$global['out']['page'] .= "<span class=\"page ui-disabled\">" . ( $i+1 ) . "</span>";
			} else {
				$global['out']['page'] .= "<span class=\"page\">" . ( $i+1 ) . "</span>";
			}
		}
	}
	$global['out']['count'] = $count;
	$global['out']['html'] = ( $global['out']['html'] != "" ) ? $global['out']['html'] : "<tr><td colspan=\"10\" style=\"background: #ffffff; text-align: center;\">Нет записей</td></tr>\n";
}
?>