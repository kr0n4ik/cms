<?php
if ( !defined( 'SMS_INDEX' ) ) { die( "Hacking..." ); exit(); }
if ( !$global['user']['loged'] ) { header( "Location: index.php" ); exit();}

if ( $_REQUEST['action'] == "save" ) {
	$subject = intval( $_REQUEST['subject'] );
	$title = $db->escape( htmlspecialchars( substr( $_REQUEST['title'], 0, 255 ) ) );
	$text = $db->escape( htmlspecialchars( substr( $_REQUEST['text'], 0, 500 ) ) );
	if ( $title && $text ) {
		$db->query( "INSERT INTO " . $sql['prefix'] . "_ticket SET time={$global['time']}, subject='{$subject}', title='{$title}', text='{$text}', userid={$global['user']['id']};" );
		$tpl->load( "info.tpl" );
		$tpl->set( "{content}", "<p>Заявка успешно добовлена</p><input type=\"button\" onClick=\"location.href='{$config['url_home']}ticket';\" value=\"Ок\" />" );
		$tpl->compile( "info" );
	} else {
		$tpl->load( "info.tpl" );
		$tpl->set( "{content}", "<p>Имеются пустые поля</p><input type=\"button\" onClick=\"history.back(-1);\" value=\"Вернуться\" />" );
		$tpl->compile( "info" );
	}
}

if ( $global['url'][1] == "list" || $global['url'][1] == "" ) {
	$tpl->load( "ticket.tpl" );
	$tpl->set( "[list]", "" );
	$tpl->set( "[/list]", "" );
	$tpl->set_block( "'\\[add\\](.*?)\\[/add\\]'si", "" );
	$tpl->compile( "content" );
} elseif ( $global['url'][1] == "new" ) {
	$tpl->load( "ticket.tpl" );
	$tpl->set( "[add]", "" );
	$tpl->set( "[/add]", "" );
	$tpl->set_block( "'\\[list\\](.*?)\\[/list\\]'si", "" );
	$tpl->compile( "content" );
}
?>