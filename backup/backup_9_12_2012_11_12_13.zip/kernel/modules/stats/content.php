<?php
if ( !defined( "SMS_INDEX" ) ) { die( "Hacking..." ); exit(); }
if ( !$global['user']['loged'] ) { header( "Location: index.php" ); exit();}

$tpl->load( "statistica.tpl" );
$tpl->compile( "content" );
?>