<?php
if ( !defined( "SMS_JSON" ) || !$global['user']['loged'] ) { die( "Hacking..." ); exit(); }
$status = array(
	'-3' => "<p class=\"red\">Пополните баланс</p>",
	'-2' => "<p class=\"red\">Не доставлено</p>",
	'-1' => "<p class=\"red\">Не принято</p>",
	'0' => "<p class=\"gray\">В очерди</p>",
	'1' => "<p class=\"blue\">У шлюза</p>",
	'2' => "<p class=\"blue\">У оператора</p>",
	'3' => "<p class=\"green\">Доставлено</p>"
);
if ( $_REQUEST['action'] == "" ) {
	$page = intval( $_REQUEST['page'] );
	$sort = ( $_REQUEST['sort'] == "asc" ) ? "ASC" : "DESC";
	switch ( $_REQUEST['order'] ) {
		case 0: $order = "createtime"; break;
		case 1: $order = "statustime"; break;
		case 2: $order = "sender"; break;
		case 3: $order = "phone"; break;
		case 4: $order = "status"; break;
		default: $order = "status";
	}

	$query = "SELECT * FROM " . $sql['prefix'] . "_statistica_two WHERE " . $find . " userid=" . $global['user']['id'];
	$count = $db->numrows( $db->query( $query . ";" ) );
	$result = $db->query( $query . " ORDER BY " . $order . " " . $sort . " LIMIT " . intval( $config['table_rows'] * $page ) . ", " . $config['table_rows'] . ";" );
	
	$i = 1;
	while ( $row = $db->fetchrow( $result ) ) {
		$color = ( $i%2 != 0 ) ? "#ffffff" : "#f8f8f8";
		$statustime = ( $row['statustime'] == 0 || $row['statustime'] == "" ) ? "Не получено" : date( "Y-m-d H:i", $row['statustime'] );
		$global['out']['html'] .= "
		<tr style=\"background: " . $color . "\">
			<td>" . date( "Y-m-d H:i", $row['createtime'] ) . "</td>
			<td>" . $statustime . "</td>
			<td>" . $row['sender'] . "</td>
			<td>+" . $row['phone'] . "</td>
			<td>" . $status[$row['status']] . "</td>
		</tr>
		";
		$i++;
	}
	
	if ( $config['table_rows'] < $count ) {
		for ( $i = 0; $i <  Ceil( $count/$config['table_rows'] ); $i++ ) {
			if ( $page == $i ) {
				$global['out']['page'] .= "<span class=\"page ui-disabled\">" . ( $i+1 ) . "</span>";
			} else {
				$global['out']['page'] .= "<span class=\"page\">" . ( $i+1 ) . "</span>";
			}
		}
	}
	
	$global['out']['count'] = $count;
	$global['out']['html'] = ( $global['out']['html'] ) ? $global['out']['html'] : "<tr><td colspan=\"10\" style=\"background: #ffffff; text-align: center;\">Нет записей</td></tr>\n";
	
}
?>