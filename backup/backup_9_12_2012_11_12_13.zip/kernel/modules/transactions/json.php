<?php
if ( !defined( "SMS_JSON" ) || !$global['user']['loged'] ) { die( "Hacking..." ); exit(); }

if ( $_REQUEST['action'] == "list" || $_REQUEST['action'] == "" ) {

	$page = intval( $_REQUEST['page'] );
	$sort = ( $_REQUEST['sort'] == "asc" ) ? "ASC" : "DESC";
	switch ( $_REQUEST['order'] ) {
		case 0: $order = "time"; break;
		case 1: $order = "amount"; break;
		case 2: $order = "service"; break;
		case 3: $order = "title"; break;
		case 4: $order = "reason"; break;
		default: $order = "time";
	}

	$query = "SELECT * FROM " . $sql['prefix'] . "_transactions WHERE " . $find . " userid=" . $global['user']['id'];
	$count = $db->numrows( $db->query( $query . ";" ) );
	$result = $db->query( $query . " ORDER BY " . $order . " " . $sort . " LIMIT " . intval( $config['table_rows'] * $page ) . ", " . $config['table_rows'] . ";" );
	
	$i = 1;
	while ( $row = $db->fetchrow( $result ) ) {
		$color = ( $i%2 != 0 ) ? "#ffffff" : "#f8f8f8";
		$global['out']['html'] .= "
		<tr style=\"background: " . $color . "\">
			<td>" . date( "d.m.Y H:s", $row['time'] ) . "</td>
			<td>" . $row['amount'] . "</td>
			<td>" . $row['service'] . "</td>
			<td>" . $row['title'] . "</td>
			<td>" . $row['reason'] . "</td>
		</tr>
		";
		$i++;
	}
	if ( $config['table_rows'] < $count ) {
		for ( $i = 0; $i <  Ceil( $count/$config['table_rows'] ); $i++ ) {
			if ( $page == $i ) {
				$global['out']['page'] .= "<span class=\"page ui-disabled\">" . ( $i+1 ) . "</span>";
			} else {
				$global['out']['page'] .= "<span class=\"page\">" . ( $i+1 ) . "</span>";
			}
		}
	}
	$global['out']['count'] = $count;
	$global['out']['html'] = ( $global['out']['html'] ) ? $global['out']['html'] : "<tr><td colspan=\"10\" style=\"background: #ffffff; text-align: center;\">Нет записей</td></tr>\n";
}
?>