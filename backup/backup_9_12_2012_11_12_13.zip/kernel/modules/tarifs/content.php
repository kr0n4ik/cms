<?php
if ( !defined( 'SMS_INDEX' ) ) { die( "Hacking..." ); exit(); }

$old = 0;
$result = $db->query( "SELECT * FROM " . $sql['prefix'] . "_tariffs_two;" );
while ( $row = $db->fetchrow( $result ) ) {
	$color = ( $i%2 == 0 ) ? "#ffffff" : "#f8f8f8";
	$tarifs .= "
	<tr style=\"background: " . $color ."\">
		<td>От " . $old . " до " . ( $row['count'] - 1 ) . "</td>
		<td>" . $row['cost'] . "</td>
	</tr>
	";
$old = $row['count'];
}


$tpl->load( "tarifs.tpl" );
$tpl->set( "{tarifs}", $tarifs );
$tpl->compile( "content" );
?>