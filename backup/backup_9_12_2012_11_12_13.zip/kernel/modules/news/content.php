<?php
if ( !defined( "SMS_INDEX" ) ) { die( "Hacking..." ); exit(); }
if ( !$global['user']['loged'] ) { header( "Location: index.php" ); exit();}

set_cookie( "news_time", $global['time'], 800 );
$page = ( $global['url']['1'] == "page" ) ? intval( $global['url']['2'] ) - 1 : 0;

$count = $db->numrows( $db->query( "SELECT * FROM " . $sql['prefix'] . "_news;" ) );
$result = $db->query( "SELECT * FROM " . $sql['prefix'] . "_news WHERE time <= " . $global['time'] . "  ORDER BY time DESC LIMIT " . intval( $config['news_rows'] * $page ) . ", " . $config['news_rows'] . ";" );
while ( $row = $db->fetchrow( $result ) ) {
	$template .= "<div class=\"news\"><span>Автор: world-sms, от " . date( "d.m.Y", $row['time'] ) . "</span><h2>" . $row['title'] . "</h2><div>" . $row['template'] . "</div></div>\n";
}

if ( $config['news_rows'] < $count ) {
	for ( $i = 0; $i <  Ceil( $count/$config['news_rows'] ); $i++ ) {
		if ( $page == $i ) {
			$pages .= "<span>" . ( $i+1 ) . "</span>";
		} else {
			$pages .= "<a href=\"" . $config['url_home'] . "news/page/" . ( $i+1 ) . "\">" . ( $i+1 ) . "</a>";
		}
	}
}

#загружаем и выводим
$tpl->load( "news.tpl" );
$tpl->set( "{template}", $template );
$tpl->set( "{pages}", $pages );
$tpl->compile( "content" );
?>