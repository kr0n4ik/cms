function message(title, text) {
	$('#info').remove();
	$('body').prepend('<div id="info"><div class="box"><div class="header" ><img src="templates/default/images/24/close.png" /><h1>' + title + '</h1></div><div class="content">' + text + '</div></div></div>');
	var windowWidth = $(document).width();
	var windowHeight = $(document).height();
	$('html, body').animate( { scrollTop: 0 }, 'slow');
	$("div#info").css({"height": windowHeight, "width": windowWidth});
	
}
$(document).ready(function() {
	/*Навигация*/
	$('div.navigation ul li a').css({ 'width':( 100/$('div.navigation ul li').length ) + '%' });
	$('#info').css({'height': $(document).height()} );
	$('#collapsible h2').click(function(){
		if ( $(this).parent('div').attr('class') == 'open' ) {
			$(this).parent('div').attr('class', 'close');
		} else {
			$(this).parent('div').attr('class', 'open');
		}
	});
	$( '#info div.header img' ).live( 'click', function(){
		$( '#info' ).remove();
	});
});