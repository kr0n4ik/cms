<?php
@session_start();
@ob_start ();
@ob_implicit_flush ( 0 );

#Константы
define( "SMS_INDEX", true );
define( "DIR_ROOT", dirname( __FILE__ ) );
define( "DIR_KERNEL", DIR_ROOT . "/kernel" );

#Иницилизация глобальных переменных
$global = array( 
	'microtime' => microtime(), 
	'url' => explode( "/", @$_GET['url']), 
	'ip' => @$_SERVER['REMOTE_ADDR'],
	'client' => "desktop"
);

require_once DIR_KERNEL . "/init.php";

foreach ( $global['modules'] as $key => $value ) {
	if ( $global['url'][0] == $key && $value['title'] != "" ) { 
		$navigation .= "<li><a class=\"ui-btn-active\" title=\"" . $value['title'] . "\" href=\"" . $config['url_home'] . $key . "\">" . $value['title'] . "</a></li>\n";
	} elseif ( $value['title'] != "" ) {
		$navigation .= "<li><a title=\"" . $value['title'] . "\" href=\"" . $config['url_home'] . $key . "\">" . $value['title'] . "</a></li>\n";
	}
}

$keywords = ( !empty( $row['metakeys'] ) ) ? $row['metakeys'] : $config['keywords'];
$description = ( !empty( $row['metadescr'] ) ) ? $row['metadescr'] : $config['description'];
$title = ( !empty( $row['title'] ) ) ? $row['title'] . " - " . $config['title'] : $config['title'];

$tpl->load( "main.tpl" );
$tpl->set( "{title}", $title );
$tpl->set( "{keywords}", $keywords );
$tpl->set( "{description}", $description );
$tpl->set( "{info}", $tpl->result['info'] );
$tpl->set( "{menu}", $tpl->result['menu'] );
$tpl->set( "{navigation}", $navigation );
$tpl->set( "{content}", $tpl->result['content'] );
$tpl->set( "{counter}", $config['counter'] );

#Мобильная версия
$tpl->set( "{buttonone}", $global['mobile']['buttonone'] );
$tpl->set( "{buttontwo}", $global['mobile']['buttontwo'] );

$tpl->compile( "main" );
echo $tpl->result['main'];
$tpl->global_clear ();
$db->close();

$global['microtime'] = ( microtime() - $global['microtime'] );
echo "\n<!-- World-SMS.ru Time:" . $global['microtime'] . " -->\n";
unset( $global );
?>